# Monster Protocol — комплект преподавателя

Готовая демонстрация: `START_WINDOWS.bat` (Python 3.10+) или `python3 start_demo.py`.
Без Python откройте `demo/game.json` в GDevelop и нажмите Предпросмотр.

- Готовый проект: [demo/game.json](demo/game.json).
- Основа ученика: [student-template/game.json](student-template/game.json).
- [Подготовка класса](docs/TEACHER_START_RU.md).
- [12 подробных занятий](docs/LESSONS_RU.md).
- [Точные события](docs/EVENTS_RU.md).
- [Подключение Teachable Machine](docs/AI_RU.md).
- [Карточки учеников](docs/STUDENT_CARDS_RU.md).
- [Проверки и ограничения](docs/VALIDATION_RU.md).

Раздавайте детям отдельную копию всей папки student-template, а не демо и не один JSON.
Камера и качество модели требуют проверки на школьном устройстве.

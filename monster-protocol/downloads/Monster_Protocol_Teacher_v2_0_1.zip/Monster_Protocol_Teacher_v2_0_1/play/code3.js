gdjs.FinalCode = {};
gdjs.FinalCode.localVariables = [];
gdjs.FinalCode.idToCallbackMap = new Map();
gdjs.FinalCode.GDBackdropObjects1= [];
gdjs.FinalCode.GDBackdropObjects2= [];
gdjs.FinalCode.GDBackdropObjects3= [];
gdjs.FinalCode.GDBrandObjects1= [];
gdjs.FinalCode.GDBrandObjects2= [];
gdjs.FinalCode.GDBrandObjects3= [];
gdjs.FinalCode.GDEditionObjects1= [];
gdjs.FinalCode.GDEditionObjects2= [];
gdjs.FinalCode.GDEditionObjects3= [];
gdjs.FinalCode.GDTitleObjects1= [];
gdjs.FinalCode.GDTitleObjects2= [];
gdjs.FinalCode.GDTitleObjects3= [];
gdjs.FinalCode.GDKickerObjects1= [];
gdjs.FinalCode.GDKickerObjects2= [];
gdjs.FinalCode.GDKickerObjects3= [];
gdjs.FinalCode.GDHeaderShadeObjects1= [];
gdjs.FinalCode.GDHeaderShadeObjects2= [];
gdjs.FinalCode.GDHeaderShadeObjects3= [];
gdjs.FinalCode.GDMusicObjects1= [];
gdjs.FinalCode.GDMusicObjects2= [];
gdjs.FinalCode.GDMusicObjects3= [];
gdjs.FinalCode.GDMusicLabelObjects1= [];
gdjs.FinalCode.GDMusicLabelObjects2= [];
gdjs.FinalCode.GDMusicLabelObjects3= [];
gdjs.FinalCode.GDParticleSparkObjects1= [];
gdjs.FinalCode.GDParticleSparkObjects2= [];
gdjs.FinalCode.GDParticleSparkObjects3= [];
gdjs.FinalCode.GDParticleHeartObjects1= [];
gdjs.FinalCode.GDParticleHeartObjects2= [];
gdjs.FinalCode.GDParticleHeartObjects3= [];
gdjs.FinalCode.GDParticleBubbleObjects1= [];
gdjs.FinalCode.GDParticleBubbleObjects2= [];
gdjs.FinalCode.GDParticleBubbleObjects3= [];
gdjs.FinalCode.GDProjectileObjects1= [];
gdjs.FinalCode.GDProjectileObjects2= [];
gdjs.FinalCode.GDProjectileObjects3= [];
gdjs.FinalCode.GDFloatingNumberObjects1= [];
gdjs.FinalCode.GDFloatingNumberObjects2= [];
gdjs.FinalCode.GDFloatingNumberObjects3= [];
gdjs.FinalCode.GDShieldHaloObjects1= [];
gdjs.FinalCode.GDShieldHaloObjects2= [];
gdjs.FinalCode.GDShieldHaloObjects3= [];
gdjs.FinalCode.GDMessagePanelObjects1= [];
gdjs.FinalCode.GDMessagePanelObjects2= [];
gdjs.FinalCode.GDMessagePanelObjects3= [];
gdjs.FinalCode.GDMessageObjects1= [];
gdjs.FinalCode.GDMessageObjects2= [];
gdjs.FinalCode.GDMessageObjects3= [];
gdjs.FinalCode.GDCreatorObjects1= [];
gdjs.FinalCode.GDCreatorObjects2= [];
gdjs.FinalCode.GDCreatorObjects3= [];
gdjs.FinalCode.GDCreatorLabelObjects1= [];
gdjs.FinalCode.GDCreatorLabelObjects2= [];
gdjs.FinalCode.GDCreatorLabelObjects3= [];
gdjs.FinalCode.GDCameraObjects1= [];
gdjs.FinalCode.GDCameraObjects2= [];
gdjs.FinalCode.GDCameraObjects3= [];
gdjs.FinalCode.GDCameraLabelObjects1= [];
gdjs.FinalCode.GDCameraLabelObjects2= [];
gdjs.FinalCode.GDCameraLabelObjects3= [];
gdjs.FinalCode.GDMonsterBodyObjects1= [];
gdjs.FinalCode.GDMonsterBodyObjects2= [];
gdjs.FinalCode.GDMonsterBodyObjects3= [];
gdjs.FinalCode.GDMonsterEyesObjects1= [];
gdjs.FinalCode.GDMonsterEyesObjects2= [];
gdjs.FinalCode.GDMonsterEyesObjects3= [];
gdjs.FinalCode.GDMonsterMouthObjects1= [];
gdjs.FinalCode.GDMonsterMouthObjects2= [];
gdjs.FinalCode.GDMonsterMouthObjects3= [];
gdjs.FinalCode.GDMonsterArmsObjects1= [];
gdjs.FinalCode.GDMonsterArmsObjects2= [];
gdjs.FinalCode.GDMonsterArmsObjects3= [];
gdjs.FinalCode.GDMonsterLegsObjects1= [];
gdjs.FinalCode.GDMonsterLegsObjects2= [];
gdjs.FinalCode.GDMonsterLegsObjects3= [];
gdjs.FinalCode.GDMonsterHornsObjects1= [];
gdjs.FinalCode.GDMonsterHornsObjects2= [];
gdjs.FinalCode.GDMonsterHornsObjects3= [];
gdjs.FinalCode.GDMonsterNoseObjects1= [];
gdjs.FinalCode.GDMonsterNoseObjects2= [];
gdjs.FinalCode.GDMonsterNoseObjects3= [];
gdjs.FinalCode.GDMonsterEarsObjects1= [];
gdjs.FinalCode.GDMonsterEarsObjects2= [];
gdjs.FinalCode.GDMonsterEarsObjects3= [];
gdjs.FinalCode.GDMonsterTailObjects1= [];
gdjs.FinalCode.GDMonsterTailObjects2= [];
gdjs.FinalCode.GDMonsterTailObjects3= [];
gdjs.FinalCode.GDMonsterWingsObjects1= [];
gdjs.FinalCode.GDMonsterWingsObjects2= [];
gdjs.FinalCode.GDMonsterWingsObjects3= [];
gdjs.FinalCode.GDGrandTrophyObjects1= [];
gdjs.FinalCode.GDGrandTrophyObjects2= [];
gdjs.FinalCode.GDGrandTrophyObjects3= [];
gdjs.FinalCode.GDNameTextObjects1= [];
gdjs.FinalCode.GDNameTextObjects2= [];
gdjs.FinalCode.GDNameTextObjects3= [];
gdjs.FinalCode.GDBadgeObjects1= [];
gdjs.FinalCode.GDBadgeObjects2= [];
gdjs.FinalCode.GDBadgeObjects3= [];
gdjs.FinalCode.GDFinalTextObjects1= [];
gdjs.FinalCode.GDFinalTextObjects2= [];
gdjs.FinalCode.GDFinalTextObjects3= [];
gdjs.FinalCode.GDAgainObjects1= [];
gdjs.FinalCode.GDAgainObjects2= [];
gdjs.FinalCode.GDAgainObjects3= [];
gdjs.FinalCode.GDAgainLabelObjects1= [];
gdjs.FinalCode.GDAgainLabelObjects2= [];
gdjs.FinalCode.GDAgainLabelObjects3= [];
gdjs.FinalCode.GDHomeObjects1= [];
gdjs.FinalCode.GDHomeObjects2= [];
gdjs.FinalCode.GDHomeObjects3= [];
gdjs.FinalCode.GDHomeLabelObjects1= [];
gdjs.FinalCode.GDHomeLabelObjects2= [];
gdjs.FinalCode.GDHomeLabelObjects3= [];


gdjs.FinalCode.mapOfGDgdjs_9546FinalCode_9546GDMusicObjects2Objects = Hashtable.newFrom({"Music": gdjs.FinalCode.GDMusicObjects2});
gdjs.FinalCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Music"), gdjs.FinalCode.GDMusicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.FinalCode.mapOfGDgdjs_9546FinalCode_9546GDMusicObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13807876);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(28).setNumber(1 - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(28)));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(28)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MusicLabel"), gdjs.FinalCode.GDMusicLabelObjects2);
{for(var i = 0, len = gdjs.FinalCode.GDMusicLabelObjects2.length ;i < len;++i) {
    gdjs.FinalCode.GDMusicLabelObjects2[i].setString("Звук: выкл");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(28)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MusicLabel"), gdjs.FinalCode.GDMusicLabelObjects1);
{for(var i = 0, len = gdjs.FinalCode.GDMusicLabelObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDMusicLabelObjects1[i].setString("Звук: вкл");
}
}
}

}


};gdjs.FinalCode.mapOfGDgdjs_9546FinalCode_9546GDCreatorObjects1Objects = Hashtable.newFrom({"Creator": gdjs.FinalCode.GDCreatorObjects1});
gdjs.FinalCode.mapOfGDgdjs_9546FinalCode_9546GDCameraObjects1Objects = Hashtable.newFrom({"Camera": gdjs.FinalCode.GDCameraObjects1});
gdjs.FinalCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MonsterArms"), gdjs.FinalCode.GDMonsterArmsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterBody"), gdjs.FinalCode.GDMonsterBodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterEars"), gdjs.FinalCode.GDMonsterEarsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterEyes"), gdjs.FinalCode.GDMonsterEyesObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterHorns"), gdjs.FinalCode.GDMonsterHornsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterLegs"), gdjs.FinalCode.GDMonsterLegsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterMouth"), gdjs.FinalCode.GDMonsterMouthObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterNose"), gdjs.FinalCode.GDMonsterNoseObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterTail"), gdjs.FinalCode.GDMonsterTailObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterWings"), gdjs.FinalCode.GDMonsterWingsObjects1);
{for(var i = 0, len = gdjs.FinalCode.GDMonsterBodyObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDMonsterBodyObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}
{for(var i = 0, len = gdjs.FinalCode.GDMonsterEyesObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDMonsterEyesObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}
{for(var i = 0, len = gdjs.FinalCode.GDMonsterMouthObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDMonsterMouthObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}
{for(var i = 0, len = gdjs.FinalCode.GDMonsterArmsObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDMonsterArmsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
}
{for(var i = 0, len = gdjs.FinalCode.GDMonsterLegsObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDMonsterLegsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}
{for(var i = 0, len = gdjs.FinalCode.GDMonsterHornsObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDMonsterHornsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)));
}
}
{for(var i = 0, len = gdjs.FinalCode.GDMonsterNoseObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDMonsterNoseObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)));
}
}
{for(var i = 0, len = gdjs.FinalCode.GDMonsterEarsObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDMonsterEarsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)));
}
}
{for(var i = 0, len = gdjs.FinalCode.GDMonsterTailObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDMonsterTailObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)));
}
}
{for(var i = 0, len = gdjs.FinalCode.GDMonsterWingsObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDMonsterWingsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)));
}
}
}

}


};gdjs.FinalCode.mapOfGDgdjs_9546FinalCode_9546GDHomeObjects1Objects = Hashtable.newFrom({"Home": gdjs.FinalCode.GDHomeObjects1});
gdjs.FinalCode.mapOfGDgdjs_9546FinalCode_9546GDAgainObjects1Objects = Hashtable.newFrom({"Again": gdjs.FinalCode.GDAgainObjects1});
gdjs.FinalCode.userFunc0xad00a0 = function GDJSInlineCode(runtimeScene) {
"use strict";
/* Ready-made visual/audio kit. All health, energy, rewards and turn rules are native events. */
if (!globalThis.MonsterWorld) {
  globalThis.MonsterWorld = (() => {
    let scene,ctx,music=null,track='',audioContext=null,unlocked=false;
    const events=[];
    const record=(type,detail={})=>{events.push({type,...detail});if(events.length>40)events.shift();};
    const vars=()=>scene.getGame().getVariables();
    const num=n=>vars().get(n).getAsNumber();
    const sv=n=>scene.getVariables().get(n).getAsNumber();
    const resource=name=>{const r=scene.getGame().getGameData().resources.resources.find(r=>r.name==='assets/'+name);return r?scene.getGame().getResourceLoader().getFullUrl(r.file):null;};
    function syncMusic(){
      if(!scene||!unlocked)return;
      const desired=scene.getName()==='Arena'?'battle-loop.wav':'home-loop.wav';
      if(!music||desired!==track){if(music)music.pause();const url=resource(desired);if(!url)return;music=new Audio(url);music.loop=true;music.volume=.25;track=desired;}
      music.volume=Math.max(0,Math.min(1,num('MusicVolume')/100));
      if(num('MusicOn')===1){if(music.paused)music.play().catch(()=>{});}else music.pause();
    }
    document.addEventListener('pointerdown',()=>{
      if(!scene)return;unlocked=true;
      const AudioCtx=globalThis.AudioContext||globalThis.webkitAudioContext;
      if(AudioCtx&&!audioContext)audioContext=new AudioCtx();
      if(audioContext?.state==='suspended')audioContext.resume().catch(()=>{});
      syncMusic();
    },{capture:true});
    document.addEventListener('visibilitychange',()=>{if(document.hidden){if(music)music.pause();}else syncMusic();});
    function sound(kind){
      if(!audioContext||audioContext.state!=='running'||num('MusicOn')!==1)return;
      const tones={attack:[392,784],hit:[120,65],good:[523,659,784],shield:[330,494],sleep:[262,330],error:[160,120]};
      (tones[kind]||tones.good).forEach((f,i)=>{const osc=audioContext.createOscillator(),gain=audioContext.createGain(),at=audioContext.currentTime+i*.07;osc.type=kind==='hit'?'triangle':'sine';osc.frequency.setValueAtTime(f,at);gain.gain.setValueAtTime(0,at);gain.gain.linearRampToValueAtTime(.075,at+.015);gain.gain.exponentialRampToValueAtTime(.001,at+.23);osc.connect(gain);gain.connect(audioContext.destination);osc.start(at);osc.stop(at+.25);});
    }
    function emit(type,x,y,count=12,color=null){
      for(let i=0;i<count&&ctx.particles.length<100;i++){
        const o=scene.createObject(type);if(!o)continue;
        const angle=Math.random()*Math.PI*2,speed=45+Math.random()*130,size=10+Math.random()*15;
        o.setPosition(x,y);o.setSize(size,size);o.setZOrder(80);if(color&&o.setColor)o.setColor(color);
        ctx.particles.push({o,x,y,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed-90,age:0,life:.7+Math.random()*.6,spin:Math.random()*180-90});
      }
    }
    function floating(text,x,y,color){const o=scene.createObject('FloatingNumber');if(!o)return;o.setString(text);o.setPosition(x,y);o.setZOrder(85);o.setColor(color);ctx.particles.push({o,x,y,vx:0,vy:-48,age:0,life:1.1,spin:0});}
    function bolt(){const o=scene.createObject('Projectile');if(!o)return;o.setSize(65,65);o.setZOrder(50);ctx.particles.push({o,projectile:true,age:0,life:.3});}
    function base(o){return {o,x:o.getX(),y:o.getY(),w:o.getWidth(),h:o.getHeight(),angle:o.getAngle()};}
    function initialize(next){
      scene=next;const objects=[];for(const cat of ['Body','Eyes','Mouth','Arms','Legs','Horns','Nose','Ears','Tail','Wings'])for(const o of scene.getObjects('Monster'+cat))objects.push({...base(o),cat});
      const body=objects.find(x=>x.cat==='Body');
      ctx={time:0,parts:objects,rival:scene.getObjects('Rival').map(base),heroX:body?body.x+body.w/2:400,heroY:body?body.y+body.h/2:400,particles:[],lastHP:num('Health'),lastEnemy:num('EnemyHP'),lastPhase:0,lastRound:num('Round'),react:0,heroHurt:0,enemyHurt:0,emission:0,barHealth:num('Health'),barEnergy:num('Energy'),barEnemy:num('EnemyHP'),buttons:[]};
      const buttonNames=['Music','Feed','Train','Rest','Battle','Decor','Attack','Shield','Heal','Creator','Camera','Retreat','Again','Home','Random','Rename','Save','Load','ToLab'];
      for(const o of scene.getAdhocListOfAllInstances())if(buttonNames.includes(o.getName())||/^(Body|Eyes|Mouth|Arms|Legs|Horns|Nose|Ears|Tail|Wings)(Next|Prev)$/.test(o.getName()))ctx.buttons.push(base(o));
      if(scene.getName()==='Final'){emit('ParticleSpark',870,300,45);sound('good');}
      record('scene',{name:scene.getName()});syncMusic();
    }
    function tick(next){
      if(scene!==next)initialize(next);
      const dt=Math.min(.05,Math.max(0,scene.getElapsedTime()/1000));ctx.time+=dt;ctx.react=Math.max(0,ctx.react-dt);ctx.heroHurt=Math.max(0,ctx.heroHurt-dt);ctx.enemyHurt=Math.max(0,ctx.enemyHurt-dt);
      const name=scene.getName(),phase=sv('Phase'),turn=sv('TurnTime'),kind=sv('ActionKind');
      const fx=num('VisualFX');if(fx){vars().get('VisualFX').setNumber(0);ctx.react=.9;
        if(fx===1){emit('ParticleHeart',ctx.heroX,ctx.heroY,13);floating('+20 энергии',ctx.heroX-80,ctx.heroY-100,'186;245;210');sound('good');}
        if(fx===2){emit('ParticleSpark',ctx.heroX,ctx.heroY,18);floating('+4 силы',ctx.heroX-60,ctx.heroY-110,'255;221;140');sound('good');}
        if(fx===3){emit('ParticleBubble',ctx.heroX,ctx.heroY,12);floating('Z z z…',ctx.heroX-40,ctx.heroY-120,'202;190;255');sound('sleep');}
        if(fx===4){emit('ParticleSpark',ctx.heroX,ctx.heroY-50,36);sound('good');}
        if(fx===5){emit('ParticleHeart',ctx.heroX,ctx.heroY,12);sound('good');}
        if(fx===6){floating('Нужно больше энергии',ctx.heroX-120,ctx.heroY-110,'255;191;165');sound('error');}
        record('reaction',{kind:fx});
      }
      if(num('PetRequest')){vars().get('PetRequest').setNumber(0);ctx.react=1.2;emit('ParticleHeart',ctx.heroX,ctx.heroY-70,18);sound('good');record('pet');}
      if(name==='Arena'&&phase===1&&ctx.lastPhase!==1){
        if(kind===1){bolt();sound('attack');record('player-attack');}
        if(kind===2){emit('ParticleBubble',ctx.heroX,ctx.heroY,15);sound('shield');record('shield');}
        if(kind===3)record('heal');
      }
      if(name==='Arena'&&phase===3&&ctx.lastPhase!==3){emit('ParticleSpark',970,365,12);sound('attack');record('enemy-counterattack');}
      const hp=num('Health'),enemy=num('EnemyHP');
      if(hp<ctx.lastHP){ctx.heroHurt=.28;emit('ParticleSpark',ctx.heroX,ctx.heroY,13);floating('−'+(ctx.lastHP-hp),ctx.heroX,ctx.heroY-80,'255;157;170');sound('hit');record('player-damage',{amount:ctx.lastHP-hp});}
      if(hp>ctx.lastHP&&name==='Arena')floating('+'+(hp-ctx.lastHP),ctx.heroX,ctx.heroY-90,'186;245;210');
      if(enemy<ctx.lastEnemy&&name==='Arena'){ctx.enemyHurt=.28;emit('ParticleSpark',965,380,20);floating('−'+(ctx.lastEnemy-enemy),960,300,'255;220;151');sound('hit');record('enemy-damage',{amount:ctx.lastEnemy-enemy});}
      ctx.lastHP=hp;ctx.lastEnemy=enemy;ctx.lastPhase=phase;
      const t=ctx.time,breath=1+.018*Math.sin(t*3),blink=(t%4.3)>.12&&(t%4.3)<.25;
      let lunge=0,jump=0;
      if(name==='Arena'&&kind===1&&phase>0&&phase<4)lunge=100*Math.sin(Math.PI*Math.min(1,turn/.62));
      if(ctx.react>0)jump=-Math.abs(Math.sin(ctx.react*10))*num('ReactionHeight');
      const shake=ctx.heroHurt>0?Math.sin(ctx.heroHurt*120)*9:0;
      for(const b of ctx.parts){
        const sx=breath,sy=1-.016*Math.sin(t*3);b.o.setSize(b.w*sx,b.h*sy*(b.cat==='Eyes'&&blink?.08:1));
        let x=ctx.heroX+(b.x-ctx.heroX)*sx+lunge+shake,y=ctx.heroY+(b.y-ctx.heroY)*sy+Math.sin(t*2.4)*num('IdleAmplitude')+jump;
        if(b.cat==='Eyes'&&blink)y+=b.h*.45;
        b.o.setPosition(x,y);b.o.setAngle(b.angle+(b.cat==='Arms'?Math.sin(t*3)*2:0));
        b.o.setOpacity(ctx.heroHurt>0&&Math.sin(ctx.heroHurt*80)>0?135:255);
      }
      for(const b of ctx.rival){
        let x=b.x,y=b.y+Math.sin(t*2.1)*6,angle=Math.sin(t*1.7)*2;
        if(phase===3)x-=140*Math.sin(Math.PI*Math.min(1,Math.max(0,(turn-.68)/.46)));
        b.o.setPosition(x,y);b.o.setAngle(angle);b.o.setSize(b.w*(1+.022*Math.sin(t*2.1)),b.h*(1-.018*Math.sin(t*2.1)));
        b.o.setOpacity(phase===5?Math.max(0,220-turn*350):ctx.enemyHurt>0?145:255);
      }
      const halo=scene.getObjects('ShieldHalo')[0];if(halo){if(name==='Arena'&&kind===2&&phase>0&&phase<5){halo.setPosition(ctx.heroX-85,ctx.heroY-60);halo.setSize(170,170);halo.setOpacity(180+50*Math.sin(t*8));}else halo.setPosition(-400,-400);}
      // Native scene sprites show the values; only their visual interpolation is here.
      for(const [field,key,max]of [['Health','barHealth',100],['Energy','barEnergy',100],['EnemyHealth','barEnemy',40+20*num('Round')]]){
        const target=field==='EnemyHealth'?enemy:num(field);ctx[key]+=(target-ctx[key])*Math.min(1,dt*12);
        const o=scene.getObjects(field+'Bar')[0];if(o){const width=field==='EnemyHealth'?241:225;o.setWidth(Math.max(.1,width*Math.max(0,ctx[key])/max));}
      }
      for(let i=0;i<3;i++){const trophy=scene.getObjects('Trophy'+i)[0];if(trophy)trophy.setOpacity(num('Badges')>i?255:55);}
      const input=scene.getGame().getInputManager(),mx=input.getMouseX(),my=input.getMouseY();
      for(const b of ctx.buttons){const hover=mx>=b.x&&mx<=b.x+b.w&&my>=b.y&&my<=b.y+b.h;const busy=name==='Arena'&&phase>0&&['Attack','Shield','Heal'].includes(b.o.getName());b.o.setOpacity(busy?125:255);b.o.setPosition(b.x,b.y+(hover&&!busy?-2:0));}
      ctx.emission+=dt;
      if(ctx.emission>.45){ctx.emission=0;if(name==='Lab')emit('ParticleBubble',1090,338,1);else if(name==='Final')emit('ParticleSpark',180+Math.random()*920,210,3);else if(name==='Arena')emit('ParticleBubble',90+Math.random()*1100,510,1);}
      ctx.particles=ctx.particles.filter(p=>{
        p.age+=dt;if(p.age>=p.life){p.o.deleteFromScene(scene);return false;}
        if(p.projectile){const f=p.age/p.life;p.o.setPosition(340+570*f,375-Math.sin(f*Math.PI)*65);p.o.setAngle(30+f*360);}
        else{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=35*dt;p.o.setPosition(p.x,p.y);if(p.spin)p.o.setAngle(p.o.getAngle()+p.spin*dt);}
        p.o.setOpacity(255*Math.min(1,(p.life-p.age)/.3));return true;
      });
      syncMusic();
    }
    window.addEventListener('pagehide',()=>{if(music)music.pause();if(audioContext)audioContext.suspend().catch(()=>{});});
    return {tick,events,getMusic:()=>music,inspect:()=>({scene:scene?.getName(),phase:scene?sv('Phase'):0,particles:ctx?.particles.length||0,musicOn:scene?num('MusicOn'):0,track})};
  })();
}
globalThis.MonsterWorld.tick(runtimeScene);
};
gdjs.FinalCode.eventsList2 = function(runtimeScene) {

{


gdjs.FinalCode.userFunc0xad00a0(runtimeScene);

}


};gdjs.FinalCode.userFunc0xc42d20 = function GDJSInlineCode(runtimeScene) {
"use strict";
/* Teacher-owned adapter. Gameplay lives in visible GDevelop events, not here. */
if (!globalThis.MonsterProtocol) {
  globalThis.MonsterProtocol = (() => {
    let scene, model=null, panel=null, webcam=null, stream=null, running=false, session=0;
    let candidate='', since=0, neutralSince=0, armed=true, lastCommand=-Infinity;
    const allowed=['ATTACK','SHIELD','HEAL','IDLE'];
    const state=()=>scene.getGame().getVariables();
    const set=(n,v)=>typeof v==='string'?state().get(n).setString(v):state().get(n).setNumber(v);
    const get=n=>state().get(n).getAsNumber();
    const status=s=>{const el=document.getElementById('mp-status');if(el)el.textContent=s;};
    function resource(name) {
      const data=scene.getGame().getGameData().resources.resources.find(r=>r.name==='assets/'+name);
      if (!data) throw Error('Ресурс не найден: '+name);
      return scene.getGame().getResourceLoader().getFullUrl(data.file);
    }
    const loadScript=(name,globalName)=>new Promise((resolve,reject)=>{
      if(globalThis[globalName])return resolve();
      const s=document.createElement('script');s.src=resource(name);s.onload=resolve;s.onerror=()=>reject(Error('Не загружена локальная библиотека '+name));document.head.append(s);
    });
    async function libraries(){await loadScript('tf.min.js','tf');await loadScript('tm.min.js','tmImage');}
    function resetGate(){candidate='';since=0;neutralSince=0;armed=true;lastCommand=-Infinity;}
    function gate(predictions,now=performance.now()) {
      const top=predictions.reduce((a,b)=>a.probability>b.probability?a:b,{className:'IDLE',probability:0});
      const label=top.className;
      if(top.probability<.85 || label==='IDLE') {
        candidate='';
        if(!neutralSince)neutralSince=now;
        if(now-neutralSince>=400)armed=true;
        return 0;
      }
      neutralSince=0;
      if(candidate!==label){candidate=label;since=now;return 0;}
      if(!armed || now-since<500 || now-lastCommand<1500)return 0;
      armed=false;lastCommand=now;
      return {ATTACK:1,SHIELD:2,HEAL:3}[label]||0;
    }
    function stop(){session++;running=false;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;if(webcam){webcam.srcObject=null;webcam.remove();webcam=null;}set('AICommand',0);resetGate();status('Камера выключена. Кнопки игры доступны.');}
    function close(){stop();if(panel)panel.remove();panel=null;}
    function shell(title){
      close();panel=document.createElement('div');panel.id='mp-overlay';panel.setAttribute('role','dialog');panel.setAttribute('aria-label',title);
      panel.style.cssText='position:fixed;inset:0;z-index:99999;background:#100b20dd;display:grid;place-items:center;font:16px system-ui;color:#fff8ed';
      panel.innerHTML='<section style="background:#282039;border:1px solid #655276;border-radius:24px;padding:26px;width:min(680px,86vw);max-height:86vh;overflow:auto"><button id="mp-close" style="float:right">Закрыть ×</button><h2></h2><div id="mp-content"></div><p id="mp-status" role="status"></p></section>';
      panel.querySelector('h2').textContent=title;
      // The canvas must not receive clicks made on a modal control.
      for(const event of ['mousedown','mouseup','pointerdown','pointerup','touchstart','touchend'])panel.addEventListener(event,e=>e.stopPropagation());
      document.body.append(panel);panel.querySelector('#mp-close').onclick=close;
      return panel.querySelector('#mp-content');
    }
    function rename(){const root=shell('Имя твоего монстра');root.innerHTML='<label>Имя (до 24 символов)<br><input id="mp-name" maxlength="24" style="font:24px system-ui;padding:10px;margin:16px 0"></label><br><button id="mp-name-save">Готово</button>';
      root.querySelector('input').value=state().get('Name').getAsString();root.querySelector('button').onclick=()=>{const n=root.querySelector('input').value.trim();if(n){set('Name',n);close();}};
    }
    function validateLabels(m){const labels=m.getClassLabels();if(labels.length!==4||!allowed.every(n=>labels.includes(n)))throw Error('Нужны ровно 4 класса: ATTACK, SHIELD, HEAL, IDLE. Проверь регистр.');}
    async function replaceModel(next){try{validateLabels(next);}catch(e){next.model.dispose();throw e;}stop();if(model)model.model.dispose();model=next;status('Модель готова. Включи камеру; команды действуют только на арене.');}
    function missingFiles(files){
      const names=Array.from(files,f=>f.name);
      return ['model.json','metadata.json'].filter(n=>!names.includes(n));
    }
    async function loadLocal(files){const f=Array.from(files),find=n=>f.find(x=>x.name===n);const missing=missingFiles(f);if(missing.length)throw Error('Не хватает: '+missing.join(', ')+'. Нужен распакованный экспорт TensorFlow.js из Teachable Machine.');
      const meta=JSON.parse(await find('metadata.json').text());const spec=JSON.parse(await find('model.json').text());
      if(!Array.isArray(spec.weightsManifest)||!spec.modelTopology)throw Error('Этот JSON не похож на модель TensorFlow.js. game.json — проект GDevelop, а не файл ИИ.');
      const names=spec.weightsManifest.flatMap(g=>g.paths);const weights=names.map(n=>{const file=find(n);if(!file)throw Error('Не найден файл весов '+n);return file;});
      await libraries();
      const layers=await tf.loadLayersModel(tf.io.browserFiles([find('model.json'),...weights]));
      await replaceModel(new tmImage.CustomMobileNet(layers,meta));
    }
    async function demoModel(){await libraries();const response=await fetch(resource('demo-bundle.json'));if(!response.ok)throw Error('Не найден локальный комплект модели');const b=await response.json();const weightData=Uint8Array.from(atob(b.weightData),c=>c.charCodeAt(0)).buffer;const layers=await tf.loadLayersModel(tf.io.fromMemory(b.modelTopology,b.weightSpecs,weightData));await replaceModel(new tmImage.CustomMobileNet(layers,b.metadata));}
    async function start(){
      const openingPanel=panel;
      if(!model){
        status('Загружаем встроенную модель цветных карточек…');
        try{await demoModel();if(!panel||panel!==openingPanel)return;}catch(e){status('Не удалось загрузить встроенную модель: '+e.message);return;}
      }
      stop();const token=session;status('Разреши доступ к камере…');
      try{
        if(!navigator.mediaDevices?.getUserMedia)throw Error('Камере нужен localhost или HTTPS. Запусти START_WINDOWS.bat из распакованной папки.');
        const acquired=await navigator.mediaDevices.getUserMedia({video:{width:320,height:240,facingMode:'user'},audio:false});
        if(token!==session){acquired.getTracks().forEach(t=>t.stop());return;}
        stream=acquired;webcam=document.createElement('video');webcam.id='mp-video';webcam.autoplay=true;webcam.muted=true;webcam.playsInline=true;webcam.style.cssText='width:240px;border-radius:14px;transform:scaleX(-1)';webcam.srcObject=stream;
        document.getElementById('mp-video-box').append(webcam);await webcam.play();
        if(token!==session)return;running=true;resetGate();
        while(running&&token===session){
          const predictions=await model.predict(webcam,false);if(token!==session)break;
          const top=predictions.reduce((a,b)=>a.probability>b.probability?a:b);
          const command=gate(predictions);
          status(top.className+' · '+Math.round(top.probability*100)+'%'+(armed?' · готов':' · убери карточку / вернись в IDLE'));
          if(command&&scene.getName()==='Arena')set('AICommand',command);
          await new Promise(r=>setTimeout(r,100));
        }
      }catch(e){if(token===session){stop();const help={NotAllowedError:'Разреши камеру в настройках рядом с адресом браузера.',NotFoundError:'Камера не найдена. Проверь подключение.',NotReadableError:'Камера занята или недоступна. Закрой видеозвонки и попробуй снова.'};status(help[e.name]||('Камера или модель: '+e.message));}}
    }
    function camera(){const root=shell('Teachable Machine → команды игры');
      root.innerHTML='<p>Быстрый старт: нажми <b>«Включить камеру»</b>. Встроенная модель цветных карточек загрузится сама.</p><p>Для своей модели: 4 класса <b>ATTACK · SHIELD · HEAL · IDLE</b>. Добавь <b>model.json, metadata.json и все веса</b> из экспорта TensorFlow.js — вместе или по очереди. Выбранные файлы останутся в списке.</p><input id="mp-model-files" type="file" multiple accept=".json,.bin"><p><button id="mp-demo">Модель цветных карточек</button> <button id="mp-start">Включить камеру</button> <button id="mp-stop">Выключить камеру</button></p><p>Красная карточка — атака, синяя — щит, зелёная — лечение. Нейтральный серый фон — IDLE. Это модель цвета, а не распознавание рук. Удержи карточку 0,5 с, затем убери её.</p><div id="mp-video-box"></div><p id="mp-battle-state" style="padding:12px;background:#171122;border-radius:10px"></p><p>Оставь окно открытым на арене. Для перехода к кнопкам нажми «Закрыть»: камера выключится. Видео и файлы обрабатываются в этом браузере.</p>';
      const collected=new Map();
      const selection=document.createElement('p');selection.id='mp-selected-files';selection.textContent='Своя модель: файлы пока не добавлены.';root.querySelector('#mp-model-files').after(selection);
      root.querySelector('#mp-model-files').onchange=async e=>{
        for(const file of e.target.files)collected.set(file.name,file);
        selection.textContent='Добавлены: '+[...collected.keys()].join(', ');
        try{
          const files=[...collected.values()],missing=missingFiles(files);
          if(missing.length){status('Файлы добавлены. Теперь добавь: '+missing.join(', ')+', затем файл весов из той же папки. Можно выбирать по очереди.');return;}
          status('Проверяем комплект модели…');await loadLocal(files);
        }catch(err){status('Модель пока не загружена: '+err.message+' Добавь недостающий файл, уже выбранные сохранены.');}
      };
      root.querySelector('#mp-demo').onclick=async()=>{try{status('Загружаем локальную модель…');await demoModel();}catch(e){status('Модель не загружена: '+e.message);}};
      root.querySelector('#mp-start').onclick=start;root.querySelector('#mp-stop').onclick=stop;
      status(model?'Модель готова. Можно включить камеру.':'Для быстрого старта нажми «Включить камеру»: встроенная модель карточек загрузится автоматически. Для своей модели добавь model.json, metadata.json и веса — вместе или по очереди.');
    }
    const fields=['Name','Health','Energy','Strength','XP','Level','Wins','Round','Gold','RoomStyle','Badges',...['Body','Eyes','Mouth','Arms','Legs','Horns','Nose','Ears','Tail','Wings'].map(x=>x+'Variant')];
    const limits={Gold:[0,100000],RoomStyle:[0,2],Badges:[0,3],Health:[0,100],Energy:[0,100],Strength:[10,30],XP:[0,100000],Level:[1,33334],Wins:[0,3],Round:[1,3],BodyVariant:[0,5],EyesVariant:[0,7],MouthVariant:[0,5]};
    function save(){try{const values={};for(const n of fields)values[n]=n==='Name'?state().get(n).getAsString():get(n);localStorage.setItem('monster-protocol-v1',JSON.stringify({version:1,values}));set('Message','Сохранено в этом браузере. Для переноса копируй проект; эта запись не передаётся автоматически.');}catch{set('Message','Браузер запретил локальное сохранение. Сохрани проект в GDevelop.');}}
    function load(){try{const data=JSON.parse(localStorage.getItem('monster-protocol-v1'));if(data?.version!==1||!data.values)throw Error('Нет сохранения');for(const n of fields){const v=data.values[n]===undefined&&['Gold','RoomStyle','Badges'].includes(n)?get(n):data.values[n];data.values[n]=v;if(n==='Name'){if(typeof v!=='string'||!v.trim()||v.length>24)throw Error('Имя');}else{const [lo,hi]=limits[n]||[0,3];if(!Number.isFinite(v)||!Number.isInteger(v)||v<lo||v>hi)throw Error(n);}}for(const n of fields)set(n,data.values[n]);set('Message','Сохранение загружено.');}catch{set('Message','Корректное сохранение не найдено. Текущий монстр не изменён.');}}
    function tick(next){if(scene&&scene!==next&&panel)close();scene=next;
      const battle=document.getElementById('mp-battle-state');if(battle)battle.textContent='Раунд '+get('Round')+' / 3 · Соперник: '+get('EnemyHP')+' HP · Ты: '+get('Health')+' HP · Энергия: '+get('Energy')+' · '+state().get('Message').getAsString();
      for(const [key,fn] of [['NamePanel',rename],['AIPanel',camera],['SaveRequest',save],['LoadRequest',load]])if(get(key)){set(key,0);fn();}
    }
    window.addEventListener('pagehide',()=>{if(scene)stop();});
    return {tick,gate,resetGate,stop,close,loadLocal,demoModel,getScene:()=>scene,getModel:()=>model};
  })();
}
runtimeScene.getGame().enableMetrics(false);
globalThis.MonsterProtocol.tick(runtimeScene);
};
gdjs.FinalCode.eventsList3 = function(runtimeScene) {

{


gdjs.FinalCode.userFunc0xc42d20(runtimeScene);

}


};gdjs.FinalCode.eventsList4 = function(runtimeScene) {

{


gdjs.FinalCode.eventsList0(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Message"), gdjs.FinalCode.GDMessageObjects1);
{for(var i = 0, len = gdjs.FinalCode.GDMessageObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDMessageObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(24)));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Creator"), gdjs.FinalCode.GDCreatorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.FinalCode.mapOfGDgdjs_9546FinalCode_9546GDCreatorObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13811180);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MonsterCreator", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Camera"), gdjs.FinalCode.GDCameraObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.FinalCode.mapOfGDgdjs_9546FinalCode_9546GDCameraObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13812388);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(1);
}
}

}


{


gdjs.FinalCode.eventsList1(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NameText"), gdjs.FinalCode.GDNameTextObjects1);
{for(var i = 0, len = gdjs.FinalCode.GDNameTextObjects1.length ;i < len;++i) {
    gdjs.FinalCode.GDNameTextObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(10)));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Home"), gdjs.FinalCode.GDHomeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.FinalCode.mapOfGDgdjs_9546FinalCode_9546GDHomeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13817620);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Lab", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Again"), gdjs.FinalCode.GDAgainObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.FinalCode.mapOfGDgdjs_9546FinalCode_9546GDAgainObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13818780);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(16).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(17).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(100);
}
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(60);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(10);
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Новое приключение. Дом, награды и внешность сохранились.");
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Lab", false);
}
}

}


{


gdjs.FinalCode.eventsList2(runtimeScene);
}


{


gdjs.FinalCode.eventsList3(runtimeScene);
}


};

gdjs.FinalCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.FinalCode.GDBackdropObjects1.length = 0;
gdjs.FinalCode.GDBackdropObjects2.length = 0;
gdjs.FinalCode.GDBackdropObjects3.length = 0;
gdjs.FinalCode.GDBrandObjects1.length = 0;
gdjs.FinalCode.GDBrandObjects2.length = 0;
gdjs.FinalCode.GDBrandObjects3.length = 0;
gdjs.FinalCode.GDEditionObjects1.length = 0;
gdjs.FinalCode.GDEditionObjects2.length = 0;
gdjs.FinalCode.GDEditionObjects3.length = 0;
gdjs.FinalCode.GDTitleObjects1.length = 0;
gdjs.FinalCode.GDTitleObjects2.length = 0;
gdjs.FinalCode.GDTitleObjects3.length = 0;
gdjs.FinalCode.GDKickerObjects1.length = 0;
gdjs.FinalCode.GDKickerObjects2.length = 0;
gdjs.FinalCode.GDKickerObjects3.length = 0;
gdjs.FinalCode.GDHeaderShadeObjects1.length = 0;
gdjs.FinalCode.GDHeaderShadeObjects2.length = 0;
gdjs.FinalCode.GDHeaderShadeObjects3.length = 0;
gdjs.FinalCode.GDMusicObjects1.length = 0;
gdjs.FinalCode.GDMusicObjects2.length = 0;
gdjs.FinalCode.GDMusicObjects3.length = 0;
gdjs.FinalCode.GDMusicLabelObjects1.length = 0;
gdjs.FinalCode.GDMusicLabelObjects2.length = 0;
gdjs.FinalCode.GDMusicLabelObjects3.length = 0;
gdjs.FinalCode.GDParticleSparkObjects1.length = 0;
gdjs.FinalCode.GDParticleSparkObjects2.length = 0;
gdjs.FinalCode.GDParticleSparkObjects3.length = 0;
gdjs.FinalCode.GDParticleHeartObjects1.length = 0;
gdjs.FinalCode.GDParticleHeartObjects2.length = 0;
gdjs.FinalCode.GDParticleHeartObjects3.length = 0;
gdjs.FinalCode.GDParticleBubbleObjects1.length = 0;
gdjs.FinalCode.GDParticleBubbleObjects2.length = 0;
gdjs.FinalCode.GDParticleBubbleObjects3.length = 0;
gdjs.FinalCode.GDProjectileObjects1.length = 0;
gdjs.FinalCode.GDProjectileObjects2.length = 0;
gdjs.FinalCode.GDProjectileObjects3.length = 0;
gdjs.FinalCode.GDFloatingNumberObjects1.length = 0;
gdjs.FinalCode.GDFloatingNumberObjects2.length = 0;
gdjs.FinalCode.GDFloatingNumberObjects3.length = 0;
gdjs.FinalCode.GDShieldHaloObjects1.length = 0;
gdjs.FinalCode.GDShieldHaloObjects2.length = 0;
gdjs.FinalCode.GDShieldHaloObjects3.length = 0;
gdjs.FinalCode.GDMessagePanelObjects1.length = 0;
gdjs.FinalCode.GDMessagePanelObjects2.length = 0;
gdjs.FinalCode.GDMessagePanelObjects3.length = 0;
gdjs.FinalCode.GDMessageObjects1.length = 0;
gdjs.FinalCode.GDMessageObjects2.length = 0;
gdjs.FinalCode.GDMessageObjects3.length = 0;
gdjs.FinalCode.GDCreatorObjects1.length = 0;
gdjs.FinalCode.GDCreatorObjects2.length = 0;
gdjs.FinalCode.GDCreatorObjects3.length = 0;
gdjs.FinalCode.GDCreatorLabelObjects1.length = 0;
gdjs.FinalCode.GDCreatorLabelObjects2.length = 0;
gdjs.FinalCode.GDCreatorLabelObjects3.length = 0;
gdjs.FinalCode.GDCameraObjects1.length = 0;
gdjs.FinalCode.GDCameraObjects2.length = 0;
gdjs.FinalCode.GDCameraObjects3.length = 0;
gdjs.FinalCode.GDCameraLabelObjects1.length = 0;
gdjs.FinalCode.GDCameraLabelObjects2.length = 0;
gdjs.FinalCode.GDCameraLabelObjects3.length = 0;
gdjs.FinalCode.GDMonsterBodyObjects1.length = 0;
gdjs.FinalCode.GDMonsterBodyObjects2.length = 0;
gdjs.FinalCode.GDMonsterBodyObjects3.length = 0;
gdjs.FinalCode.GDMonsterEyesObjects1.length = 0;
gdjs.FinalCode.GDMonsterEyesObjects2.length = 0;
gdjs.FinalCode.GDMonsterEyesObjects3.length = 0;
gdjs.FinalCode.GDMonsterMouthObjects1.length = 0;
gdjs.FinalCode.GDMonsterMouthObjects2.length = 0;
gdjs.FinalCode.GDMonsterMouthObjects3.length = 0;
gdjs.FinalCode.GDMonsterArmsObjects1.length = 0;
gdjs.FinalCode.GDMonsterArmsObjects2.length = 0;
gdjs.FinalCode.GDMonsterArmsObjects3.length = 0;
gdjs.FinalCode.GDMonsterLegsObjects1.length = 0;
gdjs.FinalCode.GDMonsterLegsObjects2.length = 0;
gdjs.FinalCode.GDMonsterLegsObjects3.length = 0;
gdjs.FinalCode.GDMonsterHornsObjects1.length = 0;
gdjs.FinalCode.GDMonsterHornsObjects2.length = 0;
gdjs.FinalCode.GDMonsterHornsObjects3.length = 0;
gdjs.FinalCode.GDMonsterNoseObjects1.length = 0;
gdjs.FinalCode.GDMonsterNoseObjects2.length = 0;
gdjs.FinalCode.GDMonsterNoseObjects3.length = 0;
gdjs.FinalCode.GDMonsterEarsObjects1.length = 0;
gdjs.FinalCode.GDMonsterEarsObjects2.length = 0;
gdjs.FinalCode.GDMonsterEarsObjects3.length = 0;
gdjs.FinalCode.GDMonsterTailObjects1.length = 0;
gdjs.FinalCode.GDMonsterTailObjects2.length = 0;
gdjs.FinalCode.GDMonsterTailObjects3.length = 0;
gdjs.FinalCode.GDMonsterWingsObjects1.length = 0;
gdjs.FinalCode.GDMonsterWingsObjects2.length = 0;
gdjs.FinalCode.GDMonsterWingsObjects3.length = 0;
gdjs.FinalCode.GDGrandTrophyObjects1.length = 0;
gdjs.FinalCode.GDGrandTrophyObjects2.length = 0;
gdjs.FinalCode.GDGrandTrophyObjects3.length = 0;
gdjs.FinalCode.GDNameTextObjects1.length = 0;
gdjs.FinalCode.GDNameTextObjects2.length = 0;
gdjs.FinalCode.GDNameTextObjects3.length = 0;
gdjs.FinalCode.GDBadgeObjects1.length = 0;
gdjs.FinalCode.GDBadgeObjects2.length = 0;
gdjs.FinalCode.GDBadgeObjects3.length = 0;
gdjs.FinalCode.GDFinalTextObjects1.length = 0;
gdjs.FinalCode.GDFinalTextObjects2.length = 0;
gdjs.FinalCode.GDFinalTextObjects3.length = 0;
gdjs.FinalCode.GDAgainObjects1.length = 0;
gdjs.FinalCode.GDAgainObjects2.length = 0;
gdjs.FinalCode.GDAgainObjects3.length = 0;
gdjs.FinalCode.GDAgainLabelObjects1.length = 0;
gdjs.FinalCode.GDAgainLabelObjects2.length = 0;
gdjs.FinalCode.GDAgainLabelObjects3.length = 0;
gdjs.FinalCode.GDHomeObjects1.length = 0;
gdjs.FinalCode.GDHomeObjects2.length = 0;
gdjs.FinalCode.GDHomeObjects3.length = 0;
gdjs.FinalCode.GDHomeLabelObjects1.length = 0;
gdjs.FinalCode.GDHomeLabelObjects2.length = 0;
gdjs.FinalCode.GDHomeLabelObjects3.length = 0;

gdjs.FinalCode.eventsList4(runtimeScene);
gdjs.FinalCode.GDBackdropObjects1.length = 0;
gdjs.FinalCode.GDBackdropObjects2.length = 0;
gdjs.FinalCode.GDBackdropObjects3.length = 0;
gdjs.FinalCode.GDBrandObjects1.length = 0;
gdjs.FinalCode.GDBrandObjects2.length = 0;
gdjs.FinalCode.GDBrandObjects3.length = 0;
gdjs.FinalCode.GDEditionObjects1.length = 0;
gdjs.FinalCode.GDEditionObjects2.length = 0;
gdjs.FinalCode.GDEditionObjects3.length = 0;
gdjs.FinalCode.GDTitleObjects1.length = 0;
gdjs.FinalCode.GDTitleObjects2.length = 0;
gdjs.FinalCode.GDTitleObjects3.length = 0;
gdjs.FinalCode.GDKickerObjects1.length = 0;
gdjs.FinalCode.GDKickerObjects2.length = 0;
gdjs.FinalCode.GDKickerObjects3.length = 0;
gdjs.FinalCode.GDHeaderShadeObjects1.length = 0;
gdjs.FinalCode.GDHeaderShadeObjects2.length = 0;
gdjs.FinalCode.GDHeaderShadeObjects3.length = 0;
gdjs.FinalCode.GDMusicObjects1.length = 0;
gdjs.FinalCode.GDMusicObjects2.length = 0;
gdjs.FinalCode.GDMusicObjects3.length = 0;
gdjs.FinalCode.GDMusicLabelObjects1.length = 0;
gdjs.FinalCode.GDMusicLabelObjects2.length = 0;
gdjs.FinalCode.GDMusicLabelObjects3.length = 0;
gdjs.FinalCode.GDParticleSparkObjects1.length = 0;
gdjs.FinalCode.GDParticleSparkObjects2.length = 0;
gdjs.FinalCode.GDParticleSparkObjects3.length = 0;
gdjs.FinalCode.GDParticleHeartObjects1.length = 0;
gdjs.FinalCode.GDParticleHeartObjects2.length = 0;
gdjs.FinalCode.GDParticleHeartObjects3.length = 0;
gdjs.FinalCode.GDParticleBubbleObjects1.length = 0;
gdjs.FinalCode.GDParticleBubbleObjects2.length = 0;
gdjs.FinalCode.GDParticleBubbleObjects3.length = 0;
gdjs.FinalCode.GDProjectileObjects1.length = 0;
gdjs.FinalCode.GDProjectileObjects2.length = 0;
gdjs.FinalCode.GDProjectileObjects3.length = 0;
gdjs.FinalCode.GDFloatingNumberObjects1.length = 0;
gdjs.FinalCode.GDFloatingNumberObjects2.length = 0;
gdjs.FinalCode.GDFloatingNumberObjects3.length = 0;
gdjs.FinalCode.GDShieldHaloObjects1.length = 0;
gdjs.FinalCode.GDShieldHaloObjects2.length = 0;
gdjs.FinalCode.GDShieldHaloObjects3.length = 0;
gdjs.FinalCode.GDMessagePanelObjects1.length = 0;
gdjs.FinalCode.GDMessagePanelObjects2.length = 0;
gdjs.FinalCode.GDMessagePanelObjects3.length = 0;
gdjs.FinalCode.GDMessageObjects1.length = 0;
gdjs.FinalCode.GDMessageObjects2.length = 0;
gdjs.FinalCode.GDMessageObjects3.length = 0;
gdjs.FinalCode.GDCreatorObjects1.length = 0;
gdjs.FinalCode.GDCreatorObjects2.length = 0;
gdjs.FinalCode.GDCreatorObjects3.length = 0;
gdjs.FinalCode.GDCreatorLabelObjects1.length = 0;
gdjs.FinalCode.GDCreatorLabelObjects2.length = 0;
gdjs.FinalCode.GDCreatorLabelObjects3.length = 0;
gdjs.FinalCode.GDCameraObjects1.length = 0;
gdjs.FinalCode.GDCameraObjects2.length = 0;
gdjs.FinalCode.GDCameraObjects3.length = 0;
gdjs.FinalCode.GDCameraLabelObjects1.length = 0;
gdjs.FinalCode.GDCameraLabelObjects2.length = 0;
gdjs.FinalCode.GDCameraLabelObjects3.length = 0;
gdjs.FinalCode.GDMonsterBodyObjects1.length = 0;
gdjs.FinalCode.GDMonsterBodyObjects2.length = 0;
gdjs.FinalCode.GDMonsterBodyObjects3.length = 0;
gdjs.FinalCode.GDMonsterEyesObjects1.length = 0;
gdjs.FinalCode.GDMonsterEyesObjects2.length = 0;
gdjs.FinalCode.GDMonsterEyesObjects3.length = 0;
gdjs.FinalCode.GDMonsterMouthObjects1.length = 0;
gdjs.FinalCode.GDMonsterMouthObjects2.length = 0;
gdjs.FinalCode.GDMonsterMouthObjects3.length = 0;
gdjs.FinalCode.GDMonsterArmsObjects1.length = 0;
gdjs.FinalCode.GDMonsterArmsObjects2.length = 0;
gdjs.FinalCode.GDMonsterArmsObjects3.length = 0;
gdjs.FinalCode.GDMonsterLegsObjects1.length = 0;
gdjs.FinalCode.GDMonsterLegsObjects2.length = 0;
gdjs.FinalCode.GDMonsterLegsObjects3.length = 0;
gdjs.FinalCode.GDMonsterHornsObjects1.length = 0;
gdjs.FinalCode.GDMonsterHornsObjects2.length = 0;
gdjs.FinalCode.GDMonsterHornsObjects3.length = 0;
gdjs.FinalCode.GDMonsterNoseObjects1.length = 0;
gdjs.FinalCode.GDMonsterNoseObjects2.length = 0;
gdjs.FinalCode.GDMonsterNoseObjects3.length = 0;
gdjs.FinalCode.GDMonsterEarsObjects1.length = 0;
gdjs.FinalCode.GDMonsterEarsObjects2.length = 0;
gdjs.FinalCode.GDMonsterEarsObjects3.length = 0;
gdjs.FinalCode.GDMonsterTailObjects1.length = 0;
gdjs.FinalCode.GDMonsterTailObjects2.length = 0;
gdjs.FinalCode.GDMonsterTailObjects3.length = 0;
gdjs.FinalCode.GDMonsterWingsObjects1.length = 0;
gdjs.FinalCode.GDMonsterWingsObjects2.length = 0;
gdjs.FinalCode.GDMonsterWingsObjects3.length = 0;
gdjs.FinalCode.GDGrandTrophyObjects1.length = 0;
gdjs.FinalCode.GDGrandTrophyObjects2.length = 0;
gdjs.FinalCode.GDGrandTrophyObjects3.length = 0;
gdjs.FinalCode.GDNameTextObjects1.length = 0;
gdjs.FinalCode.GDNameTextObjects2.length = 0;
gdjs.FinalCode.GDNameTextObjects3.length = 0;
gdjs.FinalCode.GDBadgeObjects1.length = 0;
gdjs.FinalCode.GDBadgeObjects2.length = 0;
gdjs.FinalCode.GDBadgeObjects3.length = 0;
gdjs.FinalCode.GDFinalTextObjects1.length = 0;
gdjs.FinalCode.GDFinalTextObjects2.length = 0;
gdjs.FinalCode.GDFinalTextObjects3.length = 0;
gdjs.FinalCode.GDAgainObjects1.length = 0;
gdjs.FinalCode.GDAgainObjects2.length = 0;
gdjs.FinalCode.GDAgainObjects3.length = 0;
gdjs.FinalCode.GDAgainLabelObjects1.length = 0;
gdjs.FinalCode.GDAgainLabelObjects2.length = 0;
gdjs.FinalCode.GDAgainLabelObjects3.length = 0;
gdjs.FinalCode.GDHomeObjects1.length = 0;
gdjs.FinalCode.GDHomeObjects2.length = 0;
gdjs.FinalCode.GDHomeObjects3.length = 0;
gdjs.FinalCode.GDHomeLabelObjects1.length = 0;
gdjs.FinalCode.GDHomeLabelObjects2.length = 0;
gdjs.FinalCode.GDHomeLabelObjects3.length = 0;


return;

}

gdjs['FinalCode'] = gdjs.FinalCode;

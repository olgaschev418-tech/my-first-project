gdjs.LabCode = {};
gdjs.LabCode.localVariables = [];
gdjs.LabCode.idToCallbackMap = new Map();
gdjs.LabCode.GDBackdropObjects1= [];
gdjs.LabCode.GDBackdropObjects2= [];
gdjs.LabCode.GDBackdropObjects3= [];
gdjs.LabCode.GDBrandObjects1= [];
gdjs.LabCode.GDBrandObjects2= [];
gdjs.LabCode.GDBrandObjects3= [];
gdjs.LabCode.GDEditionObjects1= [];
gdjs.LabCode.GDEditionObjects2= [];
gdjs.LabCode.GDEditionObjects3= [];
gdjs.LabCode.GDTitleObjects1= [];
gdjs.LabCode.GDTitleObjects2= [];
gdjs.LabCode.GDTitleObjects3= [];
gdjs.LabCode.GDKickerObjects1= [];
gdjs.LabCode.GDKickerObjects2= [];
gdjs.LabCode.GDKickerObjects3= [];
gdjs.LabCode.GDHeaderShadeObjects1= [];
gdjs.LabCode.GDHeaderShadeObjects2= [];
gdjs.LabCode.GDHeaderShadeObjects3= [];
gdjs.LabCode.GDMusicObjects1= [];
gdjs.LabCode.GDMusicObjects2= [];
gdjs.LabCode.GDMusicObjects3= [];
gdjs.LabCode.GDMusicLabelObjects1= [];
gdjs.LabCode.GDMusicLabelObjects2= [];
gdjs.LabCode.GDMusicLabelObjects3= [];
gdjs.LabCode.GDParticleSparkObjects1= [];
gdjs.LabCode.GDParticleSparkObjects2= [];
gdjs.LabCode.GDParticleSparkObjects3= [];
gdjs.LabCode.GDParticleHeartObjects1= [];
gdjs.LabCode.GDParticleHeartObjects2= [];
gdjs.LabCode.GDParticleHeartObjects3= [];
gdjs.LabCode.GDParticleBubbleObjects1= [];
gdjs.LabCode.GDParticleBubbleObjects2= [];
gdjs.LabCode.GDParticleBubbleObjects3= [];
gdjs.LabCode.GDProjectileObjects1= [];
gdjs.LabCode.GDProjectileObjects2= [];
gdjs.LabCode.GDProjectileObjects3= [];
gdjs.LabCode.GDFloatingNumberObjects1= [];
gdjs.LabCode.GDFloatingNumberObjects2= [];
gdjs.LabCode.GDFloatingNumberObjects3= [];
gdjs.LabCode.GDShieldHaloObjects1= [];
gdjs.LabCode.GDShieldHaloObjects2= [];
gdjs.LabCode.GDShieldHaloObjects3= [];
gdjs.LabCode.GDMessagePanelObjects1= [];
gdjs.LabCode.GDMessagePanelObjects2= [];
gdjs.LabCode.GDMessagePanelObjects3= [];
gdjs.LabCode.GDMessageObjects1= [];
gdjs.LabCode.GDMessageObjects2= [];
gdjs.LabCode.GDMessageObjects3= [];
gdjs.LabCode.GDCreatorObjects1= [];
gdjs.LabCode.GDCreatorObjects2= [];
gdjs.LabCode.GDCreatorObjects3= [];
gdjs.LabCode.GDCreatorLabelObjects1= [];
gdjs.LabCode.GDCreatorLabelObjects2= [];
gdjs.LabCode.GDCreatorLabelObjects3= [];
gdjs.LabCode.GDCameraObjects1= [];
gdjs.LabCode.GDCameraObjects2= [];
gdjs.LabCode.GDCameraObjects3= [];
gdjs.LabCode.GDCameraLabelObjects1= [];
gdjs.LabCode.GDCameraLabelObjects2= [];
gdjs.LabCode.GDCameraLabelObjects3= [];
gdjs.LabCode.GDPlayerHUDObjects1= [];
gdjs.LabCode.GDPlayerHUDObjects2= [];
gdjs.LabCode.GDPlayerHUDObjects3= [];
gdjs.LabCode.GDPlayerNameObjects1= [];
gdjs.LabCode.GDPlayerNameObjects2= [];
gdjs.LabCode.GDPlayerNameObjects3= [];
gdjs.LabCode.GDHealthTrackObjects1= [];
gdjs.LabCode.GDHealthTrackObjects2= [];
gdjs.LabCode.GDHealthTrackObjects3= [];
gdjs.LabCode.GDHealthBarObjects1= [];
gdjs.LabCode.GDHealthBarObjects2= [];
gdjs.LabCode.GDHealthBarObjects3= [];
gdjs.LabCode.GDHealthValueObjects1= [];
gdjs.LabCode.GDHealthValueObjects2= [];
gdjs.LabCode.GDHealthValueObjects3= [];
gdjs.LabCode.GDEnergyTrackObjects1= [];
gdjs.LabCode.GDEnergyTrackObjects2= [];
gdjs.LabCode.GDEnergyTrackObjects3= [];
gdjs.LabCode.GDEnergyBarObjects1= [];
gdjs.LabCode.GDEnergyBarObjects2= [];
gdjs.LabCode.GDEnergyBarObjects3= [];
gdjs.LabCode.GDEnergyValueObjects1= [];
gdjs.LabCode.GDEnergyValueObjects2= [];
gdjs.LabCode.GDEnergyValueObjects3= [];
gdjs.LabCode.GDResearchHUDObjects1= [];
gdjs.LabCode.GDResearchHUDObjects2= [];
gdjs.LabCode.GDResearchHUDObjects3= [];
gdjs.LabCode.GDStatsObjects1= [];
gdjs.LabCode.GDStatsObjects2= [];
gdjs.LabCode.GDStatsObjects3= [];
gdjs.LabCode.GDMonsterBodyObjects1= [];
gdjs.LabCode.GDMonsterBodyObjects2= [];
gdjs.LabCode.GDMonsterBodyObjects3= [];
gdjs.LabCode.GDMonsterEyesObjects1= [];
gdjs.LabCode.GDMonsterEyesObjects2= [];
gdjs.LabCode.GDMonsterEyesObjects3= [];
gdjs.LabCode.GDMonsterMouthObjects1= [];
gdjs.LabCode.GDMonsterMouthObjects2= [];
gdjs.LabCode.GDMonsterMouthObjects3= [];
gdjs.LabCode.GDMonsterArmsObjects1= [];
gdjs.LabCode.GDMonsterArmsObjects2= [];
gdjs.LabCode.GDMonsterArmsObjects3= [];
gdjs.LabCode.GDMonsterLegsObjects1= [];
gdjs.LabCode.GDMonsterLegsObjects2= [];
gdjs.LabCode.GDMonsterLegsObjects3= [];
gdjs.LabCode.GDMonsterHornsObjects1= [];
gdjs.LabCode.GDMonsterHornsObjects2= [];
gdjs.LabCode.GDMonsterHornsObjects3= [];
gdjs.LabCode.GDMonsterNoseObjects1= [];
gdjs.LabCode.GDMonsterNoseObjects2= [];
gdjs.LabCode.GDMonsterNoseObjects3= [];
gdjs.LabCode.GDMonsterEarsObjects1= [];
gdjs.LabCode.GDMonsterEarsObjects2= [];
gdjs.LabCode.GDMonsterEarsObjects3= [];
gdjs.LabCode.GDMonsterTailObjects1= [];
gdjs.LabCode.GDMonsterTailObjects2= [];
gdjs.LabCode.GDMonsterTailObjects3= [];
gdjs.LabCode.GDMonsterWingsObjects1= [];
gdjs.LabCode.GDMonsterWingsObjects2= [];
gdjs.LabCode.GDMonsterWingsObjects3= [];
gdjs.LabCode.GDNameTextObjects1= [];
gdjs.LabCode.GDNameTextObjects2= [];
gdjs.LabCode.GDNameTextObjects3= [];
gdjs.LabCode.GDFoodBowlObjects1= [];
gdjs.LabCode.GDFoodBowlObjects2= [];
gdjs.LabCode.GDFoodBowlObjects3= [];
gdjs.LabCode.GDGiftObjects1= [];
gdjs.LabCode.GDGiftObjects2= [];
gdjs.LabCode.GDGiftObjects3= [];
gdjs.LabCode.GDAdventurePanelObjects1= [];
gdjs.LabCode.GDAdventurePanelObjects2= [];
gdjs.LabCode.GDAdventurePanelObjects3= [];
gdjs.LabCode.GDAdventureHintObjects1= [];
gdjs.LabCode.GDAdventureHintObjects2= [];
gdjs.LabCode.GDAdventureHintObjects3= [];
gdjs.LabCode.GDRoomCaptionObjects1= [];
gdjs.LabCode.GDRoomCaptionObjects2= [];
gdjs.LabCode.GDRoomCaptionObjects3= [];
gdjs.LabCode.GDTrophy0Objects1= [];
gdjs.LabCode.GDTrophy0Objects2= [];
gdjs.LabCode.GDTrophy0Objects3= [];
gdjs.LabCode.GDTrophy1Objects1= [];
gdjs.LabCode.GDTrophy1Objects2= [];
gdjs.LabCode.GDTrophy1Objects3= [];
gdjs.LabCode.GDTrophy2Objects1= [];
gdjs.LabCode.GDTrophy2Objects2= [];
gdjs.LabCode.GDTrophy2Objects3= [];
gdjs.LabCode.GDTrophiesHintObjects1= [];
gdjs.LabCode.GDTrophiesHintObjects2= [];
gdjs.LabCode.GDTrophiesHintObjects3= [];
gdjs.LabCode.GDFeedObjects1= [];
gdjs.LabCode.GDFeedObjects2= [];
gdjs.LabCode.GDFeedObjects3= [];
gdjs.LabCode.GDFeedLabelObjects1= [];
gdjs.LabCode.GDFeedLabelObjects2= [];
gdjs.LabCode.GDFeedLabelObjects3= [];
gdjs.LabCode.GDTrainObjects1= [];
gdjs.LabCode.GDTrainObjects2= [];
gdjs.LabCode.GDTrainObjects3= [];
gdjs.LabCode.GDTrainLabelObjects1= [];
gdjs.LabCode.GDTrainLabelObjects2= [];
gdjs.LabCode.GDTrainLabelObjects3= [];
gdjs.LabCode.GDRestObjects1= [];
gdjs.LabCode.GDRestObjects2= [];
gdjs.LabCode.GDRestObjects3= [];
gdjs.LabCode.GDRestLabelObjects1= [];
gdjs.LabCode.GDRestLabelObjects2= [];
gdjs.LabCode.GDRestLabelObjects3= [];
gdjs.LabCode.GDDecorObjects1= [];
gdjs.LabCode.GDDecorObjects2= [];
gdjs.LabCode.GDDecorObjects3= [];
gdjs.LabCode.GDDecorLabelObjects1= [];
gdjs.LabCode.GDDecorLabelObjects2= [];
gdjs.LabCode.GDDecorLabelObjects3= [];
gdjs.LabCode.GDBattleObjects1= [];
gdjs.LabCode.GDBattleObjects2= [];
gdjs.LabCode.GDBattleObjects3= [];
gdjs.LabCode.GDBattleLabelObjects1= [];
gdjs.LabCode.GDBattleLabelObjects2= [];
gdjs.LabCode.GDBattleLabelObjects3= [];


gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDMusicObjects2Objects = Hashtable.newFrom({"Music": gdjs.LabCode.GDMusicObjects2});
gdjs.LabCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Music"), gdjs.LabCode.GDMusicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDMusicObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13320900);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(28).setNumber(1 - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(28)));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(28)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MusicLabel"), gdjs.LabCode.GDMusicLabelObjects2);
{for(var i = 0, len = gdjs.LabCode.GDMusicLabelObjects2.length ;i < len;++i) {
    gdjs.LabCode.GDMusicLabelObjects2[i].setString("Звук: выкл");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(28)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MusicLabel"), gdjs.LabCode.GDMusicLabelObjects1);
{for(var i = 0, len = gdjs.LabCode.GDMusicLabelObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDMusicLabelObjects1[i].setString("Звук: вкл");
}
}
}

}


};gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDCreatorObjects1Objects = Hashtable.newFrom({"Creator": gdjs.LabCode.GDCreatorObjects1});
gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDCameraObjects1Objects = Hashtable.newFrom({"Camera": gdjs.LabCode.GDCameraObjects1});
gdjs.LabCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MonsterArms"), gdjs.LabCode.GDMonsterArmsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterBody"), gdjs.LabCode.GDMonsterBodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterEars"), gdjs.LabCode.GDMonsterEarsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterEyes"), gdjs.LabCode.GDMonsterEyesObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterHorns"), gdjs.LabCode.GDMonsterHornsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterLegs"), gdjs.LabCode.GDMonsterLegsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterMouth"), gdjs.LabCode.GDMonsterMouthObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterNose"), gdjs.LabCode.GDMonsterNoseObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterTail"), gdjs.LabCode.GDMonsterTailObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterWings"), gdjs.LabCode.GDMonsterWingsObjects1);
{for(var i = 0, len = gdjs.LabCode.GDMonsterBodyObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDMonsterBodyObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}
{for(var i = 0, len = gdjs.LabCode.GDMonsterEyesObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDMonsterEyesObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}
{for(var i = 0, len = gdjs.LabCode.GDMonsterMouthObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDMonsterMouthObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}
{for(var i = 0, len = gdjs.LabCode.GDMonsterArmsObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDMonsterArmsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
}
{for(var i = 0, len = gdjs.LabCode.GDMonsterLegsObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDMonsterLegsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}
{for(var i = 0, len = gdjs.LabCode.GDMonsterHornsObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDMonsterHornsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)));
}
}
{for(var i = 0, len = gdjs.LabCode.GDMonsterNoseObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDMonsterNoseObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)));
}
}
{for(var i = 0, len = gdjs.LabCode.GDMonsterEarsObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDMonsterEarsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)));
}
}
{for(var i = 0, len = gdjs.LabCode.GDMonsterTailObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDMonsterTailObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)));
}
}
{for(var i = 0, len = gdjs.LabCode.GDMonsterWingsObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDMonsterWingsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)));
}
}
}

}


};gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDMonsterBodyObjects1Objects = Hashtable.newFrom({"MonsterBody": gdjs.LabCode.GDMonsterBodyObjects1});
gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDFeedObjects2Objects = Hashtable.newFrom({"Feed": gdjs.LabCode.GDFeedObjects2});
gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDFoodBowlObjects2Objects = Hashtable.newFrom({"FoodBowl": gdjs.LabCode.GDFoodBowlObjects2});
gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDRestObjects2Objects = Hashtable.newFrom({"Rest": gdjs.LabCode.GDRestObjects2});
gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDTrainObjects2Objects = Hashtable.newFrom({"Train": gdjs.LabCode.GDTrainObjects2});
gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDTrainObjects2Objects = Hashtable.newFrom({"Train": gdjs.LabCode.GDTrainObjects2});
gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDDecorObjects2Objects = Hashtable.newFrom({"Decor": gdjs.LabCode.GDDecorObjects2});
gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDDecorObjects2Objects = Hashtable.newFrom({"Decor": gdjs.LabCode.GDDecorObjects2});
gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDDecorObjects2Objects = Hashtable.newFrom({"Decor": gdjs.LabCode.GDDecorObjects2});
gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDGiftObjects2Objects = Hashtable.newFrom({"Gift": gdjs.LabCode.GDGiftObjects2});
gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDBattleObjects1Objects = Hashtable.newFrom({"Battle": gdjs.LabCode.GDBattleObjects1});
gdjs.LabCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Feed"), gdjs.LabCode.GDFeedObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDFeedObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13335436);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(Math.min(100, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) + 20));
}
{runtimeScene.getGame().getVariables().getFromIndex(29).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Ням! +20 энергии. Крошки и счастье разлетаются во все стороны.");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("FoodBowl"), gdjs.LabCode.GDFoodBowlObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDFoodBowlObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13337236);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(Math.min(100, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) + 20));
}
{runtimeScene.getGame().getVariables().getFromIndex(29).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Миска тоже работает! Монстрик рад угощению.");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rest"), gdjs.LabCode.GDRestObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDRestObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13339052);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(100);
}
{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(100);
}
{runtimeScene.getGame().getVariables().getFromIndex(29).setNumber(3);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Тихий час: здоровье и энергия полностью восстановлены.");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Train"), gdjs.LabCode.GDTrainObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDTrainObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13341028);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) < 20;
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(29).setNumber(6);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Для тренировки нужно 20 энергии. Загляни в миску или отдохни.");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Train"), gdjs.LabCode.GDTrainObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDTrainObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13342708);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) >= 20;
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) - 20);
}
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(Math.min(30, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(13)) + 4));
}
{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) + 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(1 + Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(14)) / 3));
}
{runtimeScene.getGame().getVariables().getFromIndex(29).setNumber(2);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Прыг! +4 силы. Каждые три тренировки дают новый уровень.");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Decor"), gdjs.LabCode.GDDecorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDDecorObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13345540);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(26)) < 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(25)) < 20;
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(29).setNumber(6);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Улучшение стоит 20 звёзд. Победи хранителя и забери награду!");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Decor"), gdjs.LabCode.GDDecorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDDecorObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13347452);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(26)) >= 2;
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(30).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Дом уже полностью обустроен. Теперь можно придумать собственные украшения!");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Decor"), gdjs.LabCode.GDDecorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDDecorObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13349164);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(26)) < 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(25)) >= 20;
}
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(25).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(25)) - 20);
}
{runtimeScene.getGame().getVariables().getFromIndex(26).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(26)) + 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(29).setNumber(4);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("В доме новое оборудование! Награды делают его по-настоящему твоим.");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gift"), gdjs.LabCode.GDGiftObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDGiftObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13351620);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(30).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("В коробке — воображение. Придумай своему монстрику новую способность!");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Battle"), gdjs.LabCode.GDBattleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDBattleObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13353228);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) < 3;
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(17).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) + 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(40 + 20 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)));
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Хранитель ждёт. Красный знак предупреждает об усиленном ответе — ставь щит!");
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Arena", false);
}
}

}


};gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDBattleObjects1Objects = Hashtable.newFrom({"Battle": gdjs.LabCode.GDBattleObjects1});
gdjs.LabCode.userFunc0xc41eb0 = function GDJSInlineCode(runtimeScene) {
"use strict";
/* Ready-made visual/audio kit. All health, energy, rewards and turn rules are native events. */
if (!globalThis.MonsterWorld) {
  globalThis.MonsterWorld = (() => {
    let scene,ctx,music=null,track='',audioContext=null,unlocked=false;
    const events=[];
    const record=(type,detail={})=>{events.push({type,...detail});if(events.length>40)events.shift();};
    const vars=()=>scene.getGame().getVariables();
    const num=n=>vars().get(n).getAsNumber();
    const sv=n=>scene.getVariables().get(n).getAsNumber();
    const resource=name=>{const r=scene.getGame().getGameData().resources.resources.find(r=>r.name==='assets/'+name);return r?scene.getGame().getResourceLoader().getFullUrl(r.file):null;};
    function syncMusic(){
      if(!scene||!unlocked)return;
      const desired=scene.getName()==='Arena'?'battle-loop.wav':'home-loop.wav';
      if(!music||desired!==track){if(music)music.pause();const url=resource(desired);if(!url)return;music=new Audio(url);music.loop=true;music.volume=.25;track=desired;}
      music.volume=Math.max(0,Math.min(1,num('MusicVolume')/100));
      if(num('MusicOn')===1){if(music.paused)music.play().catch(()=>{});}else music.pause();
    }
    document.addEventListener('pointerdown',()=>{
      if(!scene)return;unlocked=true;
      const AudioCtx=globalThis.AudioContext||globalThis.webkitAudioContext;
      if(AudioCtx&&!audioContext)audioContext=new AudioCtx();
      if(audioContext?.state==='suspended')audioContext.resume().catch(()=>{});
      syncMusic();
    },{capture:true});
    document.addEventListener('visibilitychange',()=>{if(document.hidden){if(music)music.pause();}else syncMusic();});
    function sound(kind){
      if(!audioContext||audioContext.state!=='running'||num('MusicOn')!==1)return;
      const tones={attack:[392,784],hit:[120,65],good:[523,659,784],shield:[330,494],sleep:[262,330],error:[160,120]};
      (tones[kind]||tones.good).forEach((f,i)=>{const osc=audioContext.createOscillator(),gain=audioContext.createGain(),at=audioContext.currentTime+i*.07;osc.type=kind==='hit'?'triangle':'sine';osc.frequency.setValueAtTime(f,at);gain.gain.setValueAtTime(0,at);gain.gain.linearRampToValueAtTime(.075,at+.015);gain.gain.exponentialRampToValueAtTime(.001,at+.23);osc.connect(gain);gain.connect(audioContext.destination);osc.start(at);osc.stop(at+.25);});
    }
    function emit(type,x,y,count=12,color=null){
      for(let i=0;i<count&&ctx.particles.length<100;i++){
        const o=scene.createObject(type);if(!o)continue;
        const angle=Math.random()*Math.PI*2,speed=45+Math.random()*130,size=10+Math.random()*15;
        o.setPosition(x,y);o.setSize(size,size);o.setZOrder(80);if(color&&o.setColor)o.setColor(color);
        ctx.particles.push({o,x,y,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed-90,age:0,life:.7+Math.random()*.6,spin:Math.random()*180-90});
      }
    }
    function floating(text,x,y,color){const o=scene.createObject('FloatingNumber');if(!o)return;o.setString(text);o.setPosition(x,y);o.setZOrder(85);o.setColor(color);ctx.particles.push({o,x,y,vx:0,vy:-48,age:0,life:1.1,spin:0});}
    function bolt(){const o=scene.createObject('Projectile');if(!o)return;o.setSize(65,65);o.setZOrder(50);ctx.particles.push({o,projectile:true,age:0,life:.3});}
    function base(o){return {o,x:o.getX(),y:o.getY(),w:o.getWidth(),h:o.getHeight(),angle:o.getAngle()};}
    function initialize(next){
      scene=next;const objects=[];for(const cat of ['Body','Eyes','Mouth','Arms','Legs','Horns','Nose','Ears','Tail','Wings'])for(const o of scene.getObjects('Monster'+cat))objects.push({...base(o),cat});
      const body=objects.find(x=>x.cat==='Body');
      ctx={time:0,parts:objects,rival:scene.getObjects('Rival').map(base),heroX:body?body.x+body.w/2:400,heroY:body?body.y+body.h/2:400,particles:[],lastHP:num('Health'),lastEnemy:num('EnemyHP'),lastPhase:0,lastRound:num('Round'),react:0,heroHurt:0,enemyHurt:0,emission:0,barHealth:num('Health'),barEnergy:num('Energy'),barEnemy:num('EnemyHP'),buttons:[]};
      const buttonNames=['Music','Feed','Train','Rest','Battle','Decor','Attack','Shield','Heal','Creator','Camera','Retreat','Again','Home','Random','Rename','Save','Load','ToLab'];
      for(const o of scene.getAdhocListOfAllInstances())if(buttonNames.includes(o.getName())||/^(Body|Eyes|Mouth|Arms|Legs|Horns|Nose|Ears|Tail|Wings)(Next|Prev)$/.test(o.getName()))ctx.buttons.push(base(o));
      if(scene.getName()==='Final'){emit('ParticleSpark',870,300,45);sound('good');}
      record('scene',{name:scene.getName()});syncMusic();
    }
    function tick(next){
      if(scene!==next)initialize(next);
      const dt=Math.min(.05,Math.max(0,scene.getElapsedTime()/1000));ctx.time+=dt;ctx.react=Math.max(0,ctx.react-dt);ctx.heroHurt=Math.max(0,ctx.heroHurt-dt);ctx.enemyHurt=Math.max(0,ctx.enemyHurt-dt);
      const name=scene.getName(),phase=sv('Phase'),turn=sv('TurnTime'),kind=sv('ActionKind');
      const fx=num('VisualFX');if(fx){vars().get('VisualFX').setNumber(0);ctx.react=.9;
        if(fx===1){emit('ParticleHeart',ctx.heroX,ctx.heroY,13);floating('+20 энергии',ctx.heroX-80,ctx.heroY-100,'186;245;210');sound('good');}
        if(fx===2){emit('ParticleSpark',ctx.heroX,ctx.heroY,18);floating('+4 силы',ctx.heroX-60,ctx.heroY-110,'255;221;140');sound('good');}
        if(fx===3){emit('ParticleBubble',ctx.heroX,ctx.heroY,12);floating('Z z z…',ctx.heroX-40,ctx.heroY-120,'202;190;255');sound('sleep');}
        if(fx===4){emit('ParticleSpark',ctx.heroX,ctx.heroY-50,36);sound('good');}
        if(fx===5){emit('ParticleHeart',ctx.heroX,ctx.heroY,12);sound('good');}
        if(fx===6){floating('Нужно больше энергии',ctx.heroX-120,ctx.heroY-110,'255;191;165');sound('error');}
        record('reaction',{kind:fx});
      }
      if(num('PetRequest')){vars().get('PetRequest').setNumber(0);ctx.react=1.2;emit('ParticleHeart',ctx.heroX,ctx.heroY-70,18);sound('good');record('pet');}
      if(name==='Arena'&&phase===1&&ctx.lastPhase!==1){
        if(kind===1){bolt();sound('attack');record('player-attack');}
        if(kind===2){emit('ParticleBubble',ctx.heroX,ctx.heroY,15);sound('shield');record('shield');}
        if(kind===3)record('heal');
      }
      if(name==='Arena'&&phase===3&&ctx.lastPhase!==3){emit('ParticleSpark',970,365,12);sound('attack');record('enemy-counterattack');}
      const hp=num('Health'),enemy=num('EnemyHP');
      if(hp<ctx.lastHP){ctx.heroHurt=.28;emit('ParticleSpark',ctx.heroX,ctx.heroY,13);floating('−'+(ctx.lastHP-hp),ctx.heroX,ctx.heroY-80,'255;157;170');sound('hit');record('player-damage',{amount:ctx.lastHP-hp});}
      if(hp>ctx.lastHP&&name==='Arena')floating('+'+(hp-ctx.lastHP),ctx.heroX,ctx.heroY-90,'186;245;210');
      if(enemy<ctx.lastEnemy&&name==='Arena'){ctx.enemyHurt=.28;emit('ParticleSpark',965,380,20);floating('−'+(ctx.lastEnemy-enemy),960,300,'255;220;151');sound('hit');record('enemy-damage',{amount:ctx.lastEnemy-enemy});}
      ctx.lastHP=hp;ctx.lastEnemy=enemy;ctx.lastPhase=phase;
      const t=ctx.time,breath=1+.018*Math.sin(t*3),blink=(t%4.3)>.12&&(t%4.3)<.25;
      let lunge=0,jump=0;
      if(name==='Arena'&&kind===1&&phase>0&&phase<4)lunge=100*Math.sin(Math.PI*Math.min(1,turn/.62));
      if(ctx.react>0)jump=-Math.abs(Math.sin(ctx.react*10))*num('ReactionHeight');
      const shake=ctx.heroHurt>0?Math.sin(ctx.heroHurt*120)*9:0;
      for(const b of ctx.parts){
        const sx=breath,sy=1-.016*Math.sin(t*3);b.o.setSize(b.w*sx,b.h*sy*(b.cat==='Eyes'&&blink?.08:1));
        let x=ctx.heroX+(b.x-ctx.heroX)*sx+lunge+shake,y=ctx.heroY+(b.y-ctx.heroY)*sy+Math.sin(t*2.4)*num('IdleAmplitude')+jump;
        if(b.cat==='Eyes'&&blink)y+=b.h*.45;
        b.o.setPosition(x,y);b.o.setAngle(b.angle+(b.cat==='Arms'?Math.sin(t*3)*2:0));
        b.o.setOpacity(ctx.heroHurt>0&&Math.sin(ctx.heroHurt*80)>0?135:255);
      }
      for(const b of ctx.rival){
        let x=b.x,y=b.y+Math.sin(t*2.1)*6,angle=Math.sin(t*1.7)*2;
        if(phase===3)x-=140*Math.sin(Math.PI*Math.min(1,Math.max(0,(turn-.68)/.46)));
        b.o.setPosition(x,y);b.o.setAngle(angle);b.o.setSize(b.w*(1+.022*Math.sin(t*2.1)),b.h*(1-.018*Math.sin(t*2.1)));
        b.o.setOpacity(phase===5?Math.max(0,220-turn*350):ctx.enemyHurt>0?145:255);
      }
      const halo=scene.getObjects('ShieldHalo')[0];if(halo){if(name==='Arena'&&kind===2&&phase>0&&phase<5){halo.setPosition(ctx.heroX-85,ctx.heroY-60);halo.setSize(170,170);halo.setOpacity(180+50*Math.sin(t*8));}else halo.setPosition(-400,-400);}
      // Native scene sprites show the values; only their visual interpolation is here.
      for(const [field,key,max]of [['Health','barHealth',100],['Energy','barEnergy',100],['EnemyHealth','barEnemy',40+20*num('Round')]]){
        const target=field==='EnemyHealth'?enemy:num(field);ctx[key]+=(target-ctx[key])*Math.min(1,dt*12);
        const o=scene.getObjects(field+'Bar')[0];if(o){const width=field==='EnemyHealth'?241:225;o.setWidth(Math.max(.1,width*Math.max(0,ctx[key])/max));}
      }
      for(let i=0;i<3;i++){const trophy=scene.getObjects('Trophy'+i)[0];if(trophy)trophy.setOpacity(num('Badges')>i?255:55);}
      const input=scene.getGame().getInputManager(),mx=input.getMouseX(),my=input.getMouseY();
      for(const b of ctx.buttons){const hover=mx>=b.x&&mx<=b.x+b.w&&my>=b.y&&my<=b.y+b.h;const busy=name==='Arena'&&phase>0&&['Attack','Shield','Heal'].includes(b.o.getName());b.o.setOpacity(busy?125:255);b.o.setPosition(b.x,b.y+(hover&&!busy?-2:0));}
      ctx.emission+=dt;
      if(ctx.emission>.45){ctx.emission=0;if(name==='Lab')emit('ParticleBubble',1090,338,1);else if(name==='Final')emit('ParticleSpark',180+Math.random()*920,210,3);else if(name==='Arena')emit('ParticleBubble',90+Math.random()*1100,510,1);}
      ctx.particles=ctx.particles.filter(p=>{
        p.age+=dt;if(p.age>=p.life){p.o.deleteFromScene(scene);return false;}
        if(p.projectile){const f=p.age/p.life;p.o.setPosition(340+570*f,375-Math.sin(f*Math.PI)*65);p.o.setAngle(30+f*360);}
        else{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=35*dt;p.o.setPosition(p.x,p.y);if(p.spin)p.o.setAngle(p.o.getAngle()+p.spin*dt);}
        p.o.setOpacity(255*Math.min(1,(p.life-p.age)/.3));return true;
      });
      syncMusic();
    }
    window.addEventListener('pagehide',()=>{if(music)music.pause();if(audioContext)audioContext.suspend().catch(()=>{});});
    return {tick,events,getMusic:()=>music,inspect:()=>({scene:scene?.getName(),phase:scene?sv('Phase'):0,particles:ctx?.particles.length||0,musicOn:scene?num('MusicOn'):0,track})};
  })();
}
globalThis.MonsterWorld.tick(runtimeScene);
};
gdjs.LabCode.eventsList3 = function(runtimeScene) {

{


gdjs.LabCode.userFunc0xc41eb0(runtimeScene);

}


};gdjs.LabCode.userFunc0xc417f8 = function GDJSInlineCode(runtimeScene) {
"use strict";
/* Teacher-owned adapter. Gameplay lives in visible GDevelop events, not here. */
if (!globalThis.MonsterProtocol) {
  globalThis.MonsterProtocol = (() => {
    let scene, model=null, panel=null, webcam=null, stream=null, running=false, session=0;
    let candidate='', since=0, neutralSince=0, armed=true, lastCommand=-Infinity;
    const allowed=['ATTACK','SHIELD','HEAL','IDLE'];
    const state=()=>scene.getGame().getVariables();
    const set=(n,v)=>typeof v==='string'?state().get(n).setString(v):state().get(n).setNumber(v);
    const get=n=>state().get(n).getAsNumber();
    const status=s=>{const el=document.getElementById('mp-status');if(el)el.textContent=s;};
    function resource(name) {
      const data=scene.getGame().getGameData().resources.resources.find(r=>r.name==='assets/'+name);
      if (!data) throw Error('Ресурс не найден: '+name);
      return scene.getGame().getResourceLoader().getFullUrl(data.file);
    }
    const loadScript=(name,globalName)=>new Promise((resolve,reject)=>{
      if(globalThis[globalName])return resolve();
      const s=document.createElement('script');s.src=resource(name);s.onload=resolve;s.onerror=()=>reject(Error('Не загружена локальная библиотека '+name));document.head.append(s);
    });
    async function libraries(){await loadScript('tf.min.js','tf');await loadScript('tm.min.js','tmImage');}
    function resetGate(){candidate='';since=0;neutralSince=0;armed=true;lastCommand=-Infinity;}
    function gate(predictions,now=performance.now()) {
      const top=predictions.reduce((a,b)=>a.probability>b.probability?a:b,{className:'IDLE',probability:0});
      const label=top.className;
      if(top.probability<.85 || label==='IDLE') {
        candidate='';
        if(!neutralSince)neutralSince=now;
        if(now-neutralSince>=400)armed=true;
        return 0;
      }
      neutralSince=0;
      if(candidate!==label){candidate=label;since=now;return 0;}
      if(!armed || now-since<500 || now-lastCommand<1500)return 0;
      armed=false;lastCommand=now;
      return {ATTACK:1,SHIELD:2,HEAL:3}[label]||0;
    }
    function stop(){session++;running=false;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;if(webcam){webcam.srcObject=null;webcam.remove();webcam=null;}set('AICommand',0);resetGate();status('Камера выключена. Кнопки игры доступны.');}
    function close(){stop();if(panel)panel.remove();panel=null;}
    function shell(title){
      close();panel=document.createElement('div');panel.id='mp-overlay';panel.setAttribute('role','dialog');panel.setAttribute('aria-label',title);
      panel.style.cssText='position:fixed;inset:0;z-index:99999;background:#100b20dd;display:grid;place-items:center;font:16px system-ui;color:#fff8ed';
      panel.innerHTML='<section style="background:#282039;border:1px solid #655276;border-radius:24px;padding:26px;width:min(680px,86vw);max-height:86vh;overflow:auto"><button id="mp-close" style="float:right">Закрыть ×</button><h2></h2><div id="mp-content"></div><p id="mp-status" role="status"></p></section>';
      panel.querySelector('h2').textContent=title;
      // The canvas must not receive clicks made on a modal control.
      for(const event of ['mousedown','mouseup','pointerdown','pointerup','touchstart','touchend'])panel.addEventListener(event,e=>e.stopPropagation());
      document.body.append(panel);panel.querySelector('#mp-close').onclick=close;
      return panel.querySelector('#mp-content');
    }
    function rename(){const root=shell('Имя твоего монстра');root.innerHTML='<label>Имя (до 24 символов)<br><input id="mp-name" maxlength="24" style="font:24px system-ui;padding:10px;margin:16px 0"></label><br><button id="mp-name-save">Готово</button>';
      root.querySelector('input').value=state().get('Name').getAsString();root.querySelector('button').onclick=()=>{const n=root.querySelector('input').value.trim();if(n){set('Name',n);close();}};
    }
    function validateLabels(m){const labels=m.getClassLabels();if(labels.length!==4||!allowed.every(n=>labels.includes(n)))throw Error('Нужны ровно 4 класса: ATTACK, SHIELD, HEAL, IDLE. Проверь регистр.');}
    async function replaceModel(next){try{validateLabels(next);}catch(e){next.model.dispose();throw e;}stop();if(model)model.model.dispose();model=next;status('Модель готова. Включи камеру; команды действуют только на арене.');}
    function missingFiles(files){
      const names=Array.from(files,f=>f.name);
      return ['model.json','metadata.json'].filter(n=>!names.includes(n));
    }
    async function loadLocal(files){const f=Array.from(files),find=n=>f.find(x=>x.name===n);const missing=missingFiles(f);if(missing.length)throw Error('Не хватает: '+missing.join(', ')+'. Нужен распакованный экспорт TensorFlow.js из Teachable Machine.');
      const meta=JSON.parse(await find('metadata.json').text());const spec=JSON.parse(await find('model.json').text());
      if(!Array.isArray(spec.weightsManifest)||!spec.modelTopology)throw Error('Этот JSON не похож на модель TensorFlow.js. game.json — проект GDevelop, а не файл ИИ.');
      const names=spec.weightsManifest.flatMap(g=>g.paths);const weights=names.map(n=>{const file=find(n);if(!file)throw Error('Не найден файл весов '+n);return file;});
      await libraries();
      const layers=await tf.loadLayersModel(tf.io.browserFiles([find('model.json'),...weights]));
      await replaceModel(new tmImage.CustomMobileNet(layers,meta));
    }
    async function demoModel(){await libraries();const response=await fetch(resource('demo-bundle.json'));if(!response.ok)throw Error('Не найден локальный комплект модели');const b=await response.json();const weightData=Uint8Array.from(atob(b.weightData),c=>c.charCodeAt(0)).buffer;const layers=await tf.loadLayersModel(tf.io.fromMemory(b.modelTopology,b.weightSpecs,weightData));await replaceModel(new tmImage.CustomMobileNet(layers,b.metadata));}
    async function start(){
      const openingPanel=panel;
      if(!model){
        status('Загружаем встроенную модель цветных карточек…');
        try{await demoModel();if(!panel||panel!==openingPanel)return;}catch(e){status('Не удалось загрузить встроенную модель: '+e.message);return;}
      }
      stop();const token=session;status('Разреши доступ к камере…');
      try{
        if(!navigator.mediaDevices?.getUserMedia)throw Error('Камере нужен localhost или HTTPS. Запусти START_WINDOWS.bat из распакованной папки.');
        const acquired=await navigator.mediaDevices.getUserMedia({video:{width:320,height:240,facingMode:'user'},audio:false});
        if(token!==session){acquired.getTracks().forEach(t=>t.stop());return;}
        stream=acquired;webcam=document.createElement('video');webcam.id='mp-video';webcam.autoplay=true;webcam.muted=true;webcam.playsInline=true;webcam.style.cssText='width:240px;border-radius:14px;transform:scaleX(-1)';webcam.srcObject=stream;
        document.getElementById('mp-video-box').append(webcam);await webcam.play();
        if(token!==session)return;running=true;resetGate();
        while(running&&token===session){
          const predictions=await model.predict(webcam,false);if(token!==session)break;
          const top=predictions.reduce((a,b)=>a.probability>b.probability?a:b);
          const command=gate(predictions);
          status(top.className+' · '+Math.round(top.probability*100)+'%'+(armed?' · готов':' · убери карточку / вернись в IDLE'));
          if(command&&scene.getName()==='Arena')set('AICommand',command);
          await new Promise(r=>setTimeout(r,100));
        }
      }catch(e){if(token===session){stop();const help={NotAllowedError:'Разреши камеру в настройках рядом с адресом браузера.',NotFoundError:'Камера не найдена. Проверь подключение.',NotReadableError:'Камера занята или недоступна. Закрой видеозвонки и попробуй снова.'};status(help[e.name]||('Камера или модель: '+e.message));}}
    }
    function camera(){const root=shell('Teachable Machine → команды игры');
      root.innerHTML='<p>Быстрый старт: нажми <b>«Включить камеру»</b>. Встроенная модель цветных карточек загрузится сама.</p><p>Для своей модели: 4 класса <b>ATTACK · SHIELD · HEAL · IDLE</b>. Добавь <b>model.json, metadata.json и все веса</b> из экспорта TensorFlow.js — вместе или по очереди. Выбранные файлы останутся в списке.</p><input id="mp-model-files" type="file" multiple accept=".json,.bin"><p><button id="mp-demo">Модель цветных карточек</button> <button id="mp-start">Включить камеру</button> <button id="mp-stop">Выключить камеру</button></p><p>Красная карточка — атака, синяя — щит, зелёная — лечение. Нейтральный серый фон — IDLE. Это модель цвета, а не распознавание рук. Удержи карточку 0,5 с, затем убери её.</p><div id="mp-video-box"></div><p id="mp-battle-state" style="padding:12px;background:#171122;border-radius:10px"></p><p>Оставь окно открытым на арене. Для перехода к кнопкам нажми «Закрыть»: камера выключится. Видео и файлы обрабатываются в этом браузере.</p>';
      const collected=new Map();
      const selection=document.createElement('p');selection.id='mp-selected-files';selection.textContent='Своя модель: файлы пока не добавлены.';root.querySelector('#mp-model-files').after(selection);
      root.querySelector('#mp-model-files').onchange=async e=>{
        for(const file of e.target.files)collected.set(file.name,file);
        selection.textContent='Добавлены: '+[...collected.keys()].join(', ');
        try{
          const files=[...collected.values()],missing=missingFiles(files);
          if(missing.length){status('Файлы добавлены. Теперь добавь: '+missing.join(', ')+', затем файл весов из той же папки. Можно выбирать по очереди.');return;}
          status('Проверяем комплект модели…');await loadLocal(files);
        }catch(err){status('Модель пока не загружена: '+err.message+' Добавь недостающий файл, уже выбранные сохранены.');}
      };
      root.querySelector('#mp-demo').onclick=async()=>{try{status('Загружаем локальную модель…');await demoModel();}catch(e){status('Модель не загружена: '+e.message);}};
      root.querySelector('#mp-start').onclick=start;root.querySelector('#mp-stop').onclick=stop;
      status(model?'Модель готова. Можно включить камеру.':'Для быстрого старта нажми «Включить камеру»: встроенная модель карточек загрузится автоматически. Для своей модели добавь model.json, metadata.json и веса — вместе или по очереди.');
    }
    const fields=['Name','Health','Energy','Strength','XP','Level','Wins','Round','Gold','RoomStyle','Badges',...['Body','Eyes','Mouth','Arms','Legs','Horns','Nose','Ears','Tail','Wings'].map(x=>x+'Variant')];
    const limits={Gold:[0,100000],RoomStyle:[0,2],Badges:[0,3],Health:[0,100],Energy:[0,100],Strength:[10,30],XP:[0,100000],Level:[1,33334],Wins:[0,3],Round:[1,3],BodyVariant:[0,5],EyesVariant:[0,7],MouthVariant:[0,5]};
    function save(){try{const values={};for(const n of fields)values[n]=n==='Name'?state().get(n).getAsString():get(n);localStorage.setItem('monster-protocol-v1',JSON.stringify({version:1,values}));set('Message','Сохранено в этом браузере. Для переноса копируй проект; эта запись не передаётся автоматически.');}catch{set('Message','Браузер запретил локальное сохранение. Сохрани проект в GDevelop.');}}
    function load(){try{const data=JSON.parse(localStorage.getItem('monster-protocol-v1'));if(data?.version!==1||!data.values)throw Error('Нет сохранения');for(const n of fields){const v=data.values[n]===undefined&&['Gold','RoomStyle','Badges'].includes(n)?get(n):data.values[n];data.values[n]=v;if(n==='Name'){if(typeof v!=='string'||!v.trim()||v.length>24)throw Error('Имя');}else{const [lo,hi]=limits[n]||[0,3];if(!Number.isFinite(v)||!Number.isInteger(v)||v<lo||v>hi)throw Error(n);}}for(const n of fields)set(n,data.values[n]);set('Message','Сохранение загружено.');}catch{set('Message','Корректное сохранение не найдено. Текущий монстр не изменён.');}}
    function tick(next){if(scene&&scene!==next&&panel)close();scene=next;
      const battle=document.getElementById('mp-battle-state');if(battle)battle.textContent='Раунд '+get('Round')+' / 3 · Соперник: '+get('EnemyHP')+' HP · Ты: '+get('Health')+' HP · Энергия: '+get('Energy')+' · '+state().get('Message').getAsString();
      for(const [key,fn] of [['NamePanel',rename],['AIPanel',camera],['SaveRequest',save],['LoadRequest',load]])if(get(key)){set(key,0);fn();}
    }
    window.addEventListener('pagehide',()=>{if(scene)stop();});
    return {tick,gate,resetGate,stop,close,loadLocal,demoModel,getScene:()=>scene,getModel:()=>model};
  })();
}
runtimeScene.getGame().enableMetrics(false);
globalThis.MonsterProtocol.tick(runtimeScene);
};
gdjs.LabCode.eventsList4 = function(runtimeScene) {

{


gdjs.LabCode.userFunc0xc417f8(runtimeScene);

}


};gdjs.LabCode.eventsList5 = function(runtimeScene) {

{


gdjs.LabCode.eventsList0(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Message"), gdjs.LabCode.GDMessageObjects1);
{for(var i = 0, len = gdjs.LabCode.GDMessageObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDMessageObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(24)));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Creator"), gdjs.LabCode.GDCreatorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDCreatorObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13324204);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MonsterCreator", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Camera"), gdjs.LabCode.GDCameraObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDCameraObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13325412);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("PlayerName"), gdjs.LabCode.GDPlayerNameObjects1);
{for(var i = 0, len = gdjs.LabCode.GDPlayerNameObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDPlayerNameObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(10)));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HealthValue"), gdjs.LabCode.GDHealthValueObjects1);
{for(var i = 0, len = gdjs.LabCode.GDHealthValueObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDHealthValueObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11))));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EnergyValue"), gdjs.LabCode.GDEnergyValueObjects1);
{for(var i = 0, len = gdjs.LabCode.GDEnergyValueObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDEnergyValueObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12))));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Stats"), gdjs.LabCode.GDStatsObjects1);
{for(var i = 0, len = gdjs.LabCode.GDStatsObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDStatsObjects1[i].setString("Сила: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(13))) + "    Уровень: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(15))) + "    Звёзды: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(25))));
}
}
}

}


{


gdjs.LabCode.eventsList1(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Backdrop"), gdjs.LabCode.GDBackdropObjects1);
gdjs.copyArray(runtimeScene.getObjects("NameText"), gdjs.LabCode.GDNameTextObjects1);
{for(var i = 0, len = gdjs.LabCode.GDNameTextObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDNameTextObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(10)));
}
}
{for(var i = 0, len = gdjs.LabCode.GDBackdropObjects1.length ;i < len;++i) {
    gdjs.LabCode.GDBackdropObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(26)));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MonsterBody"), gdjs.LabCode.GDMonsterBodyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDMonsterBodyObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13333564);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(30).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Почеши за рожками! А потом — тренировка или прогулка.");
}
}

}


{


gdjs.LabCode.eventsList2(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Battle"), gdjs.LabCode.GDBattleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LabCode.mapOfGDgdjs_9546LabCode_9546GDBattleObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13355388);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) >= 3;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Final", false);
}
}

}


{


gdjs.LabCode.eventsList3(runtimeScene);
}


{


gdjs.LabCode.eventsList4(runtimeScene);
}


};

gdjs.LabCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LabCode.GDBackdropObjects1.length = 0;
gdjs.LabCode.GDBackdropObjects2.length = 0;
gdjs.LabCode.GDBackdropObjects3.length = 0;
gdjs.LabCode.GDBrandObjects1.length = 0;
gdjs.LabCode.GDBrandObjects2.length = 0;
gdjs.LabCode.GDBrandObjects3.length = 0;
gdjs.LabCode.GDEditionObjects1.length = 0;
gdjs.LabCode.GDEditionObjects2.length = 0;
gdjs.LabCode.GDEditionObjects3.length = 0;
gdjs.LabCode.GDTitleObjects1.length = 0;
gdjs.LabCode.GDTitleObjects2.length = 0;
gdjs.LabCode.GDTitleObjects3.length = 0;
gdjs.LabCode.GDKickerObjects1.length = 0;
gdjs.LabCode.GDKickerObjects2.length = 0;
gdjs.LabCode.GDKickerObjects3.length = 0;
gdjs.LabCode.GDHeaderShadeObjects1.length = 0;
gdjs.LabCode.GDHeaderShadeObjects2.length = 0;
gdjs.LabCode.GDHeaderShadeObjects3.length = 0;
gdjs.LabCode.GDMusicObjects1.length = 0;
gdjs.LabCode.GDMusicObjects2.length = 0;
gdjs.LabCode.GDMusicObjects3.length = 0;
gdjs.LabCode.GDMusicLabelObjects1.length = 0;
gdjs.LabCode.GDMusicLabelObjects2.length = 0;
gdjs.LabCode.GDMusicLabelObjects3.length = 0;
gdjs.LabCode.GDParticleSparkObjects1.length = 0;
gdjs.LabCode.GDParticleSparkObjects2.length = 0;
gdjs.LabCode.GDParticleSparkObjects3.length = 0;
gdjs.LabCode.GDParticleHeartObjects1.length = 0;
gdjs.LabCode.GDParticleHeartObjects2.length = 0;
gdjs.LabCode.GDParticleHeartObjects3.length = 0;
gdjs.LabCode.GDParticleBubbleObjects1.length = 0;
gdjs.LabCode.GDParticleBubbleObjects2.length = 0;
gdjs.LabCode.GDParticleBubbleObjects3.length = 0;
gdjs.LabCode.GDProjectileObjects1.length = 0;
gdjs.LabCode.GDProjectileObjects2.length = 0;
gdjs.LabCode.GDProjectileObjects3.length = 0;
gdjs.LabCode.GDFloatingNumberObjects1.length = 0;
gdjs.LabCode.GDFloatingNumberObjects2.length = 0;
gdjs.LabCode.GDFloatingNumberObjects3.length = 0;
gdjs.LabCode.GDShieldHaloObjects1.length = 0;
gdjs.LabCode.GDShieldHaloObjects2.length = 0;
gdjs.LabCode.GDShieldHaloObjects3.length = 0;
gdjs.LabCode.GDMessagePanelObjects1.length = 0;
gdjs.LabCode.GDMessagePanelObjects2.length = 0;
gdjs.LabCode.GDMessagePanelObjects3.length = 0;
gdjs.LabCode.GDMessageObjects1.length = 0;
gdjs.LabCode.GDMessageObjects2.length = 0;
gdjs.LabCode.GDMessageObjects3.length = 0;
gdjs.LabCode.GDCreatorObjects1.length = 0;
gdjs.LabCode.GDCreatorObjects2.length = 0;
gdjs.LabCode.GDCreatorObjects3.length = 0;
gdjs.LabCode.GDCreatorLabelObjects1.length = 0;
gdjs.LabCode.GDCreatorLabelObjects2.length = 0;
gdjs.LabCode.GDCreatorLabelObjects3.length = 0;
gdjs.LabCode.GDCameraObjects1.length = 0;
gdjs.LabCode.GDCameraObjects2.length = 0;
gdjs.LabCode.GDCameraObjects3.length = 0;
gdjs.LabCode.GDCameraLabelObjects1.length = 0;
gdjs.LabCode.GDCameraLabelObjects2.length = 0;
gdjs.LabCode.GDCameraLabelObjects3.length = 0;
gdjs.LabCode.GDPlayerHUDObjects1.length = 0;
gdjs.LabCode.GDPlayerHUDObjects2.length = 0;
gdjs.LabCode.GDPlayerHUDObjects3.length = 0;
gdjs.LabCode.GDPlayerNameObjects1.length = 0;
gdjs.LabCode.GDPlayerNameObjects2.length = 0;
gdjs.LabCode.GDPlayerNameObjects3.length = 0;
gdjs.LabCode.GDHealthTrackObjects1.length = 0;
gdjs.LabCode.GDHealthTrackObjects2.length = 0;
gdjs.LabCode.GDHealthTrackObjects3.length = 0;
gdjs.LabCode.GDHealthBarObjects1.length = 0;
gdjs.LabCode.GDHealthBarObjects2.length = 0;
gdjs.LabCode.GDHealthBarObjects3.length = 0;
gdjs.LabCode.GDHealthValueObjects1.length = 0;
gdjs.LabCode.GDHealthValueObjects2.length = 0;
gdjs.LabCode.GDHealthValueObjects3.length = 0;
gdjs.LabCode.GDEnergyTrackObjects1.length = 0;
gdjs.LabCode.GDEnergyTrackObjects2.length = 0;
gdjs.LabCode.GDEnergyTrackObjects3.length = 0;
gdjs.LabCode.GDEnergyBarObjects1.length = 0;
gdjs.LabCode.GDEnergyBarObjects2.length = 0;
gdjs.LabCode.GDEnergyBarObjects3.length = 0;
gdjs.LabCode.GDEnergyValueObjects1.length = 0;
gdjs.LabCode.GDEnergyValueObjects2.length = 0;
gdjs.LabCode.GDEnergyValueObjects3.length = 0;
gdjs.LabCode.GDResearchHUDObjects1.length = 0;
gdjs.LabCode.GDResearchHUDObjects2.length = 0;
gdjs.LabCode.GDResearchHUDObjects3.length = 0;
gdjs.LabCode.GDStatsObjects1.length = 0;
gdjs.LabCode.GDStatsObjects2.length = 0;
gdjs.LabCode.GDStatsObjects3.length = 0;
gdjs.LabCode.GDMonsterBodyObjects1.length = 0;
gdjs.LabCode.GDMonsterBodyObjects2.length = 0;
gdjs.LabCode.GDMonsterBodyObjects3.length = 0;
gdjs.LabCode.GDMonsterEyesObjects1.length = 0;
gdjs.LabCode.GDMonsterEyesObjects2.length = 0;
gdjs.LabCode.GDMonsterEyesObjects3.length = 0;
gdjs.LabCode.GDMonsterMouthObjects1.length = 0;
gdjs.LabCode.GDMonsterMouthObjects2.length = 0;
gdjs.LabCode.GDMonsterMouthObjects3.length = 0;
gdjs.LabCode.GDMonsterArmsObjects1.length = 0;
gdjs.LabCode.GDMonsterArmsObjects2.length = 0;
gdjs.LabCode.GDMonsterArmsObjects3.length = 0;
gdjs.LabCode.GDMonsterLegsObjects1.length = 0;
gdjs.LabCode.GDMonsterLegsObjects2.length = 0;
gdjs.LabCode.GDMonsterLegsObjects3.length = 0;
gdjs.LabCode.GDMonsterHornsObjects1.length = 0;
gdjs.LabCode.GDMonsterHornsObjects2.length = 0;
gdjs.LabCode.GDMonsterHornsObjects3.length = 0;
gdjs.LabCode.GDMonsterNoseObjects1.length = 0;
gdjs.LabCode.GDMonsterNoseObjects2.length = 0;
gdjs.LabCode.GDMonsterNoseObjects3.length = 0;
gdjs.LabCode.GDMonsterEarsObjects1.length = 0;
gdjs.LabCode.GDMonsterEarsObjects2.length = 0;
gdjs.LabCode.GDMonsterEarsObjects3.length = 0;
gdjs.LabCode.GDMonsterTailObjects1.length = 0;
gdjs.LabCode.GDMonsterTailObjects2.length = 0;
gdjs.LabCode.GDMonsterTailObjects3.length = 0;
gdjs.LabCode.GDMonsterWingsObjects1.length = 0;
gdjs.LabCode.GDMonsterWingsObjects2.length = 0;
gdjs.LabCode.GDMonsterWingsObjects3.length = 0;
gdjs.LabCode.GDNameTextObjects1.length = 0;
gdjs.LabCode.GDNameTextObjects2.length = 0;
gdjs.LabCode.GDNameTextObjects3.length = 0;
gdjs.LabCode.GDFoodBowlObjects1.length = 0;
gdjs.LabCode.GDFoodBowlObjects2.length = 0;
gdjs.LabCode.GDFoodBowlObjects3.length = 0;
gdjs.LabCode.GDGiftObjects1.length = 0;
gdjs.LabCode.GDGiftObjects2.length = 0;
gdjs.LabCode.GDGiftObjects3.length = 0;
gdjs.LabCode.GDAdventurePanelObjects1.length = 0;
gdjs.LabCode.GDAdventurePanelObjects2.length = 0;
gdjs.LabCode.GDAdventurePanelObjects3.length = 0;
gdjs.LabCode.GDAdventureHintObjects1.length = 0;
gdjs.LabCode.GDAdventureHintObjects2.length = 0;
gdjs.LabCode.GDAdventureHintObjects3.length = 0;
gdjs.LabCode.GDRoomCaptionObjects1.length = 0;
gdjs.LabCode.GDRoomCaptionObjects2.length = 0;
gdjs.LabCode.GDRoomCaptionObjects3.length = 0;
gdjs.LabCode.GDTrophy0Objects1.length = 0;
gdjs.LabCode.GDTrophy0Objects2.length = 0;
gdjs.LabCode.GDTrophy0Objects3.length = 0;
gdjs.LabCode.GDTrophy1Objects1.length = 0;
gdjs.LabCode.GDTrophy1Objects2.length = 0;
gdjs.LabCode.GDTrophy1Objects3.length = 0;
gdjs.LabCode.GDTrophy2Objects1.length = 0;
gdjs.LabCode.GDTrophy2Objects2.length = 0;
gdjs.LabCode.GDTrophy2Objects3.length = 0;
gdjs.LabCode.GDTrophiesHintObjects1.length = 0;
gdjs.LabCode.GDTrophiesHintObjects2.length = 0;
gdjs.LabCode.GDTrophiesHintObjects3.length = 0;
gdjs.LabCode.GDFeedObjects1.length = 0;
gdjs.LabCode.GDFeedObjects2.length = 0;
gdjs.LabCode.GDFeedObjects3.length = 0;
gdjs.LabCode.GDFeedLabelObjects1.length = 0;
gdjs.LabCode.GDFeedLabelObjects2.length = 0;
gdjs.LabCode.GDFeedLabelObjects3.length = 0;
gdjs.LabCode.GDTrainObjects1.length = 0;
gdjs.LabCode.GDTrainObjects2.length = 0;
gdjs.LabCode.GDTrainObjects3.length = 0;
gdjs.LabCode.GDTrainLabelObjects1.length = 0;
gdjs.LabCode.GDTrainLabelObjects2.length = 0;
gdjs.LabCode.GDTrainLabelObjects3.length = 0;
gdjs.LabCode.GDRestObjects1.length = 0;
gdjs.LabCode.GDRestObjects2.length = 0;
gdjs.LabCode.GDRestObjects3.length = 0;
gdjs.LabCode.GDRestLabelObjects1.length = 0;
gdjs.LabCode.GDRestLabelObjects2.length = 0;
gdjs.LabCode.GDRestLabelObjects3.length = 0;
gdjs.LabCode.GDDecorObjects1.length = 0;
gdjs.LabCode.GDDecorObjects2.length = 0;
gdjs.LabCode.GDDecorObjects3.length = 0;
gdjs.LabCode.GDDecorLabelObjects1.length = 0;
gdjs.LabCode.GDDecorLabelObjects2.length = 0;
gdjs.LabCode.GDDecorLabelObjects3.length = 0;
gdjs.LabCode.GDBattleObjects1.length = 0;
gdjs.LabCode.GDBattleObjects2.length = 0;
gdjs.LabCode.GDBattleObjects3.length = 0;
gdjs.LabCode.GDBattleLabelObjects1.length = 0;
gdjs.LabCode.GDBattleLabelObjects2.length = 0;
gdjs.LabCode.GDBattleLabelObjects3.length = 0;

gdjs.LabCode.eventsList5(runtimeScene);
gdjs.LabCode.GDBackdropObjects1.length = 0;
gdjs.LabCode.GDBackdropObjects2.length = 0;
gdjs.LabCode.GDBackdropObjects3.length = 0;
gdjs.LabCode.GDBrandObjects1.length = 0;
gdjs.LabCode.GDBrandObjects2.length = 0;
gdjs.LabCode.GDBrandObjects3.length = 0;
gdjs.LabCode.GDEditionObjects1.length = 0;
gdjs.LabCode.GDEditionObjects2.length = 0;
gdjs.LabCode.GDEditionObjects3.length = 0;
gdjs.LabCode.GDTitleObjects1.length = 0;
gdjs.LabCode.GDTitleObjects2.length = 0;
gdjs.LabCode.GDTitleObjects3.length = 0;
gdjs.LabCode.GDKickerObjects1.length = 0;
gdjs.LabCode.GDKickerObjects2.length = 0;
gdjs.LabCode.GDKickerObjects3.length = 0;
gdjs.LabCode.GDHeaderShadeObjects1.length = 0;
gdjs.LabCode.GDHeaderShadeObjects2.length = 0;
gdjs.LabCode.GDHeaderShadeObjects3.length = 0;
gdjs.LabCode.GDMusicObjects1.length = 0;
gdjs.LabCode.GDMusicObjects2.length = 0;
gdjs.LabCode.GDMusicObjects3.length = 0;
gdjs.LabCode.GDMusicLabelObjects1.length = 0;
gdjs.LabCode.GDMusicLabelObjects2.length = 0;
gdjs.LabCode.GDMusicLabelObjects3.length = 0;
gdjs.LabCode.GDParticleSparkObjects1.length = 0;
gdjs.LabCode.GDParticleSparkObjects2.length = 0;
gdjs.LabCode.GDParticleSparkObjects3.length = 0;
gdjs.LabCode.GDParticleHeartObjects1.length = 0;
gdjs.LabCode.GDParticleHeartObjects2.length = 0;
gdjs.LabCode.GDParticleHeartObjects3.length = 0;
gdjs.LabCode.GDParticleBubbleObjects1.length = 0;
gdjs.LabCode.GDParticleBubbleObjects2.length = 0;
gdjs.LabCode.GDParticleBubbleObjects3.length = 0;
gdjs.LabCode.GDProjectileObjects1.length = 0;
gdjs.LabCode.GDProjectileObjects2.length = 0;
gdjs.LabCode.GDProjectileObjects3.length = 0;
gdjs.LabCode.GDFloatingNumberObjects1.length = 0;
gdjs.LabCode.GDFloatingNumberObjects2.length = 0;
gdjs.LabCode.GDFloatingNumberObjects3.length = 0;
gdjs.LabCode.GDShieldHaloObjects1.length = 0;
gdjs.LabCode.GDShieldHaloObjects2.length = 0;
gdjs.LabCode.GDShieldHaloObjects3.length = 0;
gdjs.LabCode.GDMessagePanelObjects1.length = 0;
gdjs.LabCode.GDMessagePanelObjects2.length = 0;
gdjs.LabCode.GDMessagePanelObjects3.length = 0;
gdjs.LabCode.GDMessageObjects1.length = 0;
gdjs.LabCode.GDMessageObjects2.length = 0;
gdjs.LabCode.GDMessageObjects3.length = 0;
gdjs.LabCode.GDCreatorObjects1.length = 0;
gdjs.LabCode.GDCreatorObjects2.length = 0;
gdjs.LabCode.GDCreatorObjects3.length = 0;
gdjs.LabCode.GDCreatorLabelObjects1.length = 0;
gdjs.LabCode.GDCreatorLabelObjects2.length = 0;
gdjs.LabCode.GDCreatorLabelObjects3.length = 0;
gdjs.LabCode.GDCameraObjects1.length = 0;
gdjs.LabCode.GDCameraObjects2.length = 0;
gdjs.LabCode.GDCameraObjects3.length = 0;
gdjs.LabCode.GDCameraLabelObjects1.length = 0;
gdjs.LabCode.GDCameraLabelObjects2.length = 0;
gdjs.LabCode.GDCameraLabelObjects3.length = 0;
gdjs.LabCode.GDPlayerHUDObjects1.length = 0;
gdjs.LabCode.GDPlayerHUDObjects2.length = 0;
gdjs.LabCode.GDPlayerHUDObjects3.length = 0;
gdjs.LabCode.GDPlayerNameObjects1.length = 0;
gdjs.LabCode.GDPlayerNameObjects2.length = 0;
gdjs.LabCode.GDPlayerNameObjects3.length = 0;
gdjs.LabCode.GDHealthTrackObjects1.length = 0;
gdjs.LabCode.GDHealthTrackObjects2.length = 0;
gdjs.LabCode.GDHealthTrackObjects3.length = 0;
gdjs.LabCode.GDHealthBarObjects1.length = 0;
gdjs.LabCode.GDHealthBarObjects2.length = 0;
gdjs.LabCode.GDHealthBarObjects3.length = 0;
gdjs.LabCode.GDHealthValueObjects1.length = 0;
gdjs.LabCode.GDHealthValueObjects2.length = 0;
gdjs.LabCode.GDHealthValueObjects3.length = 0;
gdjs.LabCode.GDEnergyTrackObjects1.length = 0;
gdjs.LabCode.GDEnergyTrackObjects2.length = 0;
gdjs.LabCode.GDEnergyTrackObjects3.length = 0;
gdjs.LabCode.GDEnergyBarObjects1.length = 0;
gdjs.LabCode.GDEnergyBarObjects2.length = 0;
gdjs.LabCode.GDEnergyBarObjects3.length = 0;
gdjs.LabCode.GDEnergyValueObjects1.length = 0;
gdjs.LabCode.GDEnergyValueObjects2.length = 0;
gdjs.LabCode.GDEnergyValueObjects3.length = 0;
gdjs.LabCode.GDResearchHUDObjects1.length = 0;
gdjs.LabCode.GDResearchHUDObjects2.length = 0;
gdjs.LabCode.GDResearchHUDObjects3.length = 0;
gdjs.LabCode.GDStatsObjects1.length = 0;
gdjs.LabCode.GDStatsObjects2.length = 0;
gdjs.LabCode.GDStatsObjects3.length = 0;
gdjs.LabCode.GDMonsterBodyObjects1.length = 0;
gdjs.LabCode.GDMonsterBodyObjects2.length = 0;
gdjs.LabCode.GDMonsterBodyObjects3.length = 0;
gdjs.LabCode.GDMonsterEyesObjects1.length = 0;
gdjs.LabCode.GDMonsterEyesObjects2.length = 0;
gdjs.LabCode.GDMonsterEyesObjects3.length = 0;
gdjs.LabCode.GDMonsterMouthObjects1.length = 0;
gdjs.LabCode.GDMonsterMouthObjects2.length = 0;
gdjs.LabCode.GDMonsterMouthObjects3.length = 0;
gdjs.LabCode.GDMonsterArmsObjects1.length = 0;
gdjs.LabCode.GDMonsterArmsObjects2.length = 0;
gdjs.LabCode.GDMonsterArmsObjects3.length = 0;
gdjs.LabCode.GDMonsterLegsObjects1.length = 0;
gdjs.LabCode.GDMonsterLegsObjects2.length = 0;
gdjs.LabCode.GDMonsterLegsObjects3.length = 0;
gdjs.LabCode.GDMonsterHornsObjects1.length = 0;
gdjs.LabCode.GDMonsterHornsObjects2.length = 0;
gdjs.LabCode.GDMonsterHornsObjects3.length = 0;
gdjs.LabCode.GDMonsterNoseObjects1.length = 0;
gdjs.LabCode.GDMonsterNoseObjects2.length = 0;
gdjs.LabCode.GDMonsterNoseObjects3.length = 0;
gdjs.LabCode.GDMonsterEarsObjects1.length = 0;
gdjs.LabCode.GDMonsterEarsObjects2.length = 0;
gdjs.LabCode.GDMonsterEarsObjects3.length = 0;
gdjs.LabCode.GDMonsterTailObjects1.length = 0;
gdjs.LabCode.GDMonsterTailObjects2.length = 0;
gdjs.LabCode.GDMonsterTailObjects3.length = 0;
gdjs.LabCode.GDMonsterWingsObjects1.length = 0;
gdjs.LabCode.GDMonsterWingsObjects2.length = 0;
gdjs.LabCode.GDMonsterWingsObjects3.length = 0;
gdjs.LabCode.GDNameTextObjects1.length = 0;
gdjs.LabCode.GDNameTextObjects2.length = 0;
gdjs.LabCode.GDNameTextObjects3.length = 0;
gdjs.LabCode.GDFoodBowlObjects1.length = 0;
gdjs.LabCode.GDFoodBowlObjects2.length = 0;
gdjs.LabCode.GDFoodBowlObjects3.length = 0;
gdjs.LabCode.GDGiftObjects1.length = 0;
gdjs.LabCode.GDGiftObjects2.length = 0;
gdjs.LabCode.GDGiftObjects3.length = 0;
gdjs.LabCode.GDAdventurePanelObjects1.length = 0;
gdjs.LabCode.GDAdventurePanelObjects2.length = 0;
gdjs.LabCode.GDAdventurePanelObjects3.length = 0;
gdjs.LabCode.GDAdventureHintObjects1.length = 0;
gdjs.LabCode.GDAdventureHintObjects2.length = 0;
gdjs.LabCode.GDAdventureHintObjects3.length = 0;
gdjs.LabCode.GDRoomCaptionObjects1.length = 0;
gdjs.LabCode.GDRoomCaptionObjects2.length = 0;
gdjs.LabCode.GDRoomCaptionObjects3.length = 0;
gdjs.LabCode.GDTrophy0Objects1.length = 0;
gdjs.LabCode.GDTrophy0Objects2.length = 0;
gdjs.LabCode.GDTrophy0Objects3.length = 0;
gdjs.LabCode.GDTrophy1Objects1.length = 0;
gdjs.LabCode.GDTrophy1Objects2.length = 0;
gdjs.LabCode.GDTrophy1Objects3.length = 0;
gdjs.LabCode.GDTrophy2Objects1.length = 0;
gdjs.LabCode.GDTrophy2Objects2.length = 0;
gdjs.LabCode.GDTrophy2Objects3.length = 0;
gdjs.LabCode.GDTrophiesHintObjects1.length = 0;
gdjs.LabCode.GDTrophiesHintObjects2.length = 0;
gdjs.LabCode.GDTrophiesHintObjects3.length = 0;
gdjs.LabCode.GDFeedObjects1.length = 0;
gdjs.LabCode.GDFeedObjects2.length = 0;
gdjs.LabCode.GDFeedObjects3.length = 0;
gdjs.LabCode.GDFeedLabelObjects1.length = 0;
gdjs.LabCode.GDFeedLabelObjects2.length = 0;
gdjs.LabCode.GDFeedLabelObjects3.length = 0;
gdjs.LabCode.GDTrainObjects1.length = 0;
gdjs.LabCode.GDTrainObjects2.length = 0;
gdjs.LabCode.GDTrainObjects3.length = 0;
gdjs.LabCode.GDTrainLabelObjects1.length = 0;
gdjs.LabCode.GDTrainLabelObjects2.length = 0;
gdjs.LabCode.GDTrainLabelObjects3.length = 0;
gdjs.LabCode.GDRestObjects1.length = 0;
gdjs.LabCode.GDRestObjects2.length = 0;
gdjs.LabCode.GDRestObjects3.length = 0;
gdjs.LabCode.GDRestLabelObjects1.length = 0;
gdjs.LabCode.GDRestLabelObjects2.length = 0;
gdjs.LabCode.GDRestLabelObjects3.length = 0;
gdjs.LabCode.GDDecorObjects1.length = 0;
gdjs.LabCode.GDDecorObjects2.length = 0;
gdjs.LabCode.GDDecorObjects3.length = 0;
gdjs.LabCode.GDDecorLabelObjects1.length = 0;
gdjs.LabCode.GDDecorLabelObjects2.length = 0;
gdjs.LabCode.GDDecorLabelObjects3.length = 0;
gdjs.LabCode.GDBattleObjects1.length = 0;
gdjs.LabCode.GDBattleObjects2.length = 0;
gdjs.LabCode.GDBattleObjects3.length = 0;
gdjs.LabCode.GDBattleLabelObjects1.length = 0;
gdjs.LabCode.GDBattleLabelObjects2.length = 0;
gdjs.LabCode.GDBattleLabelObjects3.length = 0;


return;

}

gdjs['LabCode'] = gdjs.LabCode;

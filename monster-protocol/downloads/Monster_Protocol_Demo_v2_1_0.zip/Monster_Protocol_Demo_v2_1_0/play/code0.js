gdjs.MonsterCreatorCode = {};
gdjs.MonsterCreatorCode.localVariables = [];
gdjs.MonsterCreatorCode.idToCallbackMap = new Map();
gdjs.MonsterCreatorCode.GDBackdropObjects1= [];
gdjs.MonsterCreatorCode.GDBackdropObjects2= [];
gdjs.MonsterCreatorCode.GDBackdropObjects3= [];
gdjs.MonsterCreatorCode.GDBrandObjects1= [];
gdjs.MonsterCreatorCode.GDBrandObjects2= [];
gdjs.MonsterCreatorCode.GDBrandObjects3= [];
gdjs.MonsterCreatorCode.GDEditionObjects1= [];
gdjs.MonsterCreatorCode.GDEditionObjects2= [];
gdjs.MonsterCreatorCode.GDEditionObjects3= [];
gdjs.MonsterCreatorCode.GDTitleObjects1= [];
gdjs.MonsterCreatorCode.GDTitleObjects2= [];
gdjs.MonsterCreatorCode.GDTitleObjects3= [];
gdjs.MonsterCreatorCode.GDKickerObjects1= [];
gdjs.MonsterCreatorCode.GDKickerObjects2= [];
gdjs.MonsterCreatorCode.GDKickerObjects3= [];
gdjs.MonsterCreatorCode.GDPortraitPanelObjects1= [];
gdjs.MonsterCreatorCode.GDPortraitPanelObjects2= [];
gdjs.MonsterCreatorCode.GDPortraitPanelObjects3= [];
gdjs.MonsterCreatorCode.GDPartPanelObjects1= [];
gdjs.MonsterCreatorCode.GDPartPanelObjects2= [];
gdjs.MonsterCreatorCode.GDPartPanelObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterBodyObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterBodyObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterBodyObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterEyesObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterEyesObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterEyesObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterMouthObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterMouthObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterMouthObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterArmsObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterArmsObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterArmsObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterLegsObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterLegsObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterLegsObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterHornsObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterHornsObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterHornsObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterNoseObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterNoseObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterNoseObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterEarsObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterEarsObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterEarsObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterTailObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterTailObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterTailObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterWingsObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterWingsObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterWingsObjects3= [];
gdjs.MonsterCreatorCode.GDNameTextObjects1= [];
gdjs.MonsterCreatorCode.GDNameTextObjects2= [];
gdjs.MonsterCreatorCode.GDNameTextObjects3= [];
gdjs.MonsterCreatorCode.GDCombinationObjects1= [];
gdjs.MonsterCreatorCode.GDCombinationObjects2= [];
gdjs.MonsterCreatorCode.GDCombinationObjects3= [];
gdjs.MonsterCreatorCode.GDBodyTitleObjects1= [];
gdjs.MonsterCreatorCode.GDBodyTitleObjects2= [];
gdjs.MonsterCreatorCode.GDBodyTitleObjects3= [];
gdjs.MonsterCreatorCode.GDBodyPrevObjects1= [];
gdjs.MonsterCreatorCode.GDBodyPrevObjects2= [];
gdjs.MonsterCreatorCode.GDBodyPrevObjects3= [];
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDBodyNextObjects1= [];
gdjs.MonsterCreatorCode.GDBodyNextObjects2= [];
gdjs.MonsterCreatorCode.GDBodyNextObjects3= [];
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDBodyCountObjects1= [];
gdjs.MonsterCreatorCode.GDBodyCountObjects2= [];
gdjs.MonsterCreatorCode.GDBodyCountObjects3= [];
gdjs.MonsterCreatorCode.GDEyesTitleObjects1= [];
gdjs.MonsterCreatorCode.GDEyesTitleObjects2= [];
gdjs.MonsterCreatorCode.GDEyesTitleObjects3= [];
gdjs.MonsterCreatorCode.GDEyesPrevObjects1= [];
gdjs.MonsterCreatorCode.GDEyesPrevObjects2= [];
gdjs.MonsterCreatorCode.GDEyesPrevObjects3= [];
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDEyesNextObjects1= [];
gdjs.MonsterCreatorCode.GDEyesNextObjects2= [];
gdjs.MonsterCreatorCode.GDEyesNextObjects3= [];
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDEyesCountObjects1= [];
gdjs.MonsterCreatorCode.GDEyesCountObjects2= [];
gdjs.MonsterCreatorCode.GDEyesCountObjects3= [];
gdjs.MonsterCreatorCode.GDMouthTitleObjects1= [];
gdjs.MonsterCreatorCode.GDMouthTitleObjects2= [];
gdjs.MonsterCreatorCode.GDMouthTitleObjects3= [];
gdjs.MonsterCreatorCode.GDMouthPrevObjects1= [];
gdjs.MonsterCreatorCode.GDMouthPrevObjects2= [];
gdjs.MonsterCreatorCode.GDMouthPrevObjects3= [];
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDMouthNextObjects1= [];
gdjs.MonsterCreatorCode.GDMouthNextObjects2= [];
gdjs.MonsterCreatorCode.GDMouthNextObjects3= [];
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDMouthCountObjects1= [];
gdjs.MonsterCreatorCode.GDMouthCountObjects2= [];
gdjs.MonsterCreatorCode.GDMouthCountObjects3= [];
gdjs.MonsterCreatorCode.GDArmsTitleObjects1= [];
gdjs.MonsterCreatorCode.GDArmsTitleObjects2= [];
gdjs.MonsterCreatorCode.GDArmsTitleObjects3= [];
gdjs.MonsterCreatorCode.GDArmsPrevObjects1= [];
gdjs.MonsterCreatorCode.GDArmsPrevObjects2= [];
gdjs.MonsterCreatorCode.GDArmsPrevObjects3= [];
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDArmsNextObjects1= [];
gdjs.MonsterCreatorCode.GDArmsNextObjects2= [];
gdjs.MonsterCreatorCode.GDArmsNextObjects3= [];
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDArmsCountObjects1= [];
gdjs.MonsterCreatorCode.GDArmsCountObjects2= [];
gdjs.MonsterCreatorCode.GDArmsCountObjects3= [];
gdjs.MonsterCreatorCode.GDLegsTitleObjects1= [];
gdjs.MonsterCreatorCode.GDLegsTitleObjects2= [];
gdjs.MonsterCreatorCode.GDLegsTitleObjects3= [];
gdjs.MonsterCreatorCode.GDLegsPrevObjects1= [];
gdjs.MonsterCreatorCode.GDLegsPrevObjects2= [];
gdjs.MonsterCreatorCode.GDLegsPrevObjects3= [];
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDLegsNextObjects1= [];
gdjs.MonsterCreatorCode.GDLegsNextObjects2= [];
gdjs.MonsterCreatorCode.GDLegsNextObjects3= [];
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDLegsCountObjects1= [];
gdjs.MonsterCreatorCode.GDLegsCountObjects2= [];
gdjs.MonsterCreatorCode.GDLegsCountObjects3= [];
gdjs.MonsterCreatorCode.GDHornsTitleObjects1= [];
gdjs.MonsterCreatorCode.GDHornsTitleObjects2= [];
gdjs.MonsterCreatorCode.GDHornsTitleObjects3= [];
gdjs.MonsterCreatorCode.GDHornsPrevObjects1= [];
gdjs.MonsterCreatorCode.GDHornsPrevObjects2= [];
gdjs.MonsterCreatorCode.GDHornsPrevObjects3= [];
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDHornsNextObjects1= [];
gdjs.MonsterCreatorCode.GDHornsNextObjects2= [];
gdjs.MonsterCreatorCode.GDHornsNextObjects3= [];
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDHornsCountObjects1= [];
gdjs.MonsterCreatorCode.GDHornsCountObjects2= [];
gdjs.MonsterCreatorCode.GDHornsCountObjects3= [];
gdjs.MonsterCreatorCode.GDNoseTitleObjects1= [];
gdjs.MonsterCreatorCode.GDNoseTitleObjects2= [];
gdjs.MonsterCreatorCode.GDNoseTitleObjects3= [];
gdjs.MonsterCreatorCode.GDNosePrevObjects1= [];
gdjs.MonsterCreatorCode.GDNosePrevObjects2= [];
gdjs.MonsterCreatorCode.GDNosePrevObjects3= [];
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDNoseNextObjects1= [];
gdjs.MonsterCreatorCode.GDNoseNextObjects2= [];
gdjs.MonsterCreatorCode.GDNoseNextObjects3= [];
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDNoseCountObjects1= [];
gdjs.MonsterCreatorCode.GDNoseCountObjects2= [];
gdjs.MonsterCreatorCode.GDNoseCountObjects3= [];
gdjs.MonsterCreatorCode.GDEarsTitleObjects1= [];
gdjs.MonsterCreatorCode.GDEarsTitleObjects2= [];
gdjs.MonsterCreatorCode.GDEarsTitleObjects3= [];
gdjs.MonsterCreatorCode.GDEarsPrevObjects1= [];
gdjs.MonsterCreatorCode.GDEarsPrevObjects2= [];
gdjs.MonsterCreatorCode.GDEarsPrevObjects3= [];
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDEarsNextObjects1= [];
gdjs.MonsterCreatorCode.GDEarsNextObjects2= [];
gdjs.MonsterCreatorCode.GDEarsNextObjects3= [];
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDEarsCountObjects1= [];
gdjs.MonsterCreatorCode.GDEarsCountObjects2= [];
gdjs.MonsterCreatorCode.GDEarsCountObjects3= [];
gdjs.MonsterCreatorCode.GDTailTitleObjects1= [];
gdjs.MonsterCreatorCode.GDTailTitleObjects2= [];
gdjs.MonsterCreatorCode.GDTailTitleObjects3= [];
gdjs.MonsterCreatorCode.GDTailPrevObjects1= [];
gdjs.MonsterCreatorCode.GDTailPrevObjects2= [];
gdjs.MonsterCreatorCode.GDTailPrevObjects3= [];
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDTailNextObjects1= [];
gdjs.MonsterCreatorCode.GDTailNextObjects2= [];
gdjs.MonsterCreatorCode.GDTailNextObjects3= [];
gdjs.MonsterCreatorCode.GDTailNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDTailNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDTailNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDTailCountObjects1= [];
gdjs.MonsterCreatorCode.GDTailCountObjects2= [];
gdjs.MonsterCreatorCode.GDTailCountObjects3= [];
gdjs.MonsterCreatorCode.GDWingsTitleObjects1= [];
gdjs.MonsterCreatorCode.GDWingsTitleObjects2= [];
gdjs.MonsterCreatorCode.GDWingsTitleObjects3= [];
gdjs.MonsterCreatorCode.GDWingsPrevObjects1= [];
gdjs.MonsterCreatorCode.GDWingsPrevObjects2= [];
gdjs.MonsterCreatorCode.GDWingsPrevObjects3= [];
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDWingsNextObjects1= [];
gdjs.MonsterCreatorCode.GDWingsNextObjects2= [];
gdjs.MonsterCreatorCode.GDWingsNextObjects3= [];
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDWingsCountObjects1= [];
gdjs.MonsterCreatorCode.GDWingsCountObjects2= [];
gdjs.MonsterCreatorCode.GDWingsCountObjects3= [];
gdjs.MonsterCreatorCode.GDRandomObjects1= [];
gdjs.MonsterCreatorCode.GDRandomObjects2= [];
gdjs.MonsterCreatorCode.GDRandomObjects3= [];
gdjs.MonsterCreatorCode.GDRandomLabelObjects1= [];
gdjs.MonsterCreatorCode.GDRandomLabelObjects2= [];
gdjs.MonsterCreatorCode.GDRandomLabelObjects3= [];
gdjs.MonsterCreatorCode.GDRenameObjects1= [];
gdjs.MonsterCreatorCode.GDRenameObjects2= [];
gdjs.MonsterCreatorCode.GDRenameObjects3= [];
gdjs.MonsterCreatorCode.GDRenameLabelObjects1= [];
gdjs.MonsterCreatorCode.GDRenameLabelObjects2= [];
gdjs.MonsterCreatorCode.GDRenameLabelObjects3= [];
gdjs.MonsterCreatorCode.GDSaveObjects1= [];
gdjs.MonsterCreatorCode.GDSaveObjects2= [];
gdjs.MonsterCreatorCode.GDSaveObjects3= [];
gdjs.MonsterCreatorCode.GDSaveLabelObjects1= [];
gdjs.MonsterCreatorCode.GDSaveLabelObjects2= [];
gdjs.MonsterCreatorCode.GDSaveLabelObjects3= [];
gdjs.MonsterCreatorCode.GDLoadObjects1= [];
gdjs.MonsterCreatorCode.GDLoadObjects2= [];
gdjs.MonsterCreatorCode.GDLoadObjects3= [];
gdjs.MonsterCreatorCode.GDLoadLabelObjects1= [];
gdjs.MonsterCreatorCode.GDLoadLabelObjects2= [];
gdjs.MonsterCreatorCode.GDLoadLabelObjects3= [];
gdjs.MonsterCreatorCode.GDToLabObjects1= [];
gdjs.MonsterCreatorCode.GDToLabObjects2= [];
gdjs.MonsterCreatorCode.GDToLabObjects3= [];
gdjs.MonsterCreatorCode.GDToLabLabelObjects1= [];
gdjs.MonsterCreatorCode.GDToLabLabelObjects2= [];
gdjs.MonsterCreatorCode.GDToLabLabelObjects3= [];
gdjs.MonsterCreatorCode.GDHeaderShadeObjects1= [];
gdjs.MonsterCreatorCode.GDHeaderShadeObjects2= [];
gdjs.MonsterCreatorCode.GDHeaderShadeObjects3= [];
gdjs.MonsterCreatorCode.GDMusicObjects1= [];
gdjs.MonsterCreatorCode.GDMusicObjects2= [];
gdjs.MonsterCreatorCode.GDMusicObjects3= [];
gdjs.MonsterCreatorCode.GDMusicLabelObjects1= [];
gdjs.MonsterCreatorCode.GDMusicLabelObjects2= [];
gdjs.MonsterCreatorCode.GDMusicLabelObjects3= [];
gdjs.MonsterCreatorCode.GDParticleSparkObjects1= [];
gdjs.MonsterCreatorCode.GDParticleSparkObjects2= [];
gdjs.MonsterCreatorCode.GDParticleSparkObjects3= [];
gdjs.MonsterCreatorCode.GDParticleHeartObjects1= [];
gdjs.MonsterCreatorCode.GDParticleHeartObjects2= [];
gdjs.MonsterCreatorCode.GDParticleHeartObjects3= [];
gdjs.MonsterCreatorCode.GDParticleBubbleObjects1= [];
gdjs.MonsterCreatorCode.GDParticleBubbleObjects2= [];
gdjs.MonsterCreatorCode.GDParticleBubbleObjects3= [];
gdjs.MonsterCreatorCode.GDProjectileObjects1= [];
gdjs.MonsterCreatorCode.GDProjectileObjects2= [];
gdjs.MonsterCreatorCode.GDProjectileObjects3= [];
gdjs.MonsterCreatorCode.GDFloatingNumberObjects1= [];
gdjs.MonsterCreatorCode.GDFloatingNumberObjects2= [];
gdjs.MonsterCreatorCode.GDFloatingNumberObjects3= [];
gdjs.MonsterCreatorCode.GDShieldHaloObjects1= [];
gdjs.MonsterCreatorCode.GDShieldHaloObjects2= [];
gdjs.MonsterCreatorCode.GDShieldHaloObjects3= [];


gdjs.MonsterCreatorCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MonsterArms"), gdjs.MonsterCreatorCode.GDMonsterArmsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterBody"), gdjs.MonsterCreatorCode.GDMonsterBodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterEars"), gdjs.MonsterCreatorCode.GDMonsterEarsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterEyes"), gdjs.MonsterCreatorCode.GDMonsterEyesObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterHorns"), gdjs.MonsterCreatorCode.GDMonsterHornsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterLegs"), gdjs.MonsterCreatorCode.GDMonsterLegsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterMouth"), gdjs.MonsterCreatorCode.GDMonsterMouthObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterNose"), gdjs.MonsterCreatorCode.GDMonsterNoseObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterTail"), gdjs.MonsterCreatorCode.GDMonsterTailObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterWings"), gdjs.MonsterCreatorCode.GDMonsterWingsObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterBodyObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterBodyObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterEyesObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterEyesObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterMouthObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterMouthObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterArmsObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterArmsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterLegsObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterLegsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterHornsObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterHornsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterNoseObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterNoseObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterEarsObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterEarsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterTailObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterTailObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterWingsObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterWingsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)));
}
}
}

}


};gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDBodyNextObjects2Objects = Hashtable.newFrom({"BodyNext": gdjs.MonsterCreatorCode.GDBodyNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDBodyPrevObjects2Objects = Hashtable.newFrom({"BodyPrev": gdjs.MonsterCreatorCode.GDBodyPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEyesNextObjects2Objects = Hashtable.newFrom({"EyesNext": gdjs.MonsterCreatorCode.GDEyesNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEyesPrevObjects2Objects = Hashtable.newFrom({"EyesPrev": gdjs.MonsterCreatorCode.GDEyesPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDMouthNextObjects2Objects = Hashtable.newFrom({"MouthNext": gdjs.MonsterCreatorCode.GDMouthNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDMouthPrevObjects2Objects = Hashtable.newFrom({"MouthPrev": gdjs.MonsterCreatorCode.GDMouthPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDArmsNextObjects2Objects = Hashtable.newFrom({"ArmsNext": gdjs.MonsterCreatorCode.GDArmsNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDArmsPrevObjects2Objects = Hashtable.newFrom({"ArmsPrev": gdjs.MonsterCreatorCode.GDArmsPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDLegsNextObjects2Objects = Hashtable.newFrom({"LegsNext": gdjs.MonsterCreatorCode.GDLegsNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDLegsPrevObjects2Objects = Hashtable.newFrom({"LegsPrev": gdjs.MonsterCreatorCode.GDLegsPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDHornsNextObjects2Objects = Hashtable.newFrom({"HornsNext": gdjs.MonsterCreatorCode.GDHornsNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDHornsPrevObjects2Objects = Hashtable.newFrom({"HornsPrev": gdjs.MonsterCreatorCode.GDHornsPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDNoseNextObjects2Objects = Hashtable.newFrom({"NoseNext": gdjs.MonsterCreatorCode.GDNoseNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDNosePrevObjects2Objects = Hashtable.newFrom({"NosePrev": gdjs.MonsterCreatorCode.GDNosePrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEarsNextObjects2Objects = Hashtable.newFrom({"EarsNext": gdjs.MonsterCreatorCode.GDEarsNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEarsPrevObjects2Objects = Hashtable.newFrom({"EarsPrev": gdjs.MonsterCreatorCode.GDEarsPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDTailNextObjects2Objects = Hashtable.newFrom({"TailNext": gdjs.MonsterCreatorCode.GDTailNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDTailPrevObjects2Objects = Hashtable.newFrom({"TailPrev": gdjs.MonsterCreatorCode.GDTailPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDWingsNextObjects2Objects = Hashtable.newFrom({"WingsNext": gdjs.MonsterCreatorCode.GDWingsNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDWingsPrevObjects1Objects = Hashtable.newFrom({"WingsPrev": gdjs.MonsterCreatorCode.GDWingsPrevObjects1});
gdjs.MonsterCreatorCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BodyNext"), gdjs.MonsterCreatorCode.GDBodyNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDBodyNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13064332);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) + 1, 6));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BodyPrev"), gdjs.MonsterCreatorCode.GDBodyPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDBodyPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13065588);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) + 6 - 1, 6));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("EyesNext"), gdjs.MonsterCreatorCode.GDEyesNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEyesNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13066836);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) + 1, 8));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("EyesPrev"), gdjs.MonsterCreatorCode.GDEyesPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEyesPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13068084);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) + 8 - 1, 8));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MouthNext"), gdjs.MonsterCreatorCode.GDMouthNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDMouthNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13069340);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) + 1, 6));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MouthPrev"), gdjs.MonsterCreatorCode.GDMouthPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDMouthPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13070628);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) + 6 - 1, 6));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ArmsNext"), gdjs.MonsterCreatorCode.GDArmsNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDArmsNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13071884);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ArmsPrev"), gdjs.MonsterCreatorCode.GDArmsPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDArmsPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13073140);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) + 4 - 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LegsNext"), gdjs.MonsterCreatorCode.GDLegsNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDLegsNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13074396);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LegsPrev"), gdjs.MonsterCreatorCode.GDLegsPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDLegsPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13075692);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) + 4 - 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HornsNext"), gdjs.MonsterCreatorCode.GDHornsNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDHornsNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13076964);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HornsPrev"), gdjs.MonsterCreatorCode.GDHornsPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDHornsPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13078220);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) + 4 - 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoseNext"), gdjs.MonsterCreatorCode.GDNoseNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDNoseNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13079476);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NosePrev"), gdjs.MonsterCreatorCode.GDNosePrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDNosePrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13080732);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) + 4 - 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("EarsNext"), gdjs.MonsterCreatorCode.GDEarsNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEarsNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13081988);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("EarsPrev"), gdjs.MonsterCreatorCode.GDEarsPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEarsPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13083244);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) + 4 - 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TailNext"), gdjs.MonsterCreatorCode.GDTailNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDTailNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13084500);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TailPrev"), gdjs.MonsterCreatorCode.GDTailPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDTailPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13085852);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) + 4 - 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WingsNext"), gdjs.MonsterCreatorCode.GDWingsNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDWingsNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13087124);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WingsPrev"), gdjs.MonsterCreatorCode.GDWingsPrevObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDWingsPrevObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13088380);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) + 4 - 1, 4));
}
}

}


};gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDRandomObjects1Objects = Hashtable.newFrom({"Random": gdjs.MonsterCreatorCode.GDRandomObjects1});
gdjs.MonsterCreatorCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Random"), gdjs.MonsterCreatorCode.GDRandomObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDRandomObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13089900);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.random(5));
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(gdjs.random(7));
}
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(gdjs.random(5));
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(gdjs.random(3));
}
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.random(3));
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.random(3));
}
{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.random(3));
}
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.random(3));
}
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.random(3));
}
{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.random(3));
}
}

}


};gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDToLabObjects1Objects = Hashtable.newFrom({"ToLab": gdjs.MonsterCreatorCode.GDToLabObjects1});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDRenameObjects1Objects = Hashtable.newFrom({"Rename": gdjs.MonsterCreatorCode.GDRenameObjects1});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDSaveObjects1Objects = Hashtable.newFrom({"Save": gdjs.MonsterCreatorCode.GDSaveObjects1});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDLoadObjects1Objects = Hashtable.newFrom({"Load": gdjs.MonsterCreatorCode.GDLoadObjects1});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDMusicObjects2Objects = Hashtable.newFrom({"Music": gdjs.MonsterCreatorCode.GDMusicObjects2});
gdjs.MonsterCreatorCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Music"), gdjs.MonsterCreatorCode.GDMusicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDMusicObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13099124);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(28).setNumber(1 - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(28)));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(28)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MusicLabel"), gdjs.MonsterCreatorCode.GDMusicLabelObjects2);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMusicLabelObjects2.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMusicLabelObjects2[i].setString("Звук: выкл");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(28)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MusicLabel"), gdjs.MonsterCreatorCode.GDMusicLabelObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMusicLabelObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMusicLabelObjects1[i].setString("Звук: вкл");
}
}
}

}


};gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDMonsterBodyObjects1Objects = Hashtable.newFrom({"MonsterBody": gdjs.MonsterCreatorCode.GDMonsterBodyObjects1});
gdjs.MonsterCreatorCode.userFunc0xbc8770 = function GDJSInlineCode(runtimeScene) {
"use strict";
/* Ready-made visual/audio kit. All health, energy, rewards and turn rules are native events. */
if (!globalThis.MonsterWorld) {
  globalThis.MonsterWorld = (() => {
    let scene,ctx,music=null,track='',audioContext=null,unlocked=false;
    const events=[];
    const record=(type,detail={})=>{events.push({type,...detail});if(events.length>40)events.shift();};
    const vars=()=>scene.getGame().getVariables();
    const num=n=>vars().get(n).getAsNumber();
    const sv=n=>scene.getVariables().get(n).getAsNumber();
    const resource=name=>{const r=scene.getGame().getGameData().resources.resources.find(r=>r.name==='assets/'+name);return r?scene.getGame().getResourceLoader().getFullUrl(r.file):null;};
    function syncMusic(){
      if(!scene||!unlocked)return;
      const desired=scene.getName()==='Arena'?'battle-loop.wav':'home-loop.wav';
      if(!music||desired!==track){if(music)music.pause();const url=resource(desired);if(!url)return;music=new Audio(url);music.loop=true;music.volume=.25;track=desired;}
      music.volume=Math.max(0,Math.min(1,num('MusicVolume')/100));
      if(num('MusicOn')===1){if(music.paused)music.play().catch(()=>{});}else music.pause();
    }
    document.addEventListener('pointerdown',()=>{
      if(!scene)return;unlocked=true;
      const AudioCtx=globalThis.AudioContext||globalThis.webkitAudioContext;
      if(AudioCtx&&!audioContext)audioContext=new AudioCtx();
      if(audioContext?.state==='suspended')audioContext.resume().catch(()=>{});
      syncMusic();
    },{capture:true});
    document.addEventListener('visibilitychange',()=>{if(document.hidden){if(music)music.pause();}else syncMusic();});
    function sound(kind){
      if(!audioContext||audioContext.state!=='running'||num('MusicOn')!==1)return;
      const tones={attack:[392,784],hit:[120,65],good:[523,659,784],shield:[330,494],sleep:[262,330],error:[160,120]};
      (tones[kind]||tones.good).forEach((f,i)=>{const osc=audioContext.createOscillator(),gain=audioContext.createGain(),at=audioContext.currentTime+i*.07;osc.type=kind==='hit'?'triangle':'sine';osc.frequency.setValueAtTime(f,at);gain.gain.setValueAtTime(0,at);gain.gain.linearRampToValueAtTime(.075,at+.015);gain.gain.exponentialRampToValueAtTime(.001,at+.23);osc.connect(gain);gain.connect(audioContext.destination);osc.start(at);osc.stop(at+.25);});
    }
    function emit(type,x,y,count=12,color=null){
      for(let i=0;i<count&&ctx.particles.length<100;i++){
        const o=scene.createObject(type);if(!o)continue;
        const angle=Math.random()*Math.PI*2,speed=45+Math.random()*130,size=10+Math.random()*15;
        o.setPosition(x,y);o.setSize(size,size);o.setZOrder(80);if(color&&o.setColor)o.setColor(color);
        ctx.particles.push({o,x,y,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed-90,age:0,life:.7+Math.random()*.6,spin:Math.random()*180-90});
      }
    }
    function floating(text,x,y,color){const o=scene.createObject('FloatingNumber');if(!o)return;o.setString(text);o.setPosition(x,y);o.setZOrder(85);o.setColor(color);ctx.particles.push({o,x,y,vx:0,vy:-48,age:0,life:1.1,spin:0});}
    function bolt(){const o=scene.createObject('Projectile');if(!o)return;o.setSize(65,65);o.setZOrder(50);ctx.particles.push({o,projectile:true,age:0,life:.3});}
    function base(o){return {o,x:o.getX(),y:o.getY(),w:o.getWidth(),h:o.getHeight(),angle:o.getAngle()};}
    function initialize(next){
      scene=next;const objects=[];for(const cat of ['Body','Eyes','Mouth','Arms','Legs','Horns','Nose','Ears','Tail','Wings'])for(const o of scene.getObjects('Monster'+cat))objects.push({...base(o),cat});
      const body=objects.find(x=>x.cat==='Body');
      ctx={time:0,parts:objects,rival:scene.getObjects('Rival').map(base),heroX:body?body.x+body.w/2:400,heroY:body?body.y+body.h/2:400,particles:[],lastHP:num('Health'),lastEnemy:num('EnemyHP'),lastPhase:0,lastRound:num('Round'),react:0,heroHurt:0,enemyHurt:0,emission:0,barHealth:num('Health'),barEnergy:num('Energy'),barEnemy:num('EnemyHP'),buttons:[]};
      const buttonNames=['Music','Feed','Train','Rest','Battle','Decor','Attack','Shield','Heal','Creator','Camera','Retreat','Again','Home','Random','Rename','Save','Load','ToLab'];
      for(const o of scene.getAdhocListOfAllInstances())if(buttonNames.includes(o.getName())||/^(Body|Eyes|Mouth|Arms|Legs|Horns|Nose|Ears|Tail|Wings)(Next|Prev)$/.test(o.getName()))ctx.buttons.push(base(o));
      if(scene.getName()==='Final'){emit('ParticleSpark',870,300,45);sound('good');}
      record('scene',{name:scene.getName()});syncMusic();
    }
    function tick(next){
      if(scene!==next)initialize(next);
      const dt=Math.min(.05,Math.max(0,scene.getElapsedTime()/1000));ctx.time+=dt;ctx.react=Math.max(0,ctx.react-dt);ctx.heroHurt=Math.max(0,ctx.heroHurt-dt);ctx.enemyHurt=Math.max(0,ctx.enemyHurt-dt);
      const name=scene.getName(),phase=sv('Phase'),turn=sv('TurnTime'),kind=sv('ActionKind');
      const fx=num('VisualFX');if(fx){vars().get('VisualFX').setNumber(0);ctx.react=.9;
        if(fx===1){emit('ParticleHeart',ctx.heroX,ctx.heroY,13);floating('+20 энергии',ctx.heroX-80,ctx.heroY-100,'186;245;210');sound('good');}
        if(fx===2){emit('ParticleSpark',ctx.heroX,ctx.heroY,18);floating('+4 силы',ctx.heroX-60,ctx.heroY-110,'255;221;140');sound('good');}
        if(fx===3){emit('ParticleBubble',ctx.heroX,ctx.heroY,12);floating('Z z z…',ctx.heroX-40,ctx.heroY-120,'202;190;255');sound('sleep');}
        if(fx===4){emit('ParticleSpark',ctx.heroX,ctx.heroY-50,36);sound('good');}
        if(fx===5){emit('ParticleHeart',ctx.heroX,ctx.heroY,12);sound('good');}
        if(fx===6){floating('Нужно больше энергии',ctx.heroX-120,ctx.heroY-110,'255;191;165');sound('error');}
        record('reaction',{kind:fx});
      }
      if(num('PetRequest')){vars().get('PetRequest').setNumber(0);ctx.react=1.2;emit('ParticleHeart',ctx.heroX,ctx.heroY-70,18);sound('good');record('pet');}
      if(name==='Arena'&&phase===1&&ctx.lastPhase!==1){
        if(kind===1){bolt();sound('attack');record('player-attack');}
        if(kind===2){emit('ParticleBubble',ctx.heroX,ctx.heroY,15);sound('shield');record('shield');}
        if(kind===3)record('heal');
      }
      if(name==='Arena'&&phase===3&&ctx.lastPhase!==3){emit('ParticleSpark',970,365,12);sound('attack');record('enemy-counterattack');}
      const hp=num('Health'),enemy=num('EnemyHP');
      if(hp<ctx.lastHP){ctx.heroHurt=.28;emit('ParticleSpark',ctx.heroX,ctx.heroY,13);floating('−'+(ctx.lastHP-hp),ctx.heroX,ctx.heroY-80,'255;157;170');sound('hit');record('player-damage',{amount:ctx.lastHP-hp});}
      if(hp>ctx.lastHP&&name==='Arena')floating('+'+(hp-ctx.lastHP),ctx.heroX,ctx.heroY-90,'186;245;210');
      if(enemy<ctx.lastEnemy&&name==='Arena'){ctx.enemyHurt=.28;emit('ParticleSpark',965,380,20);floating('−'+(ctx.lastEnemy-enemy),960,300,'255;220;151');sound('hit');record('enemy-damage',{amount:ctx.lastEnemy-enemy});}
      ctx.lastHP=hp;ctx.lastEnemy=enemy;ctx.lastPhase=phase;
      const t=ctx.time,breath=1+.018*Math.sin(t*3),blink=(t%4.3)>.12&&(t%4.3)<.25;
      let lunge=0,jump=0;
      if(name==='Arena'&&kind===1&&phase>0&&phase<4)lunge=100*Math.sin(Math.PI*Math.min(1,turn/.62));
      if(ctx.react>0)jump=-Math.abs(Math.sin(ctx.react*10))*num('ReactionHeight');
      const shake=ctx.heroHurt>0?Math.sin(ctx.heroHurt*120)*9:0;
      for(const b of ctx.parts){
        const sx=breath,sy=1-.016*Math.sin(t*3);b.o.setSize(b.w*sx,b.h*sy*(b.cat==='Eyes'&&blink?.08:1));
        let x=ctx.heroX+(b.x-ctx.heroX)*sx+lunge+shake,y=ctx.heroY+(b.y-ctx.heroY)*sy+Math.sin(t*2.4)*num('IdleAmplitude')+jump;
        if(b.cat==='Eyes'&&blink)y+=b.h*.45;
        b.o.setPosition(x,y);b.o.setAngle(b.angle+(b.cat==='Arms'?Math.sin(t*3)*2:0));
        b.o.setOpacity(ctx.heroHurt>0&&Math.sin(ctx.heroHurt*80)>0?135:255);
      }
      for(const b of ctx.rival){
        let x=b.x,y=b.y+Math.sin(t*2.1)*6,angle=Math.sin(t*1.7)*2;
        if(phase===3)x-=140*Math.sin(Math.PI*Math.min(1,Math.max(0,(turn-.68)/.46)));
        b.o.setPosition(x,y);b.o.setAngle(angle);b.o.setSize(b.w*(1+.022*Math.sin(t*2.1)),b.h*(1-.018*Math.sin(t*2.1)));
        b.o.setOpacity(phase===5?Math.max(0,220-turn*350):ctx.enemyHurt>0?145:255);
      }
      const halo=scene.getObjects('ShieldHalo')[0];if(halo){if(name==='Arena'&&kind===2&&phase>0&&phase<5){halo.setPosition(ctx.heroX-85,ctx.heroY-60);halo.setSize(170,170);halo.setOpacity(180+50*Math.sin(t*8));}else halo.setPosition(-400,-400);}
      // Native scene sprites show the values; only their visual interpolation is here.
      for(const [field,key,max]of [['Health','barHealth',100],['Energy','barEnergy',100],['EnemyHealth','barEnemy',40+20*num('Round')]]){
        const target=field==='EnemyHealth'?enemy:num(field);ctx[key]+=(target-ctx[key])*Math.min(1,dt*12);
        const o=scene.getObjects(field+'Bar')[0];if(o){const width=field==='EnemyHealth'?241:225;o.setWidth(Math.max(.1,width*Math.max(0,ctx[key])/max));}
      }
      for(let i=0;i<3;i++){const trophy=scene.getObjects('Trophy'+i)[0];if(trophy)trophy.setOpacity(num('Badges')>i?255:55);}
      const input=scene.getGame().getInputManager(),mx=input.getMouseX(),my=input.getMouseY();
      for(const b of ctx.buttons){const hover=mx>=b.x&&mx<=b.x+b.w&&my>=b.y&&my<=b.y+b.h;const busy=name==='Arena'&&phase>0&&['Attack','Shield','Heal'].includes(b.o.getName());b.o.setOpacity(busy?125:255);b.o.setPosition(b.x,b.y+(hover&&!busy?-2:0));}
      ctx.emission+=dt;
      if(ctx.emission>.45){ctx.emission=0;if(name==='Lab')emit('ParticleBubble',1090,338,1);else if(name==='Final')emit('ParticleSpark',180+Math.random()*920,210,3);else if(name==='Arena')emit('ParticleBubble',90+Math.random()*1100,510,1);}
      ctx.particles=ctx.particles.filter(p=>{
        p.age+=dt;if(p.age>=p.life){p.o.deleteFromScene(scene);return false;}
        if(p.projectile){const f=p.age/p.life;p.o.setPosition(340+570*f,375-Math.sin(f*Math.PI)*65);p.o.setAngle(30+f*360);}
        else{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=35*dt;p.o.setPosition(p.x,p.y);if(p.spin)p.o.setAngle(p.o.getAngle()+p.spin*dt);}
        p.o.setOpacity(255*Math.min(1,(p.life-p.age)/.3));return true;
      });
      syncMusic();
    }
    window.addEventListener('pagehide',()=>{if(music)music.pause();if(audioContext)audioContext.suspend().catch(()=>{});});
    return {tick,events,getMusic:()=>music,inspect:()=>({scene:scene?.getName(),phase:scene?sv('Phase'):0,particles:ctx?.particles.length||0,musicOn:scene?num('MusicOn'):0,track})};
  })();
}
globalThis.MonsterWorld.tick(runtimeScene);
};
gdjs.MonsterCreatorCode.eventsList4 = function(runtimeScene) {

{


gdjs.MonsterCreatorCode.userFunc0xbc8770(runtimeScene);

}


};gdjs.MonsterCreatorCode.userFunc0xbc89b0 = function GDJSInlineCode(runtimeScene) {
"use strict";
/* Teacher-owned adapter. Gameplay lives in visible GDevelop events, not here. */
if (!globalThis.MonsterProtocol) {
  globalThis.MonsterProtocol = (() => {
    let scene, model=null, panel=null, webcam=null, stream=null, running=false, session=0, handEngine=null, handReady=null, frameTask=Promise.resolve();
    let candidate='', since=0, neutralSince=0, armed=true, lastCommand=-Infinity;
    const allowed=['ATTACK','SHIELD','HEAL','IDLE'];
    const state=()=>scene.getGame().getVariables();
    const set=(n,v)=>typeof v==='string'?state().get(n).setString(v):state().get(n).setNumber(v);
    const get=n=>state().get(n).getAsNumber();
    const status=s=>{const el=document.getElementById('mp-status');if(el)el.textContent=s;};
    function resource(name) {
      const data=scene.getGame().getGameData().resources.resources.find(r=>r.name==='assets/'+name);
      if (!data) throw Error('Ресурс не найден: '+name);
      return scene.getGame().getResourceLoader().getFullUrl(data.file);
    }
    const loadScript=(name,globalName)=>new Promise((resolve,reject)=>{
      if(globalThis[globalName])return resolve();
      const s=document.createElement('script');s.src=resource(name);s.onload=resolve;s.onerror=()=>reject(Error('Не загружена локальная библиотека '+name));document.head.append(s);
    });
    async function libraries(){await loadScript('tf.min.js','tf');await loadScript('tm.min.js','tmImage');}
    function resetGate(){candidate='';since=0;neutralSince=0;armed=true;lastCommand=-Infinity;}
    function gate(predictions,now=performance.now()) {
      const top=predictions.reduce((a,b)=>a.probability>b.probability?a:b,{className:'IDLE',probability:0});
      const label=top.className;
      if(top.probability<.85 || label==='IDLE') {
        candidate='';
        if(!neutralSince)neutralSince=now;
        if(now-neutralSince>=400)armed=true;
        return 0;
      }
      neutralSince=0;
      if(candidate!==label){candidate=label;since=now;return 0;}
      if(!armed || now-since<500 || now-lastCommand<1500)return 0;
      armed=false;lastCommand=now;
      return {ATTACK:1,SHIELD:2,HEAL:3}[label]||0;
    }
    function stop(){session++;running=false;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;if(webcam){webcam.srcObject=null;webcam.remove();webcam=null;}set('AICommand',0);resetGate();const retry=document.getElementById('mp-retry');if(retry)retry.hidden=false;status('Камера выключена. Кнопки игры доступны.');}
    function close(){stop();if(panel)panel.remove();panel=null;}
    function shell(title){
      close();panel=document.createElement('div');panel.id='mp-overlay';panel.setAttribute('role','dialog');panel.setAttribute('aria-label',title);
      panel.style.cssText='position:fixed;inset:0;z-index:99999;background:#100b20dd;display:grid;place-items:center;font:16px system-ui;color:#fff8ed';
      panel.innerHTML='<section style="background:#282039;border:1px solid #655276;border-radius:24px;padding:26px;width:min(680px,86vw);max-height:86vh;overflow:auto"><button id="mp-close" style="float:right">Закрыть ×</button><h2></h2><div id="mp-content"></div><p id="mp-status" role="status"></p></section>';
      panel.querySelector('h2').textContent=title;
      // The canvas must not receive clicks made on a modal control.
      for(const event of ['mousedown','mouseup','pointerdown','pointerup','touchstart','touchend'])panel.addEventListener(event,e=>e.stopPropagation());
      document.body.append(panel);panel.querySelector('#mp-close').onclick=close;
      return panel.querySelector('#mp-content');
    }
    function rename(){const root=shell('Имя твоего монстра');root.innerHTML='<label>Имя (до 24 символов)<br><input id="mp-name" maxlength="24" style="font:24px system-ui;padding:10px;margin:16px 0"></label><br><button id="mp-name-save">Готово</button>';
      root.querySelector('input').value=state().get('Name').getAsString();root.querySelector('button').onclick=()=>{const n=root.querySelector('input').value.trim();if(n){set('Name',n);close();}};
    }
    function validateLabels(m){const labels=m.getClassLabels();if(labels.length!==4||!allowed.every(n=>labels.includes(n)))throw Error('Нужны ровно 4 класса: ATTACK, SHIELD, HEAL, IDLE. Проверь регистр.');}
    async function replaceModel(next){try{validateLabels(next);}catch(e){next.model.dispose();throw e;}stop();if(model)model.model.dispose();model=next;status('Модель готова. Включи камеру; команды действуют только на арене.');}
    function missingFiles(files){
      const names=Array.from(files,f=>f.name);
      return ['model.json','metadata.json'].filter(n=>!names.includes(n));
    }
    async function loadLocal(files){const f=Array.from(files),find=n=>f.find(x=>x.name===n);const missing=missingFiles(f);if(missing.length)throw Error('Не хватает: '+missing.join(', ')+'. Нужен распакованный экспорт TensorFlow.js из Teachable Machine.');
      const meta=JSON.parse(await find('metadata.json').text());const spec=JSON.parse(await find('model.json').text());
      if(!Array.isArray(spec.weightsManifest)||!spec.modelTopology)throw Error('Этот JSON не похож на модель TensorFlow.js. game.json — проект GDevelop, а не файл ИИ.');
      const names=spec.weightsManifest.flatMap(g=>g.paths);const weights=names.map(n=>{const file=find(n);if(!file)throw Error('Не найден файл весов '+n);return file;});
      await libraries();
      const layers=await tf.loadLayersModel(tf.io.browserFiles([find('model.json'),...weights]));
      await replaceModel(new tmImage.CustomMobileNet(layers,meta));
    }
    async function demoModel(){await libraries();const response=await fetch(resource('demo-bundle.json'));if(!response.ok)throw Error('Не найден локальный комплект модели');const b=await response.json();const weightData=Uint8Array.from(atob(b.weightData),c=>c.charCodeAt(0)).buffer;const layers=await tf.loadLayersModel(tf.io.fromMemory(b.modelTopology,b.weightSpecs,weightData));await replaceModel(new tmImage.CustomMobileNet(layers,b.metadata));}
    // Same gesture vocabulary as the previous game. MediaPipe finds the hand;
    // readable distance rules turn its 21 landmarks into three commands.
    function handLabel(points){
      if(!points||points.length!==21)return 'IDLE';
      const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,(a.z||0)-(b.z||0));
      const [index,middle,ring,pinky]=[8,12,16,20].map(tip=>distance(points[tip],points[0])>distance(points[tip-2],points[0])*1.15);
      if(!index&&!middle&&!ring&&!pinky)return 'ATTACK';
      if(index&&middle&&ring&&pinky)return 'SHIELD';
      if(index&&middle&&!ring&&!pinky)return 'HEAL';
      return 'IDLE';
    }
    const links=[[0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],[5,9],[9,10],[10,11],[11,12],[9,13],[13,14],[14,15],[15,16],[13,17],[0,17],[17,18],[18,19],[19,20]];
    function deliver(label){
      const ready=scene.getName()==='Arena'&&scene.getVariables().get('Phase').getAsNumber()===0&&!document.getElementById('mp-learning')?.open;
      // Never accumulate a command during the enemy turn or outside the arena.
      const command=gate([{className:label,probability:1}]);
      if(command&&ready)set('AICommand',command);
    }
    function handResults(result){
      const points=result.multiHandLandmarks?.[0]||null;
      const canvas=document.getElementById('mp-hand-draw');
      if(canvas){const ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);
        if(points){ctx.strokeStyle='#baf5d2';ctx.lineWidth=2;
          for(const [a,b] of links){ctx.beginPath();ctx.moveTo(points[a].x*canvas.width,points[a].y*canvas.height);ctx.lineTo(points[b].x*canvas.width,points[b].y*canvas.height);ctx.stroke();}
          ctx.fillStyle='#bca7ff';for(const p of points){ctx.beginPath();ctx.arc(p.x*canvas.width,p.y*canvas.height,2.5,0,Math.PI*2);ctx.fill();}
        }
      }
      const label=handLabel(points);deliver(label);
      const names={ATTACK:'Кулак — атака',SHIELD:'Ладонь — щит',HEAL:'Два пальца — лечение'};
      status(!points?'Покажи одну руку целиком':label==='IDLE'?'Поверни ладонь к камере':names[label]+(armed?' · удержи жест':' · убери руку'));
    }
    async function hands(){
      if(!handReady){handReady=(async()=>{
        await loadScript('hands.js','Hands');
        handEngine=new Hands({locateFile:name=>resource(name)});
        handEngine.setOptions({maxNumHands:1,modelComplexity:1,minDetectionConfidence:.7,minTrackingConfidence:.7});
        await handEngine.initialize();return handEngine;
      })().catch(e=>{handReady=null;throw e;});}
      return handReady;
    }
    async function start(){
      stop();const retry=document.getElementById('mp-retry');if(retry)retry.hidden=true;const token=session;status('Разреши камеру…');
      try{
        if(!navigator.mediaDevices?.getUserMedia)throw Error('Запусти игру через START_WINDOWS.bat: камере нужен localhost или HTTPS.');
        const acquired=await navigator.mediaDevices.getUserMedia({video:{width:640,height:480,facingMode:'user'},audio:false});
        if(token!==session){acquired.getTracks().forEach(t=>t.stop());return;}
        stream=acquired;webcam=document.createElement('video');webcam.id='mp-video';webcam.autoplay=true;webcam.muted=true;webcam.playsInline=true;
        webcam.style.cssText='display:block;width:100%;height:150px;object-fit:contain;transform:scaleX(-1);background:#100b20;border-radius:10px';webcam.srcObject=stream;
        document.getElementById('mp-video-box').prepend(webcam);await webcam.play();
        if(token!==session)return;
        let engine=null;
        if(!model){status('Загружаем распознавание руки…');engine=await hands();}
        if(token!==session)return;
        running=true;resetGate();
        if(engine){await frameTask.catch(()=>{});if(token!==session)return;engine.onResults(result=>{if(running&&token===session)handResults(result);});}
        while(running&&token===session){
          if(engine){frameTask=engine.send({image:webcam});await frameTask;}
          else{
            const predictions=await model.predict(webcam,false);if(token!==session)break;
            const top=predictions.reduce((a,b)=>a.probability>b.probability?a:b);
            deliver(top.probability>=.85?top.className:'IDLE');status('Своя модель: '+top.className+(armed?'':' · убери руку'));
          }
          await new Promise(r=>setTimeout(r,100));
        }
      }catch(e){if(token===session){stop();const help={NotAllowedError:'Разреши камеру рядом с адресом браузера.',NotFoundError:'Камера не найдена.',NotReadableError:'Камера занята. Закрой видеозвонок.'};status(help[e.name]||('Не удалось включить камеру: '+e.message));}}
    }
    function camera(){
      if(panel?.id==='mp-camera'){close();return;}
      close();panel=document.createElement('section');panel.id='mp-camera';panel.setAttribute('role','region');panel.setAttribute('aria-label','Камера: управление рукой');
      panel.style.cssText='position:fixed;right:12px;top:145px;width:220px;max-width:85vw;max-height:75vh;overflow:auto;box-sizing:border-box;z-index:99999;background:#282039f5;color:#fff8ed;border:1px solid #bca7ff;border-radius:16px;padding:10px;box-shadow:0 8px 32px #0007;font:13px system-ui';
      panel.innerHTML='<header id="mp-drag" style="display:flex;align-items:center;justify-content:space-between;cursor:move;touch-action:none;padding:0 0 8px"><b>Управление рукой</b><button id="mp-close" aria-label="Выключить камеру" style="font:20px system-ui;background:transparent;color:inherit;border:0;cursor:pointer">×</button></header><div id="mp-video-box" style="position:relative;min-height:50px"><canvas id="mp-hand-draw" width="200" height="150" style="position:absolute;inset:0;width:100%;height:150px;transform:scaleX(-1);pointer-events:none"></canvas></div><p style="display:flex;justify-content:space-between;font-size:11px;margin:8px 0"><span>✊ Атака</span><span>✋ Щит</span><span>✌ Лечение</span></p><p id="mp-status" role="status" style="min-height:30px;margin:6px 0;color:#baf5d2"></p><button id="mp-retry" style="font:inherit">Перезапустить камеру</button><details id="mp-learning" style="margin-top:8px;font-size:11px"><summary>Своя модель для занятия</summary><p>Необязательно: экспорт Teachable Machine с классами ATTACK, SHIELD, HEAL, IDLE. Добавь model.json, metadata.json и веса.</p><input id="mp-model-files" type="file" multiple accept=".json,.bin" style="width:100%"><p id="mp-selected-files"></p><button id="mp-hands">Вернуть жесты руки</button></details>';
      for(const event of ['mousedown','mouseup','pointerdown','pointerup','touchstart','touchend'])panel.addEventListener(event,e=>e.stopPropagation());
      document.body.append(panel);panel.querySelector('#mp-close').onclick=close;panel.querySelector('#mp-retry').onclick=start;
      const header=panel.querySelector('#mp-drag');let drag=null;
      header.onpointerdown=e=>{if(e.target.closest('button'))return;const b=panel.getBoundingClientRect();drag={x:e.clientX-b.left,y:e.clientY-b.top};header.setPointerCapture(e.pointerId);};
      header.onpointermove=e=>{if(!drag)return;panel.style.right='auto';panel.style.left=Math.max(0,Math.min(innerWidth-panel.offsetWidth,e.clientX-drag.x))+'px';panel.style.top=Math.max(0,Math.min(innerHeight-panel.offsetHeight,e.clientY-drag.y))+'px';};
      header.onpointerup=header.onpointercancel=()=>{drag=null;};
      const collected=new Map();
      panel.querySelector('#mp-model-files').onchange=async e=>{
        for(const f of e.target.files)collected.set(f.name,f);
        const selection=document.getElementById('mp-selected-files');selection.textContent='Добавлены: '+[...collected.keys()].join(', ');
        try{await loadLocal([...collected.values()]);status('Модель готова. Закрой эти настройки и нажми «Перезапустить камеру».');}catch(err){status(err.message);}
      };
      panel.querySelector('#mp-hands').onclick=()=>{stop();if(model)model.model.dispose();model=null;panel.querySelector('details').open=false;start();};
      start();
    }
    const fields=['Name','Health','Energy','Strength','XP','Level','Wins','Round','Gold','RoomStyle','Badges',...['Body','Eyes','Mouth','Arms','Legs','Horns','Nose','Ears','Tail','Wings'].map(x=>x+'Variant')];
    const limits={Gold:[0,100000],RoomStyle:[0,2],Badges:[0,3],Health:[0,100],Energy:[0,100],Strength:[10,30],XP:[0,100000],Level:[1,33334],Wins:[0,3],Round:[1,3],BodyVariant:[0,5],EyesVariant:[0,7],MouthVariant:[0,5]};
    function save(){try{const values={};for(const n of fields)values[n]=n==='Name'?state().get(n).getAsString():get(n);localStorage.setItem('monster-protocol-v1',JSON.stringify({version:1,values}));set('Message','Сохранено в этом браузере. Для переноса копируй проект; эта запись не передаётся автоматически.');}catch{set('Message','Браузер запретил локальное сохранение. Сохрани проект в GDevelop.');}}
    function load(){try{const data=JSON.parse(localStorage.getItem('monster-protocol-v1'));if(data?.version!==1||!data.values)throw Error('Нет сохранения');for(const n of fields){const v=data.values[n]===undefined&&['Gold','RoomStyle','Badges'].includes(n)?get(n):data.values[n];data.values[n]=v;if(n==='Name'){if(typeof v!=='string'||!v.trim()||v.length>24)throw Error('Имя');}else{const [lo,hi]=limits[n]||[0,3];if(!Number.isFinite(v)||!Number.isInteger(v)||v<lo||v>hi)throw Error(n);}}for(const n of fields)set(n,data.values[n]);set('Message','Сохранение загружено.');}catch{set('Message','Корректное сохранение не найдено. Текущий монстр не изменён.');}}
    function tick(next){if(scene&&scene!==next){if(panel&&panel.id!=='mp-camera')close();resetGate();}scene=next;
      const cameraLabel=scene.getObjects('CameraLabel')[0];if(cameraLabel)cameraLabel.setString(panel?.id==='mp-camera'?'Выключить камеру':'Включить камеру');
      const battle=document.getElementById('mp-battle-state');if(battle)battle.textContent='Раунд '+get('Round')+' / 3 · Соперник: '+get('EnemyHP')+' HP · Ты: '+get('Health')+' HP · Энергия: '+get('Energy')+' · '+state().get('Message').getAsString();
      for(const [key,fn] of [['NamePanel',rename],['AIPanel',camera],['SaveRequest',save],['LoadRequest',load]])if(get(key)){set(key,0);fn();}
    }
    window.addEventListener('pagehide',()=>{if(scene)stop();});
    return {tick,gate,resetGate,stop,close,loadLocal,demoModel,handLabel,getCameraState:()=>({running,mode:model?'custom':'hands'}),getScene:()=>scene,getModel:()=>model};
  })();
}
runtimeScene.getGame().enableMetrics(false);
globalThis.MonsterProtocol.tick(runtimeScene);
};
gdjs.MonsterCreatorCode.eventsList5 = function(runtimeScene) {

{


gdjs.MonsterCreatorCode.userFunc0xbc89b0(runtimeScene);

}


};gdjs.MonsterCreatorCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Backdrop"), gdjs.MonsterCreatorCode.GDBackdropObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDBackdropObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDBackdropObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(26)));
}
}
}

}


{


gdjs.MonsterCreatorCode.eventsList0(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BodyCount"), gdjs.MonsterCreatorCode.GDBodyCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDBodyCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDBodyCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) + 1) + " / 6");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EyesCount"), gdjs.MonsterCreatorCode.GDEyesCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDEyesCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDEyesCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) + 1) + " / 8");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MouthCount"), gdjs.MonsterCreatorCode.GDMouthCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMouthCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMouthCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) + 1) + " / 6");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ArmsCount"), gdjs.MonsterCreatorCode.GDArmsCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDArmsCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDArmsCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) + 1) + " / 4");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("LegsCount"), gdjs.MonsterCreatorCode.GDLegsCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDLegsCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDLegsCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) + 1) + " / 4");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HornsCount"), gdjs.MonsterCreatorCode.GDHornsCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDHornsCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDHornsCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) + 1) + " / 4");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NoseCount"), gdjs.MonsterCreatorCode.GDNoseCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDNoseCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDNoseCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) + 1) + " / 4");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EarsCount"), gdjs.MonsterCreatorCode.GDEarsCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDEarsCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDEarsCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) + 1) + " / 4");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TailCount"), gdjs.MonsterCreatorCode.GDTailCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDTailCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDTailCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) + 1) + " / 4");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("WingsCount"), gdjs.MonsterCreatorCode.GDWingsCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDWingsCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDWingsCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) + 1) + " / 4");
}
}
}

}


{


gdjs.MonsterCreatorCode.eventsList1(runtimeScene);
}


{


gdjs.MonsterCreatorCode.eventsList2(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("ToLab"), gdjs.MonsterCreatorCode.GDToLabObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDToLabObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13093196);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Lab", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rename"), gdjs.MonsterCreatorCode.GDRenameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDRenameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13094540);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(21).setNumber(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Save"), gdjs.MonsterCreatorCode.GDSaveObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDSaveObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13095708);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(22).setNumber(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Load"), gdjs.MonsterCreatorCode.GDLoadObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDLoadObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13096996);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(23).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NameText"), gdjs.MonsterCreatorCode.GDNameTextObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDNameTextObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDNameTextObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(10)));
}
}
}

}


{


gdjs.MonsterCreatorCode.eventsList3(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("MonsterBody"), gdjs.MonsterCreatorCode.GDMonsterBodyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDMonsterBodyObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13101884);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(30).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Ещё немного рожек — и можно отправляться в приключение!");
}
}

}


{


gdjs.MonsterCreatorCode.eventsList4(runtimeScene);
}


{


gdjs.MonsterCreatorCode.eventsList5(runtimeScene);
}


};

gdjs.MonsterCreatorCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MonsterCreatorCode.GDBackdropObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBackdropObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBackdropObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBrandObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBrandObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBrandObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEditionObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEditionObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEditionObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDKickerObjects1.length = 0;
gdjs.MonsterCreatorCode.GDKickerObjects2.length = 0;
gdjs.MonsterCreatorCode.GDKickerObjects3.length = 0;
gdjs.MonsterCreatorCode.GDPortraitPanelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDPortraitPanelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDPortraitPanelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDPartPanelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDPartPanelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDPartPanelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterBodyObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterBodyObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterBodyObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEyesObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEyesObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEyesObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterMouthObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterMouthObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterMouthObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterArmsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterArmsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterArmsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterLegsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterLegsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterLegsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterHornsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterHornsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterHornsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterNoseObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterNoseObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterNoseObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEarsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEarsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEarsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterTailObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterTailObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterTailObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterWingsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterWingsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterWingsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNameTextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNameTextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNameTextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDCombinationObjects1.length = 0;
gdjs.MonsterCreatorCode.GDCombinationObjects2.length = 0;
gdjs.MonsterCreatorCode.GDCombinationObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRandomObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRandomObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRandomObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRandomLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRandomLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRandomLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRenameObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRenameObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRenameObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRenameLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRenameLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRenameLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDSaveObjects1.length = 0;
gdjs.MonsterCreatorCode.GDSaveObjects2.length = 0;
gdjs.MonsterCreatorCode.GDSaveObjects3.length = 0;
gdjs.MonsterCreatorCode.GDSaveLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDSaveLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDSaveLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLoadObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLoadObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLoadObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLoadLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLoadLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLoadLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDToLabObjects1.length = 0;
gdjs.MonsterCreatorCode.GDToLabObjects2.length = 0;
gdjs.MonsterCreatorCode.GDToLabObjects3.length = 0;
gdjs.MonsterCreatorCode.GDToLabLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDToLabLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDToLabLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHeaderShadeObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHeaderShadeObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHeaderShadeObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMusicObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMusicObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMusicObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMusicLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMusicLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMusicLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDParticleSparkObjects1.length = 0;
gdjs.MonsterCreatorCode.GDParticleSparkObjects2.length = 0;
gdjs.MonsterCreatorCode.GDParticleSparkObjects3.length = 0;
gdjs.MonsterCreatorCode.GDParticleHeartObjects1.length = 0;
gdjs.MonsterCreatorCode.GDParticleHeartObjects2.length = 0;
gdjs.MonsterCreatorCode.GDParticleHeartObjects3.length = 0;
gdjs.MonsterCreatorCode.GDParticleBubbleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDParticleBubbleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDParticleBubbleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDProjectileObjects1.length = 0;
gdjs.MonsterCreatorCode.GDProjectileObjects2.length = 0;
gdjs.MonsterCreatorCode.GDProjectileObjects3.length = 0;
gdjs.MonsterCreatorCode.GDFloatingNumberObjects1.length = 0;
gdjs.MonsterCreatorCode.GDFloatingNumberObjects2.length = 0;
gdjs.MonsterCreatorCode.GDFloatingNumberObjects3.length = 0;
gdjs.MonsterCreatorCode.GDShieldHaloObjects1.length = 0;
gdjs.MonsterCreatorCode.GDShieldHaloObjects2.length = 0;
gdjs.MonsterCreatorCode.GDShieldHaloObjects3.length = 0;

gdjs.MonsterCreatorCode.eventsList6(runtimeScene);
gdjs.MonsterCreatorCode.GDBackdropObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBackdropObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBackdropObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBrandObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBrandObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBrandObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEditionObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEditionObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEditionObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDKickerObjects1.length = 0;
gdjs.MonsterCreatorCode.GDKickerObjects2.length = 0;
gdjs.MonsterCreatorCode.GDKickerObjects3.length = 0;
gdjs.MonsterCreatorCode.GDPortraitPanelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDPortraitPanelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDPortraitPanelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDPartPanelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDPartPanelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDPartPanelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterBodyObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterBodyObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterBodyObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEyesObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEyesObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEyesObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterMouthObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterMouthObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterMouthObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterArmsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterArmsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterArmsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterLegsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterLegsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterLegsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterHornsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterHornsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterHornsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterNoseObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterNoseObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterNoseObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEarsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEarsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEarsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterTailObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterTailObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterTailObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterWingsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterWingsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterWingsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNameTextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNameTextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNameTextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDCombinationObjects1.length = 0;
gdjs.MonsterCreatorCode.GDCombinationObjects2.length = 0;
gdjs.MonsterCreatorCode.GDCombinationObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRandomObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRandomObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRandomObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRandomLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRandomLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRandomLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRenameObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRenameObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRenameObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRenameLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRenameLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRenameLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDSaveObjects1.length = 0;
gdjs.MonsterCreatorCode.GDSaveObjects2.length = 0;
gdjs.MonsterCreatorCode.GDSaveObjects3.length = 0;
gdjs.MonsterCreatorCode.GDSaveLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDSaveLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDSaveLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLoadObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLoadObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLoadObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLoadLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLoadLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLoadLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDToLabObjects1.length = 0;
gdjs.MonsterCreatorCode.GDToLabObjects2.length = 0;
gdjs.MonsterCreatorCode.GDToLabObjects3.length = 0;
gdjs.MonsterCreatorCode.GDToLabLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDToLabLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDToLabLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHeaderShadeObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHeaderShadeObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHeaderShadeObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMusicObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMusicObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMusicObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMusicLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMusicLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMusicLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDParticleSparkObjects1.length = 0;
gdjs.MonsterCreatorCode.GDParticleSparkObjects2.length = 0;
gdjs.MonsterCreatorCode.GDParticleSparkObjects3.length = 0;
gdjs.MonsterCreatorCode.GDParticleHeartObjects1.length = 0;
gdjs.MonsterCreatorCode.GDParticleHeartObjects2.length = 0;
gdjs.MonsterCreatorCode.GDParticleHeartObjects3.length = 0;
gdjs.MonsterCreatorCode.GDParticleBubbleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDParticleBubbleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDParticleBubbleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDProjectileObjects1.length = 0;
gdjs.MonsterCreatorCode.GDProjectileObjects2.length = 0;
gdjs.MonsterCreatorCode.GDProjectileObjects3.length = 0;
gdjs.MonsterCreatorCode.GDFloatingNumberObjects1.length = 0;
gdjs.MonsterCreatorCode.GDFloatingNumberObjects2.length = 0;
gdjs.MonsterCreatorCode.GDFloatingNumberObjects3.length = 0;
gdjs.MonsterCreatorCode.GDShieldHaloObjects1.length = 0;
gdjs.MonsterCreatorCode.GDShieldHaloObjects2.length = 0;
gdjs.MonsterCreatorCode.GDShieldHaloObjects3.length = 0;


return;

}

gdjs['MonsterCreatorCode'] = gdjs.MonsterCreatorCode;

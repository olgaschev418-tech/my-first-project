gdjs.ArenaCode = {};
gdjs.ArenaCode.localVariables = [];
gdjs.ArenaCode.idToCallbackMap = new Map();
gdjs.ArenaCode.GDBackdropObjects1= [];
gdjs.ArenaCode.GDBackdropObjects2= [];
gdjs.ArenaCode.GDBackdropObjects3= [];
gdjs.ArenaCode.GDBrandObjects1= [];
gdjs.ArenaCode.GDBrandObjects2= [];
gdjs.ArenaCode.GDBrandObjects3= [];
gdjs.ArenaCode.GDEditionObjects1= [];
gdjs.ArenaCode.GDEditionObjects2= [];
gdjs.ArenaCode.GDEditionObjects3= [];
gdjs.ArenaCode.GDTitleObjects1= [];
gdjs.ArenaCode.GDTitleObjects2= [];
gdjs.ArenaCode.GDTitleObjects3= [];
gdjs.ArenaCode.GDKickerObjects1= [];
gdjs.ArenaCode.GDKickerObjects2= [];
gdjs.ArenaCode.GDKickerObjects3= [];
gdjs.ArenaCode.GDHeaderShadeObjects1= [];
gdjs.ArenaCode.GDHeaderShadeObjects2= [];
gdjs.ArenaCode.GDHeaderShadeObjects3= [];
gdjs.ArenaCode.GDMusicObjects1= [];
gdjs.ArenaCode.GDMusicObjects2= [];
gdjs.ArenaCode.GDMusicObjects3= [];
gdjs.ArenaCode.GDMusicLabelObjects1= [];
gdjs.ArenaCode.GDMusicLabelObjects2= [];
gdjs.ArenaCode.GDMusicLabelObjects3= [];
gdjs.ArenaCode.GDParticleSparkObjects1= [];
gdjs.ArenaCode.GDParticleSparkObjects2= [];
gdjs.ArenaCode.GDParticleSparkObjects3= [];
gdjs.ArenaCode.GDParticleHeartObjects1= [];
gdjs.ArenaCode.GDParticleHeartObjects2= [];
gdjs.ArenaCode.GDParticleHeartObjects3= [];
gdjs.ArenaCode.GDParticleBubbleObjects1= [];
gdjs.ArenaCode.GDParticleBubbleObjects2= [];
gdjs.ArenaCode.GDParticleBubbleObjects3= [];
gdjs.ArenaCode.GDProjectileObjects1= [];
gdjs.ArenaCode.GDProjectileObjects2= [];
gdjs.ArenaCode.GDProjectileObjects3= [];
gdjs.ArenaCode.GDFloatingNumberObjects1= [];
gdjs.ArenaCode.GDFloatingNumberObjects2= [];
gdjs.ArenaCode.GDFloatingNumberObjects3= [];
gdjs.ArenaCode.GDShieldHaloObjects1= [];
gdjs.ArenaCode.GDShieldHaloObjects2= [];
gdjs.ArenaCode.GDShieldHaloObjects3= [];
gdjs.ArenaCode.GDMessagePanelObjects1= [];
gdjs.ArenaCode.GDMessagePanelObjects2= [];
gdjs.ArenaCode.GDMessagePanelObjects3= [];
gdjs.ArenaCode.GDMessageObjects1= [];
gdjs.ArenaCode.GDMessageObjects2= [];
gdjs.ArenaCode.GDMessageObjects3= [];
gdjs.ArenaCode.GDCreatorObjects1= [];
gdjs.ArenaCode.GDCreatorObjects2= [];
gdjs.ArenaCode.GDCreatorObjects3= [];
gdjs.ArenaCode.GDCreatorLabelObjects1= [];
gdjs.ArenaCode.GDCreatorLabelObjects2= [];
gdjs.ArenaCode.GDCreatorLabelObjects3= [];
gdjs.ArenaCode.GDCameraObjects1= [];
gdjs.ArenaCode.GDCameraObjects2= [];
gdjs.ArenaCode.GDCameraObjects3= [];
gdjs.ArenaCode.GDCameraLabelObjects1= [];
gdjs.ArenaCode.GDCameraLabelObjects2= [];
gdjs.ArenaCode.GDCameraLabelObjects3= [];
gdjs.ArenaCode.GDPlayerHUDObjects1= [];
gdjs.ArenaCode.GDPlayerHUDObjects2= [];
gdjs.ArenaCode.GDPlayerHUDObjects3= [];
gdjs.ArenaCode.GDPlayerNameObjects1= [];
gdjs.ArenaCode.GDPlayerNameObjects2= [];
gdjs.ArenaCode.GDPlayerNameObjects3= [];
gdjs.ArenaCode.GDHealthTrackObjects1= [];
gdjs.ArenaCode.GDHealthTrackObjects2= [];
gdjs.ArenaCode.GDHealthTrackObjects3= [];
gdjs.ArenaCode.GDHealthBarObjects1= [];
gdjs.ArenaCode.GDHealthBarObjects2= [];
gdjs.ArenaCode.GDHealthBarObjects3= [];
gdjs.ArenaCode.GDHealthValueObjects1= [];
gdjs.ArenaCode.GDHealthValueObjects2= [];
gdjs.ArenaCode.GDHealthValueObjects3= [];
gdjs.ArenaCode.GDEnergyTrackObjects1= [];
gdjs.ArenaCode.GDEnergyTrackObjects2= [];
gdjs.ArenaCode.GDEnergyTrackObjects3= [];
gdjs.ArenaCode.GDEnergyBarObjects1= [];
gdjs.ArenaCode.GDEnergyBarObjects2= [];
gdjs.ArenaCode.GDEnergyBarObjects3= [];
gdjs.ArenaCode.GDEnergyValueObjects1= [];
gdjs.ArenaCode.GDEnergyValueObjects2= [];
gdjs.ArenaCode.GDEnergyValueObjects3= [];
gdjs.ArenaCode.GDMonsterBodyObjects1= [];
gdjs.ArenaCode.GDMonsterBodyObjects2= [];
gdjs.ArenaCode.GDMonsterBodyObjects3= [];
gdjs.ArenaCode.GDMonsterEyesObjects1= [];
gdjs.ArenaCode.GDMonsterEyesObjects2= [];
gdjs.ArenaCode.GDMonsterEyesObjects3= [];
gdjs.ArenaCode.GDMonsterMouthObjects1= [];
gdjs.ArenaCode.GDMonsterMouthObjects2= [];
gdjs.ArenaCode.GDMonsterMouthObjects3= [];
gdjs.ArenaCode.GDMonsterArmsObjects1= [];
gdjs.ArenaCode.GDMonsterArmsObjects2= [];
gdjs.ArenaCode.GDMonsterArmsObjects3= [];
gdjs.ArenaCode.GDMonsterLegsObjects1= [];
gdjs.ArenaCode.GDMonsterLegsObjects2= [];
gdjs.ArenaCode.GDMonsterLegsObjects3= [];
gdjs.ArenaCode.GDMonsterHornsObjects1= [];
gdjs.ArenaCode.GDMonsterHornsObjects2= [];
gdjs.ArenaCode.GDMonsterHornsObjects3= [];
gdjs.ArenaCode.GDMonsterNoseObjects1= [];
gdjs.ArenaCode.GDMonsterNoseObjects2= [];
gdjs.ArenaCode.GDMonsterNoseObjects3= [];
gdjs.ArenaCode.GDMonsterEarsObjects1= [];
gdjs.ArenaCode.GDMonsterEarsObjects2= [];
gdjs.ArenaCode.GDMonsterEarsObjects3= [];
gdjs.ArenaCode.GDMonsterTailObjects1= [];
gdjs.ArenaCode.GDMonsterTailObjects2= [];
gdjs.ArenaCode.GDMonsterTailObjects3= [];
gdjs.ArenaCode.GDMonsterWingsObjects1= [];
gdjs.ArenaCode.GDMonsterWingsObjects2= [];
gdjs.ArenaCode.GDMonsterWingsObjects3= [];
gdjs.ArenaCode.GDRivalObjects1= [];
gdjs.ArenaCode.GDRivalObjects2= [];
gdjs.ArenaCode.GDRivalObjects3= [];
gdjs.ArenaCode.GDEnemyHUDObjects1= [];
gdjs.ArenaCode.GDEnemyHUDObjects2= [];
gdjs.ArenaCode.GDEnemyHUDObjects3= [];
gdjs.ArenaCode.GDEnemyTitleObjects1= [];
gdjs.ArenaCode.GDEnemyTitleObjects2= [];
gdjs.ArenaCode.GDEnemyTitleObjects3= [];
gdjs.ArenaCode.GDEnemyHPValueObjects1= [];
gdjs.ArenaCode.GDEnemyHPValueObjects2= [];
gdjs.ArenaCode.GDEnemyHPValueObjects3= [];
gdjs.ArenaCode.GDEnemyHealthTrackObjects1= [];
gdjs.ArenaCode.GDEnemyHealthTrackObjects2= [];
gdjs.ArenaCode.GDEnemyHealthTrackObjects3= [];
gdjs.ArenaCode.GDEnemyHealthBarObjects1= [];
gdjs.ArenaCode.GDEnemyHealthBarObjects2= [];
gdjs.ArenaCode.GDEnemyHealthBarObjects3= [];
gdjs.ArenaCode.GDRoundTextObjects1= [];
gdjs.ArenaCode.GDRoundTextObjects2= [];
gdjs.ArenaCode.GDRoundTextObjects3= [];
gdjs.ArenaCode.GDPhaseTextObjects1= [];
gdjs.ArenaCode.GDPhaseTextObjects2= [];
gdjs.ArenaCode.GDPhaseTextObjects3= [];
gdjs.ArenaCode.GDEnemyIntentObjects1= [];
gdjs.ArenaCode.GDEnemyIntentObjects2= [];
gdjs.ArenaCode.GDEnemyIntentObjects3= [];
gdjs.ArenaCode.GDNameTextObjects1= [];
gdjs.ArenaCode.GDNameTextObjects2= [];
gdjs.ArenaCode.GDNameTextObjects3= [];
gdjs.ArenaCode.GDCombatStatsObjects1= [];
gdjs.ArenaCode.GDCombatStatsObjects2= [];
gdjs.ArenaCode.GDCombatStatsObjects3= [];
gdjs.ArenaCode.GDAttackObjects1= [];
gdjs.ArenaCode.GDAttackObjects2= [];
gdjs.ArenaCode.GDAttackObjects3= [];
gdjs.ArenaCode.GDAttackLabelObjects1= [];
gdjs.ArenaCode.GDAttackLabelObjects2= [];
gdjs.ArenaCode.GDAttackLabelObjects3= [];
gdjs.ArenaCode.GDShieldObjects1= [];
gdjs.ArenaCode.GDShieldObjects2= [];
gdjs.ArenaCode.GDShieldObjects3= [];
gdjs.ArenaCode.GDShieldLabelObjects1= [];
gdjs.ArenaCode.GDShieldLabelObjects2= [];
gdjs.ArenaCode.GDShieldLabelObjects3= [];
gdjs.ArenaCode.GDHealObjects1= [];
gdjs.ArenaCode.GDHealObjects2= [];
gdjs.ArenaCode.GDHealObjects3= [];
gdjs.ArenaCode.GDHealLabelObjects1= [];
gdjs.ArenaCode.GDHealLabelObjects2= [];
gdjs.ArenaCode.GDHealLabelObjects3= [];
gdjs.ArenaCode.GDRetreatObjects1= [];
gdjs.ArenaCode.GDRetreatObjects2= [];
gdjs.ArenaCode.GDRetreatObjects3= [];
gdjs.ArenaCode.GDRetreatLabelObjects1= [];
gdjs.ArenaCode.GDRetreatLabelObjects2= [];
gdjs.ArenaCode.GDRetreatLabelObjects3= [];


gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDMusicObjects2Objects = Hashtable.newFrom({"Music": gdjs.ArenaCode.GDMusicObjects2});
gdjs.ArenaCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Music"), gdjs.ArenaCode.GDMusicObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDMusicObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13626460);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(28).setNumber(1 - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(28)));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(28)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MusicLabel"), gdjs.ArenaCode.GDMusicLabelObjects2);
{for(var i = 0, len = gdjs.ArenaCode.GDMusicLabelObjects2.length ;i < len;++i) {
    gdjs.ArenaCode.GDMusicLabelObjects2[i].setString("Звук: выкл");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(28)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MusicLabel"), gdjs.ArenaCode.GDMusicLabelObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDMusicLabelObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMusicLabelObjects1[i].setString("Звук: вкл");
}
}
}

}


};gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDCreatorObjects1Objects = Hashtable.newFrom({"Creator": gdjs.ArenaCode.GDCreatorObjects1});
gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDCameraObjects1Objects = Hashtable.newFrom({"Camera": gdjs.ArenaCode.GDCameraObjects1});
gdjs.ArenaCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MonsterArms"), gdjs.ArenaCode.GDMonsterArmsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterBody"), gdjs.ArenaCode.GDMonsterBodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterEars"), gdjs.ArenaCode.GDMonsterEarsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterEyes"), gdjs.ArenaCode.GDMonsterEyesObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterHorns"), gdjs.ArenaCode.GDMonsterHornsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterLegs"), gdjs.ArenaCode.GDMonsterLegsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterMouth"), gdjs.ArenaCode.GDMonsterMouthObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterNose"), gdjs.ArenaCode.GDMonsterNoseObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterTail"), gdjs.ArenaCode.GDMonsterTailObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterWings"), gdjs.ArenaCode.GDMonsterWingsObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterBodyObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterBodyObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterEyesObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterEyesObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterMouthObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterMouthObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterArmsObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterArmsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterLegsObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterLegsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterHornsObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterHornsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterNoseObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterNoseObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterEarsObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterEarsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterTailObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterTailObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterWingsObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterWingsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)));
}
}
}

}


};gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDRetreatObjects1Objects = Hashtable.newFrom({"Retreat": gdjs.ArenaCode.GDRetreatObjects1});
gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDAttackObjects2Objects = Hashtable.newFrom({"Attack": gdjs.ArenaCode.GDAttackObjects2});
gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDShieldObjects2Objects = Hashtable.newFrom({"Shield": gdjs.ArenaCode.GDShieldObjects2});
gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDHealObjects2Objects = Hashtable.newFrom({"Heal": gdjs.ArenaCode.GDHealObjects2});
gdjs.ArenaCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(0);
}
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) > 0;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) + gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Attack"), gdjs.ArenaCode.GDAttackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDAttackObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13646948);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 0;
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield"), gdjs.ArenaCode.GDShieldObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDShieldObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13648356);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 0;
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(2);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Heal"), gdjs.ArenaCode.GDHealObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDHealObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13649708);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 0;
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(3);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 0;
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19)));
}
{runtimeScene.getGame().getVariables().getFromIndex(19).setNumber(0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) > 0;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(19).setNumber(0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) < 10;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(29).setNumber(6);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Не хватает энергии! Щит восстановит силы и смягчит удар.");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) >= 10;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) - 10);
}
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(13)));
}
{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)) + 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Звёздный выпад! Теперь дождись ответа хранителя.");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(Math.min(100, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) + 14));
}
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(2);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)) + 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Защитный купол! +14 энергии, даже сильный удар нанесёт только 3 урона.");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) < 20;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(29).setNumber(6);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Лечение стоит 20 энергии. Попробуй щит.");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) >= 20;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) - 20);
}
{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(Math.min(100, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) + 25));
}
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(3);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)) + 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(29).setNumber(5);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Целебное сияние! +25 здоровья. Хранитель готовит ответ.");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) >= 0.28;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(Math.max(0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6))));
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(2);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) >= 0.68;
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(6 + 2 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)));
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(3);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)) >= 3;
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(2 * (6 + 2 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) == 2;
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(3);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) >= 1.08;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(Math.max(0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2))));
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(4);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 4;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)) >= 3;
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber(0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 4;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) >= 1.58;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) > 0;
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 4;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) >= 1.58;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) <= 0;
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Хранитель оказался сильнее. Дома тебя ждут отдых и новая попытка.");
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Lab", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) <= 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) >= 0.85;
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(16).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) + 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(27).setNumber(Math.max(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(27)), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16))));
}
{runtimeScene.getGame().getVariables().getFromIndex(25).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(25)) + 20);
}
{runtimeScene.getGame().getVariables().getFromIndex(29).setNumber(4);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(5);
}
{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Победа! +20 звёзд и новый трофей для дома.");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) >= 1.15;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) < 3;
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Lab", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) >= 1.15;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) >= 3;
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Final", false);
}
}

}


};gdjs.ArenaCode.userFunc0xae7760 = function GDJSInlineCode(runtimeScene) {
"use strict";
/* Ready-made visual/audio kit. All health, energy, rewards and turn rules are native events. */
if (!globalThis.MonsterWorld) {
  globalThis.MonsterWorld = (() => {
    let scene,ctx,music=null,track='',audioContext=null,unlocked=false;
    const events=[];
    const record=(type,detail={})=>{events.push({type,...detail});if(events.length>40)events.shift();};
    const vars=()=>scene.getGame().getVariables();
    const num=n=>vars().get(n).getAsNumber();
    const sv=n=>scene.getVariables().get(n).getAsNumber();
    const resource=name=>{const r=scene.getGame().getGameData().resources.resources.find(r=>r.name==='assets/'+name);return r?scene.getGame().getResourceLoader().getFullUrl(r.file):null;};
    function syncMusic(){
      if(!scene||!unlocked)return;
      const desired=scene.getName()==='Arena'?'battle-loop.wav':'home-loop.wav';
      if(!music||desired!==track){if(music)music.pause();const url=resource(desired);if(!url)return;music=new Audio(url);music.loop=true;music.volume=.25;track=desired;}
      music.volume=Math.max(0,Math.min(1,num('MusicVolume')/100));
      if(num('MusicOn')===1){if(music.paused)music.play().catch(()=>{});}else music.pause();
    }
    document.addEventListener('pointerdown',()=>{
      if(!scene)return;unlocked=true;
      const AudioCtx=globalThis.AudioContext||globalThis.webkitAudioContext;
      if(AudioCtx&&!audioContext)audioContext=new AudioCtx();
      if(audioContext?.state==='suspended')audioContext.resume().catch(()=>{});
      syncMusic();
    },{capture:true});
    document.addEventListener('visibilitychange',()=>{if(document.hidden){if(music)music.pause();}else syncMusic();});
    function sound(kind){
      if(!audioContext||audioContext.state!=='running'||num('MusicOn')!==1)return;
      const tones={attack:[392,784],hit:[120,65],good:[523,659,784],shield:[330,494],sleep:[262,330],error:[160,120]};
      (tones[kind]||tones.good).forEach((f,i)=>{const osc=audioContext.createOscillator(),gain=audioContext.createGain(),at=audioContext.currentTime+i*.07;osc.type=kind==='hit'?'triangle':'sine';osc.frequency.setValueAtTime(f,at);gain.gain.setValueAtTime(0,at);gain.gain.linearRampToValueAtTime(.075,at+.015);gain.gain.exponentialRampToValueAtTime(.001,at+.23);osc.connect(gain);gain.connect(audioContext.destination);osc.start(at);osc.stop(at+.25);});
    }
    function emit(type,x,y,count=12,color=null){
      for(let i=0;i<count&&ctx.particles.length<100;i++){
        const o=scene.createObject(type);if(!o)continue;
        const angle=Math.random()*Math.PI*2,speed=45+Math.random()*130,size=10+Math.random()*15;
        o.setPosition(x,y);o.setSize(size,size);o.setZOrder(80);if(color&&o.setColor)o.setColor(color);
        ctx.particles.push({o,x,y,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed-90,age:0,life:.7+Math.random()*.6,spin:Math.random()*180-90});
      }
    }
    function floating(text,x,y,color){const o=scene.createObject('FloatingNumber');if(!o)return;o.setString(text);o.setPosition(x,y);o.setZOrder(85);o.setColor(color);ctx.particles.push({o,x,y,vx:0,vy:-48,age:0,life:1.1,spin:0});}
    function bolt(){const o=scene.createObject('Projectile');if(!o)return;o.setSize(65,65);o.setZOrder(50);ctx.particles.push({o,projectile:true,age:0,life:.3});}
    function base(o){return {o,x:o.getX(),y:o.getY(),w:o.getWidth(),h:o.getHeight(),angle:o.getAngle()};}
    function initialize(next){
      scene=next;const objects=[];for(const cat of ['Body','Eyes','Mouth','Arms','Legs','Horns','Nose','Ears','Tail','Wings'])for(const o of scene.getObjects('Monster'+cat))objects.push({...base(o),cat});
      const body=objects.find(x=>x.cat==='Body');
      ctx={time:0,parts:objects,rival:scene.getObjects('Rival').map(base),heroX:body?body.x+body.w/2:400,heroY:body?body.y+body.h/2:400,particles:[],lastHP:num('Health'),lastEnemy:num('EnemyHP'),lastPhase:0,lastRound:num('Round'),react:0,heroHurt:0,enemyHurt:0,emission:0,barHealth:num('Health'),barEnergy:num('Energy'),barEnemy:num('EnemyHP'),buttons:[]};
      const buttonNames=['Music','Feed','Train','Rest','Battle','Decor','Attack','Shield','Heal','Creator','Camera','Retreat','Again','Home','Random','Rename','Save','Load','ToLab'];
      for(const o of scene.getAdhocListOfAllInstances())if(buttonNames.includes(o.getName())||/^(Body|Eyes|Mouth|Arms|Legs|Horns|Nose|Ears|Tail|Wings)(Next|Prev)$/.test(o.getName()))ctx.buttons.push(base(o));
      if(scene.getName()==='Final'){emit('ParticleSpark',870,300,45);sound('good');}
      record('scene',{name:scene.getName()});syncMusic();
    }
    function tick(next){
      if(scene!==next)initialize(next);
      const dt=Math.min(.05,Math.max(0,scene.getElapsedTime()/1000));ctx.time+=dt;ctx.react=Math.max(0,ctx.react-dt);ctx.heroHurt=Math.max(0,ctx.heroHurt-dt);ctx.enemyHurt=Math.max(0,ctx.enemyHurt-dt);
      const name=scene.getName(),phase=sv('Phase'),turn=sv('TurnTime'),kind=sv('ActionKind');
      const fx=num('VisualFX');if(fx){vars().get('VisualFX').setNumber(0);ctx.react=.9;
        if(fx===1){emit('ParticleHeart',ctx.heroX,ctx.heroY,13);floating('+20 энергии',ctx.heroX-80,ctx.heroY-100,'186;245;210');sound('good');}
        if(fx===2){emit('ParticleSpark',ctx.heroX,ctx.heroY,18);floating('+4 силы',ctx.heroX-60,ctx.heroY-110,'255;221;140');sound('good');}
        if(fx===3){emit('ParticleBubble',ctx.heroX,ctx.heroY,12);floating('Z z z…',ctx.heroX-40,ctx.heroY-120,'202;190;255');sound('sleep');}
        if(fx===4){emit('ParticleSpark',ctx.heroX,ctx.heroY-50,36);sound('good');}
        if(fx===5){emit('ParticleHeart',ctx.heroX,ctx.heroY,12);sound('good');}
        if(fx===6){floating('Нужно больше энергии',ctx.heroX-120,ctx.heroY-110,'255;191;165');sound('error');}
        record('reaction',{kind:fx});
      }
      if(num('PetRequest')){vars().get('PetRequest').setNumber(0);ctx.react=1.2;emit('ParticleHeart',ctx.heroX,ctx.heroY-70,18);sound('good');record('pet');}
      if(name==='Arena'&&phase===1&&ctx.lastPhase!==1){
        if(kind===1){bolt();sound('attack');record('player-attack');}
        if(kind===2){emit('ParticleBubble',ctx.heroX,ctx.heroY,15);sound('shield');record('shield');}
        if(kind===3)record('heal');
      }
      if(name==='Arena'&&phase===3&&ctx.lastPhase!==3){emit('ParticleSpark',970,365,12);sound('attack');record('enemy-counterattack');}
      const hp=num('Health'),enemy=num('EnemyHP');
      if(hp<ctx.lastHP){ctx.heroHurt=.28;emit('ParticleSpark',ctx.heroX,ctx.heroY,13);floating('−'+(ctx.lastHP-hp),ctx.heroX,ctx.heroY-80,'255;157;170');sound('hit');record('player-damage',{amount:ctx.lastHP-hp});}
      if(hp>ctx.lastHP&&name==='Arena')floating('+'+(hp-ctx.lastHP),ctx.heroX,ctx.heroY-90,'186;245;210');
      if(enemy<ctx.lastEnemy&&name==='Arena'){ctx.enemyHurt=.28;emit('ParticleSpark',965,380,20);floating('−'+(ctx.lastEnemy-enemy),960,300,'255;220;151');sound('hit');record('enemy-damage',{amount:ctx.lastEnemy-enemy});}
      ctx.lastHP=hp;ctx.lastEnemy=enemy;ctx.lastPhase=phase;
      const t=ctx.time,breath=1+.018*Math.sin(t*3),blink=(t%4.3)>.12&&(t%4.3)<.25;
      let lunge=0,jump=0;
      if(name==='Arena'&&kind===1&&phase>0&&phase<4)lunge=100*Math.sin(Math.PI*Math.min(1,turn/.62));
      if(ctx.react>0)jump=-Math.abs(Math.sin(ctx.react*10))*num('ReactionHeight');
      const shake=ctx.heroHurt>0?Math.sin(ctx.heroHurt*120)*9:0;
      for(const b of ctx.parts){
        const sx=breath,sy=1-.016*Math.sin(t*3);b.o.setSize(b.w*sx,b.h*sy*(b.cat==='Eyes'&&blink?.08:1));
        let x=ctx.heroX+(b.x-ctx.heroX)*sx+lunge+shake,y=ctx.heroY+(b.y-ctx.heroY)*sy+Math.sin(t*2.4)*num('IdleAmplitude')+jump;
        if(b.cat==='Eyes'&&blink)y+=b.h*.45;
        b.o.setPosition(x,y);b.o.setAngle(b.angle+(b.cat==='Arms'?Math.sin(t*3)*2:0));
        b.o.setOpacity(ctx.heroHurt>0&&Math.sin(ctx.heroHurt*80)>0?135:255);
      }
      for(const b of ctx.rival){
        let x=b.x,y=b.y+Math.sin(t*2.1)*6,angle=Math.sin(t*1.7)*2;
        if(phase===3)x-=140*Math.sin(Math.PI*Math.min(1,Math.max(0,(turn-.68)/.46)));
        b.o.setPosition(x,y);b.o.setAngle(angle);b.o.setSize(b.w*(1+.022*Math.sin(t*2.1)),b.h*(1-.018*Math.sin(t*2.1)));
        b.o.setOpacity(phase===5?Math.max(0,220-turn*350):ctx.enemyHurt>0?145:255);
      }
      const halo=scene.getObjects('ShieldHalo')[0];if(halo){if(name==='Arena'&&kind===2&&phase>0&&phase<5){halo.setPosition(ctx.heroX-85,ctx.heroY-60);halo.setSize(170,170);halo.setOpacity(180+50*Math.sin(t*8));}else halo.setPosition(-400,-400);}
      // Native scene sprites show the values; only their visual interpolation is here.
      for(const [field,key,max]of [['Health','barHealth',100],['Energy','barEnergy',100],['EnemyHealth','barEnemy',40+20*num('Round')]]){
        const target=field==='EnemyHealth'?enemy:num(field);ctx[key]+=(target-ctx[key])*Math.min(1,dt*12);
        const o=scene.getObjects(field+'Bar')[0];if(o){const width=field==='EnemyHealth'?241:225;o.setWidth(Math.max(.1,width*Math.max(0,ctx[key])/max));}
      }
      for(let i=0;i<3;i++){const trophy=scene.getObjects('Trophy'+i)[0];if(trophy)trophy.setOpacity(num('Badges')>i?255:55);}
      const input=scene.getGame().getInputManager(),mx=input.getMouseX(),my=input.getMouseY();
      for(const b of ctx.buttons){const hover=mx>=b.x&&mx<=b.x+b.w&&my>=b.y&&my<=b.y+b.h;const busy=name==='Arena'&&phase>0&&['Attack','Shield','Heal'].includes(b.o.getName());b.o.setOpacity(busy?125:255);b.o.setPosition(b.x,b.y+(hover&&!busy?-2:0));}
      ctx.emission+=dt;
      if(ctx.emission>.45){ctx.emission=0;if(name==='Lab')emit('ParticleBubble',1090,338,1);else if(name==='Final')emit('ParticleSpark',180+Math.random()*920,210,3);else if(name==='Arena')emit('ParticleBubble',90+Math.random()*1100,510,1);}
      ctx.particles=ctx.particles.filter(p=>{
        p.age+=dt;if(p.age>=p.life){p.o.deleteFromScene(scene);return false;}
        if(p.projectile){const f=p.age/p.life;p.o.setPosition(340+570*f,375-Math.sin(f*Math.PI)*65);p.o.setAngle(30+f*360);}
        else{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=35*dt;p.o.setPosition(p.x,p.y);if(p.spin)p.o.setAngle(p.o.getAngle()+p.spin*dt);}
        p.o.setOpacity(255*Math.min(1,(p.life-p.age)/.3));return true;
      });
      syncMusic();
    }
    window.addEventListener('pagehide',()=>{if(music)music.pause();if(audioContext)audioContext.suspend().catch(()=>{});});
    return {tick,events,getMusic:()=>music,inspect:()=>({scene:scene?.getName(),phase:scene?sv('Phase'):0,particles:ctx?.particles.length||0,musicOn:scene?num('MusicOn'):0,track})};
  })();
}
globalThis.MonsterWorld.tick(runtimeScene);
};
gdjs.ArenaCode.eventsList3 = function(runtimeScene) {

{


gdjs.ArenaCode.userFunc0xae7760(runtimeScene);

}


};gdjs.ArenaCode.userFunc0xadae80 = function GDJSInlineCode(runtimeScene) {
"use strict";
/* Teacher-owned adapter. Gameplay lives in visible GDevelop events, not here. */
if (!globalThis.MonsterProtocol) {
  globalThis.MonsterProtocol = (() => {
    let scene, model=null, panel=null, webcam=null, stream=null, running=false, session=0, handEngine=null, handReady=null, frameTask=Promise.resolve();
    let candidate='', since=0, neutralSince=0, armed=true, lastCommand=-Infinity;
    const allowed=['ATTACK','SHIELD','HEAL','IDLE'];
    const state=()=>scene.getGame().getVariables();
    const set=(n,v)=>typeof v==='string'?state().get(n).setString(v):state().get(n).setNumber(v);
    const get=n=>state().get(n).getAsNumber();
    const status=s=>{const el=document.getElementById('mp-status');if(el)el.textContent=s;};
    function resource(name) {
      const data=scene.getGame().getGameData().resources.resources.find(r=>r.name==='assets/'+name);
      if (!data) throw Error('Ресурс не найден: '+name);
      return scene.getGame().getResourceLoader().getFullUrl(data.file);
    }
    const loadScript=(name,globalName)=>new Promise((resolve,reject)=>{
      if(globalThis[globalName])return resolve();
      const s=document.createElement('script');s.src=resource(name);s.onload=resolve;s.onerror=()=>reject(Error('Не загружена локальная библиотека '+name));document.head.append(s);
    });
    async function libraries(){await loadScript('tf.min.js','tf');await loadScript('tm.min.js','tmImage');}
    function resetGate(){candidate='';since=0;neutralSince=0;armed=true;lastCommand=-Infinity;}
    function gate(predictions,now=performance.now()) {
      const top=predictions.reduce((a,b)=>a.probability>b.probability?a:b,{className:'IDLE',probability:0});
      const label=top.className;
      if(top.probability<.85 || label==='IDLE') {
        candidate='';
        if(!neutralSince)neutralSince=now;
        if(now-neutralSince>=400)armed=true;
        return 0;
      }
      neutralSince=0;
      if(candidate!==label){candidate=label;since=now;return 0;}
      if(!armed || now-since<500 || now-lastCommand<1500)return 0;
      armed=false;lastCommand=now;
      return {ATTACK:1,SHIELD:2,HEAL:3}[label]||0;
    }
    function stop(){session++;running=false;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;if(webcam){webcam.srcObject=null;webcam.remove();webcam=null;}set('AICommand',0);resetGate();const retry=document.getElementById('mp-retry');if(retry)retry.hidden=false;status('Камера выключена. Кнопки игры доступны.');}
    function close(){stop();if(panel)panel.remove();panel=null;}
    function shell(title){
      close();panel=document.createElement('div');panel.id='mp-overlay';panel.setAttribute('role','dialog');panel.setAttribute('aria-label',title);
      panel.style.cssText='position:fixed;inset:0;z-index:99999;background:#100b20dd;display:grid;place-items:center;font:16px system-ui;color:#fff8ed';
      panel.innerHTML='<section style="background:#282039;border:1px solid #655276;border-radius:24px;padding:26px;width:min(680px,86vw);max-height:86vh;overflow:auto"><button id="mp-close" style="float:right">Закрыть ×</button><h2></h2><div id="mp-content"></div><p id="mp-status" role="status"></p></section>';
      panel.querySelector('h2').textContent=title;
      // The canvas must not receive clicks made on a modal control.
      for(const event of ['mousedown','mouseup','pointerdown','pointerup','touchstart','touchend'])panel.addEventListener(event,e=>e.stopPropagation());
      document.body.append(panel);panel.querySelector('#mp-close').onclick=close;
      return panel.querySelector('#mp-content');
    }
    function rename(){const root=shell('Имя твоего монстра');root.innerHTML='<label>Имя (до 24 символов)<br><input id="mp-name" maxlength="24" style="font:24px system-ui;padding:10px;margin:16px 0"></label><br><button id="mp-name-save">Готово</button>';
      root.querySelector('input').value=state().get('Name').getAsString();root.querySelector('button').onclick=()=>{const n=root.querySelector('input').value.trim();if(n){set('Name',n);close();}};
    }
    function validateLabels(m){const labels=m.getClassLabels();if(labels.length!==4||!allowed.every(n=>labels.includes(n)))throw Error('Нужны ровно 4 класса: ATTACK, SHIELD, HEAL, IDLE. Проверь регистр.');}
    async function replaceModel(next){try{validateLabels(next);}catch(e){next.model.dispose();throw e;}stop();if(model)model.model.dispose();model=next;status('Модель готова. Включи камеру; команды действуют только на арене.');}
    function missingFiles(files){
      const names=Array.from(files,f=>f.name);
      return ['model.json','metadata.json'].filter(n=>!names.includes(n));
    }
    async function loadLocal(files){const f=Array.from(files),find=n=>f.find(x=>x.name===n);const missing=missingFiles(f);if(missing.length)throw Error('Не хватает: '+missing.join(', ')+'. Нужен распакованный экспорт TensorFlow.js из Teachable Machine.');
      const meta=JSON.parse(await find('metadata.json').text());const spec=JSON.parse(await find('model.json').text());
      if(!Array.isArray(spec.weightsManifest)||!spec.modelTopology)throw Error('Этот JSON не похож на модель TensorFlow.js. game.json — проект GDevelop, а не файл ИИ.');
      const names=spec.weightsManifest.flatMap(g=>g.paths);const weights=names.map(n=>{const file=find(n);if(!file)throw Error('Не найден файл весов '+n);return file;});
      await libraries();
      const layers=await tf.loadLayersModel(tf.io.browserFiles([find('model.json'),...weights]));
      await replaceModel(new tmImage.CustomMobileNet(layers,meta));
    }
    async function demoModel(){await libraries();const response=await fetch(resource('demo-bundle.json'));if(!response.ok)throw Error('Не найден локальный комплект модели');const b=await response.json();const weightData=Uint8Array.from(atob(b.weightData),c=>c.charCodeAt(0)).buffer;const layers=await tf.loadLayersModel(tf.io.fromMemory(b.modelTopology,b.weightSpecs,weightData));await replaceModel(new tmImage.CustomMobileNet(layers,b.metadata));}
    // Same gesture vocabulary as the previous game. MediaPipe finds the hand;
    // readable distance rules turn its 21 landmarks into three commands.
    function handLabel(points){
      if(!points||points.length!==21)return 'IDLE';
      const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,(a.z||0)-(b.z||0));
      const [index,middle,ring,pinky]=[8,12,16,20].map(tip=>distance(points[tip],points[0])>distance(points[tip-2],points[0])*1.15);
      if(!index&&!middle&&!ring&&!pinky)return 'ATTACK';
      if(index&&middle&&ring&&pinky)return 'SHIELD';
      if(index&&middle&&!ring&&!pinky)return 'HEAL';
      return 'IDLE';
    }
    const links=[[0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],[5,9],[9,10],[10,11],[11,12],[9,13],[13,14],[14,15],[15,16],[13,17],[0,17],[17,18],[18,19],[19,20]];
    function deliver(label){
      const ready=scene.getName()==='Arena'&&scene.getVariables().get('Phase').getAsNumber()===0&&!document.getElementById('mp-learning')?.open;
      // Never accumulate a command during the enemy turn or outside the arena.
      const command=gate([{className:label,probability:1}]);
      if(command&&ready)set('AICommand',command);
    }
    function handResults(result){
      const points=result.multiHandLandmarks?.[0]||null;
      const canvas=document.getElementById('mp-hand-draw');
      if(canvas){const ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);
        if(points){ctx.strokeStyle='#baf5d2';ctx.lineWidth=2;
          for(const [a,b] of links){ctx.beginPath();ctx.moveTo(points[a].x*canvas.width,points[a].y*canvas.height);ctx.lineTo(points[b].x*canvas.width,points[b].y*canvas.height);ctx.stroke();}
          ctx.fillStyle='#bca7ff';for(const p of points){ctx.beginPath();ctx.arc(p.x*canvas.width,p.y*canvas.height,2.5,0,Math.PI*2);ctx.fill();}
        }
      }
      const label=handLabel(points);deliver(label);
      const names={ATTACK:'Кулак — атака',SHIELD:'Ладонь — щит',HEAL:'Два пальца — лечение'};
      status(!points?'Покажи одну руку целиком':label==='IDLE'?'Поверни ладонь к камере':names[label]+(armed?' · удержи жест':' · убери руку'));
    }
    async function hands(){
      if(!handReady){handReady=(async()=>{
        await loadScript('hands.js','Hands');
        handEngine=new Hands({locateFile:name=>resource(name)});
        handEngine.setOptions({maxNumHands:1,modelComplexity:1,minDetectionConfidence:.7,minTrackingConfidence:.7});
        await handEngine.initialize();return handEngine;
      })().catch(e=>{handReady=null;throw e;});}
      return handReady;
    }
    async function start(){
      stop();const retry=document.getElementById('mp-retry');if(retry)retry.hidden=true;const token=session;status('Разреши камеру…');
      try{
        if(!navigator.mediaDevices?.getUserMedia)throw Error('Запусти игру через START_WINDOWS.bat: камере нужен localhost или HTTPS.');
        const acquired=await navigator.mediaDevices.getUserMedia({video:{width:640,height:480,facingMode:'user'},audio:false});
        if(token!==session){acquired.getTracks().forEach(t=>t.stop());return;}
        stream=acquired;webcam=document.createElement('video');webcam.id='mp-video';webcam.autoplay=true;webcam.muted=true;webcam.playsInline=true;
        webcam.style.cssText='display:block;width:100%;height:150px;object-fit:contain;transform:scaleX(-1);background:#100b20;border-radius:10px';webcam.srcObject=stream;
        document.getElementById('mp-video-box').prepend(webcam);await webcam.play();
        if(token!==session)return;
        let engine=null;
        if(!model){status('Загружаем распознавание руки…');engine=await hands();}
        if(token!==session)return;
        running=true;resetGate();
        if(engine){await frameTask.catch(()=>{});if(token!==session)return;engine.onResults(result=>{if(running&&token===session)handResults(result);});}
        while(running&&token===session){
          if(engine){frameTask=engine.send({image:webcam});await frameTask;}
          else{
            const predictions=await model.predict(webcam,false);if(token!==session)break;
            const top=predictions.reduce((a,b)=>a.probability>b.probability?a:b);
            deliver(top.probability>=.85?top.className:'IDLE');status('Своя модель: '+top.className+(armed?'':' · убери руку'));
          }
          await new Promise(r=>setTimeout(r,100));
        }
      }catch(e){if(token===session){stop();const help={NotAllowedError:'Разреши камеру рядом с адресом браузера.',NotFoundError:'Камера не найдена.',NotReadableError:'Камера занята. Закрой видеозвонок.'};status(help[e.name]||('Не удалось включить камеру: '+e.message));}}
    }
    function camera(){
      if(panel?.id==='mp-camera'){close();return;}
      close();panel=document.createElement('section');panel.id='mp-camera';panel.setAttribute('role','region');panel.setAttribute('aria-label','Камера: управление рукой');
      panel.style.cssText='position:fixed;right:12px;top:145px;width:220px;max-width:85vw;max-height:75vh;overflow:auto;box-sizing:border-box;z-index:99999;background:#282039f5;color:#fff8ed;border:1px solid #bca7ff;border-radius:16px;padding:10px;box-shadow:0 8px 32px #0007;font:13px system-ui';
      panel.innerHTML='<header id="mp-drag" style="display:flex;align-items:center;justify-content:space-between;cursor:move;touch-action:none;padding:0 0 8px"><b>Управление рукой</b><button id="mp-close" aria-label="Выключить камеру" style="font:20px system-ui;background:transparent;color:inherit;border:0;cursor:pointer">×</button></header><div id="mp-video-box" style="position:relative;min-height:50px"><canvas id="mp-hand-draw" width="200" height="150" style="position:absolute;inset:0;width:100%;height:150px;transform:scaleX(-1);pointer-events:none"></canvas></div><p style="display:flex;justify-content:space-between;font-size:11px;margin:8px 0"><span>✊ Атака</span><span>✋ Щит</span><span>✌ Лечение</span></p><p id="mp-status" role="status" style="min-height:30px;margin:6px 0;color:#baf5d2"></p><button id="mp-retry" style="font:inherit">Перезапустить камеру</button><details id="mp-learning" style="margin-top:8px;font-size:11px"><summary>Своя модель для занятия</summary><p>Необязательно: экспорт Teachable Machine с классами ATTACK, SHIELD, HEAL, IDLE. Добавь model.json, metadata.json и веса.</p><input id="mp-model-files" type="file" multiple accept=".json,.bin" style="width:100%"><p id="mp-selected-files"></p><button id="mp-hands">Вернуть жесты руки</button></details>';
      for(const event of ['mousedown','mouseup','pointerdown','pointerup','touchstart','touchend'])panel.addEventListener(event,e=>e.stopPropagation());
      document.body.append(panel);panel.querySelector('#mp-close').onclick=close;panel.querySelector('#mp-retry').onclick=start;
      const header=panel.querySelector('#mp-drag');let drag=null;
      header.onpointerdown=e=>{if(e.target.closest('button'))return;const b=panel.getBoundingClientRect();drag={x:e.clientX-b.left,y:e.clientY-b.top};header.setPointerCapture(e.pointerId);};
      header.onpointermove=e=>{if(!drag)return;panel.style.right='auto';panel.style.left=Math.max(0,Math.min(innerWidth-panel.offsetWidth,e.clientX-drag.x))+'px';panel.style.top=Math.max(0,Math.min(innerHeight-panel.offsetHeight,e.clientY-drag.y))+'px';};
      header.onpointerup=header.onpointercancel=()=>{drag=null;};
      const collected=new Map();
      panel.querySelector('#mp-model-files').onchange=async e=>{
        for(const f of e.target.files)collected.set(f.name,f);
        const selection=document.getElementById('mp-selected-files');selection.textContent='Добавлены: '+[...collected.keys()].join(', ');
        try{await loadLocal([...collected.values()]);status('Модель готова. Закрой эти настройки и нажми «Перезапустить камеру».');}catch(err){status(err.message);}
      };
      panel.querySelector('#mp-hands').onclick=()=>{stop();if(model)model.model.dispose();model=null;panel.querySelector('details').open=false;start();};
      start();
    }
    const fields=['Name','Health','Energy','Strength','XP','Level','Wins','Round','Gold','RoomStyle','Badges',...['Body','Eyes','Mouth','Arms','Legs','Horns','Nose','Ears','Tail','Wings'].map(x=>x+'Variant')];
    const limits={Gold:[0,100000],RoomStyle:[0,2],Badges:[0,3],Health:[0,100],Energy:[0,100],Strength:[10,30],XP:[0,100000],Level:[1,33334],Wins:[0,3],Round:[1,3],BodyVariant:[0,5],EyesVariant:[0,7],MouthVariant:[0,5]};
    function save(){try{const values={};for(const n of fields)values[n]=n==='Name'?state().get(n).getAsString():get(n);localStorage.setItem('monster-protocol-v1',JSON.stringify({version:1,values}));set('Message','Сохранено в этом браузере. Для переноса копируй проект; эта запись не передаётся автоматически.');}catch{set('Message','Браузер запретил локальное сохранение. Сохрани проект в GDevelop.');}}
    function load(){try{const data=JSON.parse(localStorage.getItem('monster-protocol-v1'));if(data?.version!==1||!data.values)throw Error('Нет сохранения');for(const n of fields){const v=data.values[n]===undefined&&['Gold','RoomStyle','Badges'].includes(n)?get(n):data.values[n];data.values[n]=v;if(n==='Name'){if(typeof v!=='string'||!v.trim()||v.length>24)throw Error('Имя');}else{const [lo,hi]=limits[n]||[0,3];if(!Number.isFinite(v)||!Number.isInteger(v)||v<lo||v>hi)throw Error(n);}}for(const n of fields)set(n,data.values[n]);set('Message','Сохранение загружено.');}catch{set('Message','Корректное сохранение не найдено. Текущий монстр не изменён.');}}
    function tick(next){if(scene&&scene!==next){if(panel&&panel.id!=='mp-camera')close();resetGate();}scene=next;
      const cameraLabel=scene.getObjects('CameraLabel')[0];if(cameraLabel)cameraLabel.setString(panel?.id==='mp-camera'?'Выключить камеру':'Включить камеру');
      const battle=document.getElementById('mp-battle-state');if(battle)battle.textContent='Раунд '+get('Round')+' / 3 · Соперник: '+get('EnemyHP')+' HP · Ты: '+get('Health')+' HP · Энергия: '+get('Energy')+' · '+state().get('Message').getAsString();
      for(const [key,fn] of [['NamePanel',rename],['AIPanel',camera],['SaveRequest',save],['LoadRequest',load]])if(get(key)){set(key,0);fn();}
    }
    window.addEventListener('pagehide',()=>{if(scene)stop();});
    return {tick,gate,resetGate,stop,close,loadLocal,demoModel,handLabel,getCameraState:()=>({running,mode:model?'custom':'hands'}),getScene:()=>scene,getModel:()=>model};
  })();
}
runtimeScene.getGame().enableMetrics(false);
globalThis.MonsterProtocol.tick(runtimeScene);
};
gdjs.ArenaCode.eventsList4 = function(runtimeScene) {

{


gdjs.ArenaCode.userFunc0xadae80(runtimeScene);

}


};gdjs.ArenaCode.eventsList5 = function(runtimeScene) {

{


gdjs.ArenaCode.eventsList0(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Message"), gdjs.ArenaCode.GDMessageObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDMessageObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMessageObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(24)));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Creator"), gdjs.ArenaCode.GDCreatorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDCreatorObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13629764);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MonsterCreator", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Camera"), gdjs.ArenaCode.GDCameraObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDCameraObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13630972);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("PlayerName"), gdjs.ArenaCode.GDPlayerNameObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDPlayerNameObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDPlayerNameObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(10)));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HealthValue"), gdjs.ArenaCode.GDHealthValueObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDHealthValueObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDHealthValueObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11))));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EnergyValue"), gdjs.ArenaCode.GDEnergyValueObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDEnergyValueObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDEnergyValueObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12))));
}
}
}

}


{


gdjs.ArenaCode.eventsList1(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Backdrop"), gdjs.ArenaCode.GDBackdropObjects1);
gdjs.copyArray(runtimeScene.getObjects("CombatStats"), gdjs.ArenaCode.GDCombatStatsObjects1);
gdjs.copyArray(runtimeScene.getObjects("EnemyHPValue"), gdjs.ArenaCode.GDEnemyHPValueObjects1);
gdjs.copyArray(runtimeScene.getObjects("NameText"), gdjs.ArenaCode.GDNameTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rival"), gdjs.ArenaCode.GDRivalObjects1);
gdjs.copyArray(runtimeScene.getObjects("RoundText"), gdjs.ArenaCode.GDRoundTextObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDBackdropObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDBackdropObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)) - 1);
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDRivalObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDRivalObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)) - 1);
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDNameTextObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDNameTextObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(10)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDEnemyHPValueObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDEnemyHPValueObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDCombatStatsObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDCombatStatsObjects1[i].setString("Соперник: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + " HP");
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDRoundTextObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDRoundTextObjects1[i].setString("ХРАНИТЕЛЬ " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))) + " / 3");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EnemyTitle"), gdjs.ArenaCode.GDEnemyTitleObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDEnemyTitleObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDEnemyTitleObjects1[i].setString("Моховик · лесной друг");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EnemyTitle"), gdjs.ArenaCode.GDEnemyTitleObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDEnemyTitleObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDEnemyTitleObjects1[i].setString("Искра · быстрая лиса");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EnemyTitle"), gdjs.ArenaCode.GDEnemyTitleObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDEnemyTitleObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDEnemyTitleObjects1[i].setString("Кристаллус · страж ночи");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Retreat"), gdjs.ArenaCode.GDRetreatObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDRetreatObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13641988);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Дома можно отдохнуть. Текущий хранитель начнёт бой заново.");
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Lab", false);
}
}

}


{


gdjs.ArenaCode.eventsList2(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EnemyIntent"), gdjs.ArenaCode.GDEnemyIntentObjects1);
gdjs.copyArray(runtimeScene.getObjects("PhaseText"), gdjs.ArenaCode.GDPhaseTextObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDPhaseTextObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDPhaseTextObjects1[i].setString("Твой ход");
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDEnemyIntentObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDEnemyIntentObjects1[i].setString("Хранитель ответит после твоего действия");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7)) == 2;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EnemyIntent"), gdjs.ArenaCode.GDEnemyIntentObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDEnemyIntentObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDEnemyIntentObjects1[i].setString("ГОТОВИТ СИЛЬНЫЙ УДАР — ИСПОЛЬЗУЙ ЩИТ!");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PhaseText"), gdjs.ArenaCode.GDPhaseTextObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDPhaseTextObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDPhaseTextObjects1[i].setString("Смотри за боем…");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PhaseText"), gdjs.ArenaCode.GDPhaseTextObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDPhaseTextObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDPhaseTextObjects1[i].setString("Хранитель отвечает!");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) == 5;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PhaseText"), gdjs.ArenaCode.GDPhaseTextObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDPhaseTextObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDPhaseTextObjects1[i].setString("ПОБЕДА! +20 звёзд");
}
}
}

}


{


gdjs.ArenaCode.eventsList3(runtimeScene);
}


{


gdjs.ArenaCode.eventsList4(runtimeScene);
}


};

gdjs.ArenaCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ArenaCode.GDBackdropObjects1.length = 0;
gdjs.ArenaCode.GDBackdropObjects2.length = 0;
gdjs.ArenaCode.GDBackdropObjects3.length = 0;
gdjs.ArenaCode.GDBrandObjects1.length = 0;
gdjs.ArenaCode.GDBrandObjects2.length = 0;
gdjs.ArenaCode.GDBrandObjects3.length = 0;
gdjs.ArenaCode.GDEditionObjects1.length = 0;
gdjs.ArenaCode.GDEditionObjects2.length = 0;
gdjs.ArenaCode.GDEditionObjects3.length = 0;
gdjs.ArenaCode.GDTitleObjects1.length = 0;
gdjs.ArenaCode.GDTitleObjects2.length = 0;
gdjs.ArenaCode.GDTitleObjects3.length = 0;
gdjs.ArenaCode.GDKickerObjects1.length = 0;
gdjs.ArenaCode.GDKickerObjects2.length = 0;
gdjs.ArenaCode.GDKickerObjects3.length = 0;
gdjs.ArenaCode.GDHeaderShadeObjects1.length = 0;
gdjs.ArenaCode.GDHeaderShadeObjects2.length = 0;
gdjs.ArenaCode.GDHeaderShadeObjects3.length = 0;
gdjs.ArenaCode.GDMusicObjects1.length = 0;
gdjs.ArenaCode.GDMusicObjects2.length = 0;
gdjs.ArenaCode.GDMusicObjects3.length = 0;
gdjs.ArenaCode.GDMusicLabelObjects1.length = 0;
gdjs.ArenaCode.GDMusicLabelObjects2.length = 0;
gdjs.ArenaCode.GDMusicLabelObjects3.length = 0;
gdjs.ArenaCode.GDParticleSparkObjects1.length = 0;
gdjs.ArenaCode.GDParticleSparkObjects2.length = 0;
gdjs.ArenaCode.GDParticleSparkObjects3.length = 0;
gdjs.ArenaCode.GDParticleHeartObjects1.length = 0;
gdjs.ArenaCode.GDParticleHeartObjects2.length = 0;
gdjs.ArenaCode.GDParticleHeartObjects3.length = 0;
gdjs.ArenaCode.GDParticleBubbleObjects1.length = 0;
gdjs.ArenaCode.GDParticleBubbleObjects2.length = 0;
gdjs.ArenaCode.GDParticleBubbleObjects3.length = 0;
gdjs.ArenaCode.GDProjectileObjects1.length = 0;
gdjs.ArenaCode.GDProjectileObjects2.length = 0;
gdjs.ArenaCode.GDProjectileObjects3.length = 0;
gdjs.ArenaCode.GDFloatingNumberObjects1.length = 0;
gdjs.ArenaCode.GDFloatingNumberObjects2.length = 0;
gdjs.ArenaCode.GDFloatingNumberObjects3.length = 0;
gdjs.ArenaCode.GDShieldHaloObjects1.length = 0;
gdjs.ArenaCode.GDShieldHaloObjects2.length = 0;
gdjs.ArenaCode.GDShieldHaloObjects3.length = 0;
gdjs.ArenaCode.GDMessagePanelObjects1.length = 0;
gdjs.ArenaCode.GDMessagePanelObjects2.length = 0;
gdjs.ArenaCode.GDMessagePanelObjects3.length = 0;
gdjs.ArenaCode.GDMessageObjects1.length = 0;
gdjs.ArenaCode.GDMessageObjects2.length = 0;
gdjs.ArenaCode.GDMessageObjects3.length = 0;
gdjs.ArenaCode.GDCreatorObjects1.length = 0;
gdjs.ArenaCode.GDCreatorObjects2.length = 0;
gdjs.ArenaCode.GDCreatorObjects3.length = 0;
gdjs.ArenaCode.GDCreatorLabelObjects1.length = 0;
gdjs.ArenaCode.GDCreatorLabelObjects2.length = 0;
gdjs.ArenaCode.GDCreatorLabelObjects3.length = 0;
gdjs.ArenaCode.GDCameraObjects1.length = 0;
gdjs.ArenaCode.GDCameraObjects2.length = 0;
gdjs.ArenaCode.GDCameraObjects3.length = 0;
gdjs.ArenaCode.GDCameraLabelObjects1.length = 0;
gdjs.ArenaCode.GDCameraLabelObjects2.length = 0;
gdjs.ArenaCode.GDCameraLabelObjects3.length = 0;
gdjs.ArenaCode.GDPlayerHUDObjects1.length = 0;
gdjs.ArenaCode.GDPlayerHUDObjects2.length = 0;
gdjs.ArenaCode.GDPlayerHUDObjects3.length = 0;
gdjs.ArenaCode.GDPlayerNameObjects1.length = 0;
gdjs.ArenaCode.GDPlayerNameObjects2.length = 0;
gdjs.ArenaCode.GDPlayerNameObjects3.length = 0;
gdjs.ArenaCode.GDHealthTrackObjects1.length = 0;
gdjs.ArenaCode.GDHealthTrackObjects2.length = 0;
gdjs.ArenaCode.GDHealthTrackObjects3.length = 0;
gdjs.ArenaCode.GDHealthBarObjects1.length = 0;
gdjs.ArenaCode.GDHealthBarObjects2.length = 0;
gdjs.ArenaCode.GDHealthBarObjects3.length = 0;
gdjs.ArenaCode.GDHealthValueObjects1.length = 0;
gdjs.ArenaCode.GDHealthValueObjects2.length = 0;
gdjs.ArenaCode.GDHealthValueObjects3.length = 0;
gdjs.ArenaCode.GDEnergyTrackObjects1.length = 0;
gdjs.ArenaCode.GDEnergyTrackObjects2.length = 0;
gdjs.ArenaCode.GDEnergyTrackObjects3.length = 0;
gdjs.ArenaCode.GDEnergyBarObjects1.length = 0;
gdjs.ArenaCode.GDEnergyBarObjects2.length = 0;
gdjs.ArenaCode.GDEnergyBarObjects3.length = 0;
gdjs.ArenaCode.GDEnergyValueObjects1.length = 0;
gdjs.ArenaCode.GDEnergyValueObjects2.length = 0;
gdjs.ArenaCode.GDEnergyValueObjects3.length = 0;
gdjs.ArenaCode.GDMonsterBodyObjects1.length = 0;
gdjs.ArenaCode.GDMonsterBodyObjects2.length = 0;
gdjs.ArenaCode.GDMonsterBodyObjects3.length = 0;
gdjs.ArenaCode.GDMonsterEyesObjects1.length = 0;
gdjs.ArenaCode.GDMonsterEyesObjects2.length = 0;
gdjs.ArenaCode.GDMonsterEyesObjects3.length = 0;
gdjs.ArenaCode.GDMonsterMouthObjects1.length = 0;
gdjs.ArenaCode.GDMonsterMouthObjects2.length = 0;
gdjs.ArenaCode.GDMonsterMouthObjects3.length = 0;
gdjs.ArenaCode.GDMonsterArmsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterArmsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterArmsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterLegsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterLegsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterLegsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterHornsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterHornsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterHornsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterNoseObjects1.length = 0;
gdjs.ArenaCode.GDMonsterNoseObjects2.length = 0;
gdjs.ArenaCode.GDMonsterNoseObjects3.length = 0;
gdjs.ArenaCode.GDMonsterEarsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterEarsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterEarsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterTailObjects1.length = 0;
gdjs.ArenaCode.GDMonsterTailObjects2.length = 0;
gdjs.ArenaCode.GDMonsterTailObjects3.length = 0;
gdjs.ArenaCode.GDMonsterWingsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterWingsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterWingsObjects3.length = 0;
gdjs.ArenaCode.GDRivalObjects1.length = 0;
gdjs.ArenaCode.GDRivalObjects2.length = 0;
gdjs.ArenaCode.GDRivalObjects3.length = 0;
gdjs.ArenaCode.GDEnemyHUDObjects1.length = 0;
gdjs.ArenaCode.GDEnemyHUDObjects2.length = 0;
gdjs.ArenaCode.GDEnemyHUDObjects3.length = 0;
gdjs.ArenaCode.GDEnemyTitleObjects1.length = 0;
gdjs.ArenaCode.GDEnemyTitleObjects2.length = 0;
gdjs.ArenaCode.GDEnemyTitleObjects3.length = 0;
gdjs.ArenaCode.GDEnemyHPValueObjects1.length = 0;
gdjs.ArenaCode.GDEnemyHPValueObjects2.length = 0;
gdjs.ArenaCode.GDEnemyHPValueObjects3.length = 0;
gdjs.ArenaCode.GDEnemyHealthTrackObjects1.length = 0;
gdjs.ArenaCode.GDEnemyHealthTrackObjects2.length = 0;
gdjs.ArenaCode.GDEnemyHealthTrackObjects3.length = 0;
gdjs.ArenaCode.GDEnemyHealthBarObjects1.length = 0;
gdjs.ArenaCode.GDEnemyHealthBarObjects2.length = 0;
gdjs.ArenaCode.GDEnemyHealthBarObjects3.length = 0;
gdjs.ArenaCode.GDRoundTextObjects1.length = 0;
gdjs.ArenaCode.GDRoundTextObjects2.length = 0;
gdjs.ArenaCode.GDRoundTextObjects3.length = 0;
gdjs.ArenaCode.GDPhaseTextObjects1.length = 0;
gdjs.ArenaCode.GDPhaseTextObjects2.length = 0;
gdjs.ArenaCode.GDPhaseTextObjects3.length = 0;
gdjs.ArenaCode.GDEnemyIntentObjects1.length = 0;
gdjs.ArenaCode.GDEnemyIntentObjects2.length = 0;
gdjs.ArenaCode.GDEnemyIntentObjects3.length = 0;
gdjs.ArenaCode.GDNameTextObjects1.length = 0;
gdjs.ArenaCode.GDNameTextObjects2.length = 0;
gdjs.ArenaCode.GDNameTextObjects3.length = 0;
gdjs.ArenaCode.GDCombatStatsObjects1.length = 0;
gdjs.ArenaCode.GDCombatStatsObjects2.length = 0;
gdjs.ArenaCode.GDCombatStatsObjects3.length = 0;
gdjs.ArenaCode.GDAttackObjects1.length = 0;
gdjs.ArenaCode.GDAttackObjects2.length = 0;
gdjs.ArenaCode.GDAttackObjects3.length = 0;
gdjs.ArenaCode.GDAttackLabelObjects1.length = 0;
gdjs.ArenaCode.GDAttackLabelObjects2.length = 0;
gdjs.ArenaCode.GDAttackLabelObjects3.length = 0;
gdjs.ArenaCode.GDShieldObjects1.length = 0;
gdjs.ArenaCode.GDShieldObjects2.length = 0;
gdjs.ArenaCode.GDShieldObjects3.length = 0;
gdjs.ArenaCode.GDShieldLabelObjects1.length = 0;
gdjs.ArenaCode.GDShieldLabelObjects2.length = 0;
gdjs.ArenaCode.GDShieldLabelObjects3.length = 0;
gdjs.ArenaCode.GDHealObjects1.length = 0;
gdjs.ArenaCode.GDHealObjects2.length = 0;
gdjs.ArenaCode.GDHealObjects3.length = 0;
gdjs.ArenaCode.GDHealLabelObjects1.length = 0;
gdjs.ArenaCode.GDHealLabelObjects2.length = 0;
gdjs.ArenaCode.GDHealLabelObjects3.length = 0;
gdjs.ArenaCode.GDRetreatObjects1.length = 0;
gdjs.ArenaCode.GDRetreatObjects2.length = 0;
gdjs.ArenaCode.GDRetreatObjects3.length = 0;
gdjs.ArenaCode.GDRetreatLabelObjects1.length = 0;
gdjs.ArenaCode.GDRetreatLabelObjects2.length = 0;
gdjs.ArenaCode.GDRetreatLabelObjects3.length = 0;

gdjs.ArenaCode.eventsList5(runtimeScene);
gdjs.ArenaCode.GDBackdropObjects1.length = 0;
gdjs.ArenaCode.GDBackdropObjects2.length = 0;
gdjs.ArenaCode.GDBackdropObjects3.length = 0;
gdjs.ArenaCode.GDBrandObjects1.length = 0;
gdjs.ArenaCode.GDBrandObjects2.length = 0;
gdjs.ArenaCode.GDBrandObjects3.length = 0;
gdjs.ArenaCode.GDEditionObjects1.length = 0;
gdjs.ArenaCode.GDEditionObjects2.length = 0;
gdjs.ArenaCode.GDEditionObjects3.length = 0;
gdjs.ArenaCode.GDTitleObjects1.length = 0;
gdjs.ArenaCode.GDTitleObjects2.length = 0;
gdjs.ArenaCode.GDTitleObjects3.length = 0;
gdjs.ArenaCode.GDKickerObjects1.length = 0;
gdjs.ArenaCode.GDKickerObjects2.length = 0;
gdjs.ArenaCode.GDKickerObjects3.length = 0;
gdjs.ArenaCode.GDHeaderShadeObjects1.length = 0;
gdjs.ArenaCode.GDHeaderShadeObjects2.length = 0;
gdjs.ArenaCode.GDHeaderShadeObjects3.length = 0;
gdjs.ArenaCode.GDMusicObjects1.length = 0;
gdjs.ArenaCode.GDMusicObjects2.length = 0;
gdjs.ArenaCode.GDMusicObjects3.length = 0;
gdjs.ArenaCode.GDMusicLabelObjects1.length = 0;
gdjs.ArenaCode.GDMusicLabelObjects2.length = 0;
gdjs.ArenaCode.GDMusicLabelObjects3.length = 0;
gdjs.ArenaCode.GDParticleSparkObjects1.length = 0;
gdjs.ArenaCode.GDParticleSparkObjects2.length = 0;
gdjs.ArenaCode.GDParticleSparkObjects3.length = 0;
gdjs.ArenaCode.GDParticleHeartObjects1.length = 0;
gdjs.ArenaCode.GDParticleHeartObjects2.length = 0;
gdjs.ArenaCode.GDParticleHeartObjects3.length = 0;
gdjs.ArenaCode.GDParticleBubbleObjects1.length = 0;
gdjs.ArenaCode.GDParticleBubbleObjects2.length = 0;
gdjs.ArenaCode.GDParticleBubbleObjects3.length = 0;
gdjs.ArenaCode.GDProjectileObjects1.length = 0;
gdjs.ArenaCode.GDProjectileObjects2.length = 0;
gdjs.ArenaCode.GDProjectileObjects3.length = 0;
gdjs.ArenaCode.GDFloatingNumberObjects1.length = 0;
gdjs.ArenaCode.GDFloatingNumberObjects2.length = 0;
gdjs.ArenaCode.GDFloatingNumberObjects3.length = 0;
gdjs.ArenaCode.GDShieldHaloObjects1.length = 0;
gdjs.ArenaCode.GDShieldHaloObjects2.length = 0;
gdjs.ArenaCode.GDShieldHaloObjects3.length = 0;
gdjs.ArenaCode.GDMessagePanelObjects1.length = 0;
gdjs.ArenaCode.GDMessagePanelObjects2.length = 0;
gdjs.ArenaCode.GDMessagePanelObjects3.length = 0;
gdjs.ArenaCode.GDMessageObjects1.length = 0;
gdjs.ArenaCode.GDMessageObjects2.length = 0;
gdjs.ArenaCode.GDMessageObjects3.length = 0;
gdjs.ArenaCode.GDCreatorObjects1.length = 0;
gdjs.ArenaCode.GDCreatorObjects2.length = 0;
gdjs.ArenaCode.GDCreatorObjects3.length = 0;
gdjs.ArenaCode.GDCreatorLabelObjects1.length = 0;
gdjs.ArenaCode.GDCreatorLabelObjects2.length = 0;
gdjs.ArenaCode.GDCreatorLabelObjects3.length = 0;
gdjs.ArenaCode.GDCameraObjects1.length = 0;
gdjs.ArenaCode.GDCameraObjects2.length = 0;
gdjs.ArenaCode.GDCameraObjects3.length = 0;
gdjs.ArenaCode.GDCameraLabelObjects1.length = 0;
gdjs.ArenaCode.GDCameraLabelObjects2.length = 0;
gdjs.ArenaCode.GDCameraLabelObjects3.length = 0;
gdjs.ArenaCode.GDPlayerHUDObjects1.length = 0;
gdjs.ArenaCode.GDPlayerHUDObjects2.length = 0;
gdjs.ArenaCode.GDPlayerHUDObjects3.length = 0;
gdjs.ArenaCode.GDPlayerNameObjects1.length = 0;
gdjs.ArenaCode.GDPlayerNameObjects2.length = 0;
gdjs.ArenaCode.GDPlayerNameObjects3.length = 0;
gdjs.ArenaCode.GDHealthTrackObjects1.length = 0;
gdjs.ArenaCode.GDHealthTrackObjects2.length = 0;
gdjs.ArenaCode.GDHealthTrackObjects3.length = 0;
gdjs.ArenaCode.GDHealthBarObjects1.length = 0;
gdjs.ArenaCode.GDHealthBarObjects2.length = 0;
gdjs.ArenaCode.GDHealthBarObjects3.length = 0;
gdjs.ArenaCode.GDHealthValueObjects1.length = 0;
gdjs.ArenaCode.GDHealthValueObjects2.length = 0;
gdjs.ArenaCode.GDHealthValueObjects3.length = 0;
gdjs.ArenaCode.GDEnergyTrackObjects1.length = 0;
gdjs.ArenaCode.GDEnergyTrackObjects2.length = 0;
gdjs.ArenaCode.GDEnergyTrackObjects3.length = 0;
gdjs.ArenaCode.GDEnergyBarObjects1.length = 0;
gdjs.ArenaCode.GDEnergyBarObjects2.length = 0;
gdjs.ArenaCode.GDEnergyBarObjects3.length = 0;
gdjs.ArenaCode.GDEnergyValueObjects1.length = 0;
gdjs.ArenaCode.GDEnergyValueObjects2.length = 0;
gdjs.ArenaCode.GDEnergyValueObjects3.length = 0;
gdjs.ArenaCode.GDMonsterBodyObjects1.length = 0;
gdjs.ArenaCode.GDMonsterBodyObjects2.length = 0;
gdjs.ArenaCode.GDMonsterBodyObjects3.length = 0;
gdjs.ArenaCode.GDMonsterEyesObjects1.length = 0;
gdjs.ArenaCode.GDMonsterEyesObjects2.length = 0;
gdjs.ArenaCode.GDMonsterEyesObjects3.length = 0;
gdjs.ArenaCode.GDMonsterMouthObjects1.length = 0;
gdjs.ArenaCode.GDMonsterMouthObjects2.length = 0;
gdjs.ArenaCode.GDMonsterMouthObjects3.length = 0;
gdjs.ArenaCode.GDMonsterArmsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterArmsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterArmsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterLegsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterLegsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterLegsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterHornsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterHornsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterHornsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterNoseObjects1.length = 0;
gdjs.ArenaCode.GDMonsterNoseObjects2.length = 0;
gdjs.ArenaCode.GDMonsterNoseObjects3.length = 0;
gdjs.ArenaCode.GDMonsterEarsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterEarsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterEarsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterTailObjects1.length = 0;
gdjs.ArenaCode.GDMonsterTailObjects2.length = 0;
gdjs.ArenaCode.GDMonsterTailObjects3.length = 0;
gdjs.ArenaCode.GDMonsterWingsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterWingsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterWingsObjects3.length = 0;
gdjs.ArenaCode.GDRivalObjects1.length = 0;
gdjs.ArenaCode.GDRivalObjects2.length = 0;
gdjs.ArenaCode.GDRivalObjects3.length = 0;
gdjs.ArenaCode.GDEnemyHUDObjects1.length = 0;
gdjs.ArenaCode.GDEnemyHUDObjects2.length = 0;
gdjs.ArenaCode.GDEnemyHUDObjects3.length = 0;
gdjs.ArenaCode.GDEnemyTitleObjects1.length = 0;
gdjs.ArenaCode.GDEnemyTitleObjects2.length = 0;
gdjs.ArenaCode.GDEnemyTitleObjects3.length = 0;
gdjs.ArenaCode.GDEnemyHPValueObjects1.length = 0;
gdjs.ArenaCode.GDEnemyHPValueObjects2.length = 0;
gdjs.ArenaCode.GDEnemyHPValueObjects3.length = 0;
gdjs.ArenaCode.GDEnemyHealthTrackObjects1.length = 0;
gdjs.ArenaCode.GDEnemyHealthTrackObjects2.length = 0;
gdjs.ArenaCode.GDEnemyHealthTrackObjects3.length = 0;
gdjs.ArenaCode.GDEnemyHealthBarObjects1.length = 0;
gdjs.ArenaCode.GDEnemyHealthBarObjects2.length = 0;
gdjs.ArenaCode.GDEnemyHealthBarObjects3.length = 0;
gdjs.ArenaCode.GDRoundTextObjects1.length = 0;
gdjs.ArenaCode.GDRoundTextObjects2.length = 0;
gdjs.ArenaCode.GDRoundTextObjects3.length = 0;
gdjs.ArenaCode.GDPhaseTextObjects1.length = 0;
gdjs.ArenaCode.GDPhaseTextObjects2.length = 0;
gdjs.ArenaCode.GDPhaseTextObjects3.length = 0;
gdjs.ArenaCode.GDEnemyIntentObjects1.length = 0;
gdjs.ArenaCode.GDEnemyIntentObjects2.length = 0;
gdjs.ArenaCode.GDEnemyIntentObjects3.length = 0;
gdjs.ArenaCode.GDNameTextObjects1.length = 0;
gdjs.ArenaCode.GDNameTextObjects2.length = 0;
gdjs.ArenaCode.GDNameTextObjects3.length = 0;
gdjs.ArenaCode.GDCombatStatsObjects1.length = 0;
gdjs.ArenaCode.GDCombatStatsObjects2.length = 0;
gdjs.ArenaCode.GDCombatStatsObjects3.length = 0;
gdjs.ArenaCode.GDAttackObjects1.length = 0;
gdjs.ArenaCode.GDAttackObjects2.length = 0;
gdjs.ArenaCode.GDAttackObjects3.length = 0;
gdjs.ArenaCode.GDAttackLabelObjects1.length = 0;
gdjs.ArenaCode.GDAttackLabelObjects2.length = 0;
gdjs.ArenaCode.GDAttackLabelObjects3.length = 0;
gdjs.ArenaCode.GDShieldObjects1.length = 0;
gdjs.ArenaCode.GDShieldObjects2.length = 0;
gdjs.ArenaCode.GDShieldObjects3.length = 0;
gdjs.ArenaCode.GDShieldLabelObjects1.length = 0;
gdjs.ArenaCode.GDShieldLabelObjects2.length = 0;
gdjs.ArenaCode.GDShieldLabelObjects3.length = 0;
gdjs.ArenaCode.GDHealObjects1.length = 0;
gdjs.ArenaCode.GDHealObjects2.length = 0;
gdjs.ArenaCode.GDHealObjects3.length = 0;
gdjs.ArenaCode.GDHealLabelObjects1.length = 0;
gdjs.ArenaCode.GDHealLabelObjects2.length = 0;
gdjs.ArenaCode.GDHealLabelObjects3.length = 0;
gdjs.ArenaCode.GDRetreatObjects1.length = 0;
gdjs.ArenaCode.GDRetreatObjects2.length = 0;
gdjs.ArenaCode.GDRetreatObjects3.length = 0;
gdjs.ArenaCode.GDRetreatLabelObjects1.length = 0;
gdjs.ArenaCode.GDRetreatLabelObjects2.length = 0;
gdjs.ArenaCode.GDRetreatLabelObjects3.length = 0;


return;

}

gdjs['ArenaCode'] = gdjs.ArenaCode;

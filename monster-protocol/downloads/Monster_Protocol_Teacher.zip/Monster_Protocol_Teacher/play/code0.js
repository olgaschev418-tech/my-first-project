gdjs.MonsterCreatorCode = {};
gdjs.MonsterCreatorCode.localVariables = [];
gdjs.MonsterCreatorCode.idToCallbackMap = new Map();
gdjs.MonsterCreatorCode.GDBackdropObjects1= [];
gdjs.MonsterCreatorCode.GDBackdropObjects2= [];
gdjs.MonsterCreatorCode.GDBackdropObjects3= [];
gdjs.MonsterCreatorCode.GDBrandObjects1= [];
gdjs.MonsterCreatorCode.GDBrandObjects2= [];
gdjs.MonsterCreatorCode.GDBrandObjects3= [];
gdjs.MonsterCreatorCode.GDEditionObjects1= [];
gdjs.MonsterCreatorCode.GDEditionObjects2= [];
gdjs.MonsterCreatorCode.GDEditionObjects3= [];
gdjs.MonsterCreatorCode.GDTitleObjects1= [];
gdjs.MonsterCreatorCode.GDTitleObjects2= [];
gdjs.MonsterCreatorCode.GDTitleObjects3= [];
gdjs.MonsterCreatorCode.GDKickerObjects1= [];
gdjs.MonsterCreatorCode.GDKickerObjects2= [];
gdjs.MonsterCreatorCode.GDKickerObjects3= [];
gdjs.MonsterCreatorCode.GDPortraitPanelObjects1= [];
gdjs.MonsterCreatorCode.GDPortraitPanelObjects2= [];
gdjs.MonsterCreatorCode.GDPortraitPanelObjects3= [];
gdjs.MonsterCreatorCode.GDPartPanelObjects1= [];
gdjs.MonsterCreatorCode.GDPartPanelObjects2= [];
gdjs.MonsterCreatorCode.GDPartPanelObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterBodyObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterBodyObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterBodyObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterEyesObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterEyesObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterEyesObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterMouthObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterMouthObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterMouthObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterArmsObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterArmsObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterArmsObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterLegsObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterLegsObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterLegsObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterHornsObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterHornsObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterHornsObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterNoseObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterNoseObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterNoseObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterEarsObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterEarsObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterEarsObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterTailObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterTailObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterTailObjects3= [];
gdjs.MonsterCreatorCode.GDMonsterWingsObjects1= [];
gdjs.MonsterCreatorCode.GDMonsterWingsObjects2= [];
gdjs.MonsterCreatorCode.GDMonsterWingsObjects3= [];
gdjs.MonsterCreatorCode.GDNameTextObjects1= [];
gdjs.MonsterCreatorCode.GDNameTextObjects2= [];
gdjs.MonsterCreatorCode.GDNameTextObjects3= [];
gdjs.MonsterCreatorCode.GDCombinationObjects1= [];
gdjs.MonsterCreatorCode.GDCombinationObjects2= [];
gdjs.MonsterCreatorCode.GDCombinationObjects3= [];
gdjs.MonsterCreatorCode.GDBodyTitleObjects1= [];
gdjs.MonsterCreatorCode.GDBodyTitleObjects2= [];
gdjs.MonsterCreatorCode.GDBodyTitleObjects3= [];
gdjs.MonsterCreatorCode.GDBodyPrevObjects1= [];
gdjs.MonsterCreatorCode.GDBodyPrevObjects2= [];
gdjs.MonsterCreatorCode.GDBodyPrevObjects3= [];
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDBodyNextObjects1= [];
gdjs.MonsterCreatorCode.GDBodyNextObjects2= [];
gdjs.MonsterCreatorCode.GDBodyNextObjects3= [];
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDBodyCountObjects1= [];
gdjs.MonsterCreatorCode.GDBodyCountObjects2= [];
gdjs.MonsterCreatorCode.GDBodyCountObjects3= [];
gdjs.MonsterCreatorCode.GDEyesTitleObjects1= [];
gdjs.MonsterCreatorCode.GDEyesTitleObjects2= [];
gdjs.MonsterCreatorCode.GDEyesTitleObjects3= [];
gdjs.MonsterCreatorCode.GDEyesPrevObjects1= [];
gdjs.MonsterCreatorCode.GDEyesPrevObjects2= [];
gdjs.MonsterCreatorCode.GDEyesPrevObjects3= [];
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDEyesNextObjects1= [];
gdjs.MonsterCreatorCode.GDEyesNextObjects2= [];
gdjs.MonsterCreatorCode.GDEyesNextObjects3= [];
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDEyesCountObjects1= [];
gdjs.MonsterCreatorCode.GDEyesCountObjects2= [];
gdjs.MonsterCreatorCode.GDEyesCountObjects3= [];
gdjs.MonsterCreatorCode.GDMouthTitleObjects1= [];
gdjs.MonsterCreatorCode.GDMouthTitleObjects2= [];
gdjs.MonsterCreatorCode.GDMouthTitleObjects3= [];
gdjs.MonsterCreatorCode.GDMouthPrevObjects1= [];
gdjs.MonsterCreatorCode.GDMouthPrevObjects2= [];
gdjs.MonsterCreatorCode.GDMouthPrevObjects3= [];
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDMouthNextObjects1= [];
gdjs.MonsterCreatorCode.GDMouthNextObjects2= [];
gdjs.MonsterCreatorCode.GDMouthNextObjects3= [];
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDMouthCountObjects1= [];
gdjs.MonsterCreatorCode.GDMouthCountObjects2= [];
gdjs.MonsterCreatorCode.GDMouthCountObjects3= [];
gdjs.MonsterCreatorCode.GDArmsTitleObjects1= [];
gdjs.MonsterCreatorCode.GDArmsTitleObjects2= [];
gdjs.MonsterCreatorCode.GDArmsTitleObjects3= [];
gdjs.MonsterCreatorCode.GDArmsPrevObjects1= [];
gdjs.MonsterCreatorCode.GDArmsPrevObjects2= [];
gdjs.MonsterCreatorCode.GDArmsPrevObjects3= [];
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDArmsNextObjects1= [];
gdjs.MonsterCreatorCode.GDArmsNextObjects2= [];
gdjs.MonsterCreatorCode.GDArmsNextObjects3= [];
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDArmsCountObjects1= [];
gdjs.MonsterCreatorCode.GDArmsCountObjects2= [];
gdjs.MonsterCreatorCode.GDArmsCountObjects3= [];
gdjs.MonsterCreatorCode.GDLegsTitleObjects1= [];
gdjs.MonsterCreatorCode.GDLegsTitleObjects2= [];
gdjs.MonsterCreatorCode.GDLegsTitleObjects3= [];
gdjs.MonsterCreatorCode.GDLegsPrevObjects1= [];
gdjs.MonsterCreatorCode.GDLegsPrevObjects2= [];
gdjs.MonsterCreatorCode.GDLegsPrevObjects3= [];
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDLegsNextObjects1= [];
gdjs.MonsterCreatorCode.GDLegsNextObjects2= [];
gdjs.MonsterCreatorCode.GDLegsNextObjects3= [];
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDLegsCountObjects1= [];
gdjs.MonsterCreatorCode.GDLegsCountObjects2= [];
gdjs.MonsterCreatorCode.GDLegsCountObjects3= [];
gdjs.MonsterCreatorCode.GDHornsTitleObjects1= [];
gdjs.MonsterCreatorCode.GDHornsTitleObjects2= [];
gdjs.MonsterCreatorCode.GDHornsTitleObjects3= [];
gdjs.MonsterCreatorCode.GDHornsPrevObjects1= [];
gdjs.MonsterCreatorCode.GDHornsPrevObjects2= [];
gdjs.MonsterCreatorCode.GDHornsPrevObjects3= [];
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDHornsNextObjects1= [];
gdjs.MonsterCreatorCode.GDHornsNextObjects2= [];
gdjs.MonsterCreatorCode.GDHornsNextObjects3= [];
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDHornsCountObjects1= [];
gdjs.MonsterCreatorCode.GDHornsCountObjects2= [];
gdjs.MonsterCreatorCode.GDHornsCountObjects3= [];
gdjs.MonsterCreatorCode.GDNoseTitleObjects1= [];
gdjs.MonsterCreatorCode.GDNoseTitleObjects2= [];
gdjs.MonsterCreatorCode.GDNoseTitleObjects3= [];
gdjs.MonsterCreatorCode.GDNosePrevObjects1= [];
gdjs.MonsterCreatorCode.GDNosePrevObjects2= [];
gdjs.MonsterCreatorCode.GDNosePrevObjects3= [];
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDNoseNextObjects1= [];
gdjs.MonsterCreatorCode.GDNoseNextObjects2= [];
gdjs.MonsterCreatorCode.GDNoseNextObjects3= [];
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDNoseCountObjects1= [];
gdjs.MonsterCreatorCode.GDNoseCountObjects2= [];
gdjs.MonsterCreatorCode.GDNoseCountObjects3= [];
gdjs.MonsterCreatorCode.GDEarsTitleObjects1= [];
gdjs.MonsterCreatorCode.GDEarsTitleObjects2= [];
gdjs.MonsterCreatorCode.GDEarsTitleObjects3= [];
gdjs.MonsterCreatorCode.GDEarsPrevObjects1= [];
gdjs.MonsterCreatorCode.GDEarsPrevObjects2= [];
gdjs.MonsterCreatorCode.GDEarsPrevObjects3= [];
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDEarsNextObjects1= [];
gdjs.MonsterCreatorCode.GDEarsNextObjects2= [];
gdjs.MonsterCreatorCode.GDEarsNextObjects3= [];
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDEarsCountObjects1= [];
gdjs.MonsterCreatorCode.GDEarsCountObjects2= [];
gdjs.MonsterCreatorCode.GDEarsCountObjects3= [];
gdjs.MonsterCreatorCode.GDTailTitleObjects1= [];
gdjs.MonsterCreatorCode.GDTailTitleObjects2= [];
gdjs.MonsterCreatorCode.GDTailTitleObjects3= [];
gdjs.MonsterCreatorCode.GDTailPrevObjects1= [];
gdjs.MonsterCreatorCode.GDTailPrevObjects2= [];
gdjs.MonsterCreatorCode.GDTailPrevObjects3= [];
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDTailNextObjects1= [];
gdjs.MonsterCreatorCode.GDTailNextObjects2= [];
gdjs.MonsterCreatorCode.GDTailNextObjects3= [];
gdjs.MonsterCreatorCode.GDTailNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDTailNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDTailNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDTailCountObjects1= [];
gdjs.MonsterCreatorCode.GDTailCountObjects2= [];
gdjs.MonsterCreatorCode.GDTailCountObjects3= [];
gdjs.MonsterCreatorCode.GDWingsTitleObjects1= [];
gdjs.MonsterCreatorCode.GDWingsTitleObjects2= [];
gdjs.MonsterCreatorCode.GDWingsTitleObjects3= [];
gdjs.MonsterCreatorCode.GDWingsPrevObjects1= [];
gdjs.MonsterCreatorCode.GDWingsPrevObjects2= [];
gdjs.MonsterCreatorCode.GDWingsPrevObjects3= [];
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects1= [];
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects2= [];
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects3= [];
gdjs.MonsterCreatorCode.GDWingsNextObjects1= [];
gdjs.MonsterCreatorCode.GDWingsNextObjects2= [];
gdjs.MonsterCreatorCode.GDWingsNextObjects3= [];
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects1= [];
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects2= [];
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects3= [];
gdjs.MonsterCreatorCode.GDWingsCountObjects1= [];
gdjs.MonsterCreatorCode.GDWingsCountObjects2= [];
gdjs.MonsterCreatorCode.GDWingsCountObjects3= [];
gdjs.MonsterCreatorCode.GDRandomObjects1= [];
gdjs.MonsterCreatorCode.GDRandomObjects2= [];
gdjs.MonsterCreatorCode.GDRandomObjects3= [];
gdjs.MonsterCreatorCode.GDRandomLabelObjects1= [];
gdjs.MonsterCreatorCode.GDRandomLabelObjects2= [];
gdjs.MonsterCreatorCode.GDRandomLabelObjects3= [];
gdjs.MonsterCreatorCode.GDRenameObjects1= [];
gdjs.MonsterCreatorCode.GDRenameObjects2= [];
gdjs.MonsterCreatorCode.GDRenameObjects3= [];
gdjs.MonsterCreatorCode.GDRenameLabelObjects1= [];
gdjs.MonsterCreatorCode.GDRenameLabelObjects2= [];
gdjs.MonsterCreatorCode.GDRenameLabelObjects3= [];
gdjs.MonsterCreatorCode.GDSaveObjects1= [];
gdjs.MonsterCreatorCode.GDSaveObjects2= [];
gdjs.MonsterCreatorCode.GDSaveObjects3= [];
gdjs.MonsterCreatorCode.GDSaveLabelObjects1= [];
gdjs.MonsterCreatorCode.GDSaveLabelObjects2= [];
gdjs.MonsterCreatorCode.GDSaveLabelObjects3= [];
gdjs.MonsterCreatorCode.GDLoadObjects1= [];
gdjs.MonsterCreatorCode.GDLoadObjects2= [];
gdjs.MonsterCreatorCode.GDLoadObjects3= [];
gdjs.MonsterCreatorCode.GDLoadLabelObjects1= [];
gdjs.MonsterCreatorCode.GDLoadLabelObjects2= [];
gdjs.MonsterCreatorCode.GDLoadLabelObjects3= [];
gdjs.MonsterCreatorCode.GDToLabObjects1= [];
gdjs.MonsterCreatorCode.GDToLabObjects2= [];
gdjs.MonsterCreatorCode.GDToLabObjects3= [];
gdjs.MonsterCreatorCode.GDToLabLabelObjects1= [];
gdjs.MonsterCreatorCode.GDToLabLabelObjects2= [];
gdjs.MonsterCreatorCode.GDToLabLabelObjects3= [];


gdjs.MonsterCreatorCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MonsterArms"), gdjs.MonsterCreatorCode.GDMonsterArmsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterBody"), gdjs.MonsterCreatorCode.GDMonsterBodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterEars"), gdjs.MonsterCreatorCode.GDMonsterEarsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterEyes"), gdjs.MonsterCreatorCode.GDMonsterEyesObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterHorns"), gdjs.MonsterCreatorCode.GDMonsterHornsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterLegs"), gdjs.MonsterCreatorCode.GDMonsterLegsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterMouth"), gdjs.MonsterCreatorCode.GDMonsterMouthObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterNose"), gdjs.MonsterCreatorCode.GDMonsterNoseObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterTail"), gdjs.MonsterCreatorCode.GDMonsterTailObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterWings"), gdjs.MonsterCreatorCode.GDMonsterWingsObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterBodyObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterBodyObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterEyesObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterEyesObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterMouthObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterMouthObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterArmsObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterArmsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterLegsObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterLegsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterHornsObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterHornsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterNoseObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterNoseObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterEarsObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterEarsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterTailObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterTailObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)));
}
}
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMonsterWingsObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMonsterWingsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)));
}
}
}

}


};gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDBodyNextObjects2Objects = Hashtable.newFrom({"BodyNext": gdjs.MonsterCreatorCode.GDBodyNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDBodyPrevObjects2Objects = Hashtable.newFrom({"BodyPrev": gdjs.MonsterCreatorCode.GDBodyPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEyesNextObjects2Objects = Hashtable.newFrom({"EyesNext": gdjs.MonsterCreatorCode.GDEyesNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEyesPrevObjects2Objects = Hashtable.newFrom({"EyesPrev": gdjs.MonsterCreatorCode.GDEyesPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDMouthNextObjects2Objects = Hashtable.newFrom({"MouthNext": gdjs.MonsterCreatorCode.GDMouthNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDMouthPrevObjects2Objects = Hashtable.newFrom({"MouthPrev": gdjs.MonsterCreatorCode.GDMouthPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDArmsNextObjects2Objects = Hashtable.newFrom({"ArmsNext": gdjs.MonsterCreatorCode.GDArmsNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDArmsPrevObjects2Objects = Hashtable.newFrom({"ArmsPrev": gdjs.MonsterCreatorCode.GDArmsPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDLegsNextObjects2Objects = Hashtable.newFrom({"LegsNext": gdjs.MonsterCreatorCode.GDLegsNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDLegsPrevObjects2Objects = Hashtable.newFrom({"LegsPrev": gdjs.MonsterCreatorCode.GDLegsPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDHornsNextObjects2Objects = Hashtable.newFrom({"HornsNext": gdjs.MonsterCreatorCode.GDHornsNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDHornsPrevObjects2Objects = Hashtable.newFrom({"HornsPrev": gdjs.MonsterCreatorCode.GDHornsPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDNoseNextObjects2Objects = Hashtable.newFrom({"NoseNext": gdjs.MonsterCreatorCode.GDNoseNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDNosePrevObjects2Objects = Hashtable.newFrom({"NosePrev": gdjs.MonsterCreatorCode.GDNosePrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEarsNextObjects2Objects = Hashtable.newFrom({"EarsNext": gdjs.MonsterCreatorCode.GDEarsNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEarsPrevObjects2Objects = Hashtable.newFrom({"EarsPrev": gdjs.MonsterCreatorCode.GDEarsPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDTailNextObjects2Objects = Hashtable.newFrom({"TailNext": gdjs.MonsterCreatorCode.GDTailNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDTailPrevObjects2Objects = Hashtable.newFrom({"TailPrev": gdjs.MonsterCreatorCode.GDTailPrevObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDWingsNextObjects2Objects = Hashtable.newFrom({"WingsNext": gdjs.MonsterCreatorCode.GDWingsNextObjects2});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDWingsPrevObjects1Objects = Hashtable.newFrom({"WingsPrev": gdjs.MonsterCreatorCode.GDWingsPrevObjects1});
gdjs.MonsterCreatorCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BodyNext"), gdjs.MonsterCreatorCode.GDBodyNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDBodyNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12018324);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) + 1, 6));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BodyPrev"), gdjs.MonsterCreatorCode.GDBodyPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDBodyPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12019580);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) + 6 - 1, 6));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("EyesNext"), gdjs.MonsterCreatorCode.GDEyesNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEyesNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12020828);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) + 1, 8));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("EyesPrev"), gdjs.MonsterCreatorCode.GDEyesPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEyesPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12022076);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) + 8 - 1, 8));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MouthNext"), gdjs.MonsterCreatorCode.GDMouthNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDMouthNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12023332);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) + 1, 6));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MouthPrev"), gdjs.MonsterCreatorCode.GDMouthPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDMouthPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12024620);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) + 6 - 1, 6));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ArmsNext"), gdjs.MonsterCreatorCode.GDArmsNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDArmsNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12025876);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ArmsPrev"), gdjs.MonsterCreatorCode.GDArmsPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDArmsPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12027132);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) + 4 - 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LegsNext"), gdjs.MonsterCreatorCode.GDLegsNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDLegsNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12028388);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LegsPrev"), gdjs.MonsterCreatorCode.GDLegsPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDLegsPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12029684);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) + 4 - 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HornsNext"), gdjs.MonsterCreatorCode.GDHornsNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDHornsNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12030956);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("HornsPrev"), gdjs.MonsterCreatorCode.GDHornsPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDHornsPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12032212);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) + 4 - 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NoseNext"), gdjs.MonsterCreatorCode.GDNoseNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDNoseNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12033468);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NosePrev"), gdjs.MonsterCreatorCode.GDNosePrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDNosePrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12034724);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) + 4 - 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("EarsNext"), gdjs.MonsterCreatorCode.GDEarsNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEarsNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12035980);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("EarsPrev"), gdjs.MonsterCreatorCode.GDEarsPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDEarsPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12037236);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) + 4 - 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TailNext"), gdjs.MonsterCreatorCode.GDTailNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDTailNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12038492);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TailPrev"), gdjs.MonsterCreatorCode.GDTailPrevObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDTailPrevObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12039844);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) + 4 - 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WingsNext"), gdjs.MonsterCreatorCode.GDWingsNextObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDWingsNextObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12041116);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) + 1, 4));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("WingsPrev"), gdjs.MonsterCreatorCode.GDWingsPrevObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDWingsPrevObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12042372);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) + 4 - 1, 4));
}
}

}


};gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDRandomObjects1Objects = Hashtable.newFrom({"Random": gdjs.MonsterCreatorCode.GDRandomObjects1});
gdjs.MonsterCreatorCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Random"), gdjs.MonsterCreatorCode.GDRandomObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDRandomObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12043892);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.random(5));
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(gdjs.random(7));
}
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(gdjs.random(5));
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(gdjs.random(3));
}
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(gdjs.random(3));
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.random(3));
}
{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(gdjs.random(3));
}
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.random(3));
}
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.random(3));
}
{runtimeScene.getGame().getVariables().getFromIndex(9).setNumber(gdjs.random(3));
}
}

}


};gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDToLabObjects1Objects = Hashtable.newFrom({"ToLab": gdjs.MonsterCreatorCode.GDToLabObjects1});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDRenameObjects1Objects = Hashtable.newFrom({"Rename": gdjs.MonsterCreatorCode.GDRenameObjects1});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDSaveObjects1Objects = Hashtable.newFrom({"Save": gdjs.MonsterCreatorCode.GDSaveObjects1});
gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDLoadObjects1Objects = Hashtable.newFrom({"Load": gdjs.MonsterCreatorCode.GDLoadObjects1});
gdjs.MonsterCreatorCode.userFunc0xb58068 = function GDJSInlineCode(runtimeScene) {
"use strict";
/* Teacher-owned adapter. Gameplay lives in visible GDevelop events, not here. */
if (!globalThis.MonsterProtocol) {
  globalThis.MonsterProtocol = (() => {
    let scene, model=null, panel=null, webcam=null, stream=null, running=false, session=0;
    let candidate='', since=0, neutralSince=0, armed=true, lastCommand=-Infinity;
    const allowed=['ATTACK','SHIELD','HEAL','IDLE'];
    const state=()=>scene.getGame().getVariables();
    const set=(n,v)=>typeof v==='string'?state().get(n).setString(v):state().get(n).setNumber(v);
    const get=n=>state().get(n).getAsNumber();
    const status=s=>{const el=document.getElementById('mp-status');if(el)el.textContent=s;};
    function resource(name) {
      const data=scene.getGame().getGameData().resources.resources.find(r=>r.name==='assets/'+name);
      if (!data) throw Error('Ресурс не найден: '+name);
      return scene.getGame().getResourceLoader().getFullUrl(data.file);
    }
    const loadScript=(name,globalName)=>new Promise((resolve,reject)=>{
      if(globalThis[globalName])return resolve();
      const s=document.createElement('script');s.src=resource(name);s.onload=resolve;s.onerror=()=>reject(Error('Не загружена локальная библиотека '+name));document.head.append(s);
    });
    async function libraries(){await loadScript('tf.min.js','tf');await loadScript('tm.min.js','tmImage');}
    function resetGate(){candidate='';since=0;neutralSince=0;armed=true;lastCommand=-Infinity;}
    function gate(predictions,now=performance.now()) {
      const top=predictions.reduce((a,b)=>a.probability>b.probability?a:b,{className:'IDLE',probability:0});
      const label=top.className;
      if(top.probability<.85 || label==='IDLE') {
        candidate='';
        if(!neutralSince)neutralSince=now;
        if(now-neutralSince>=400)armed=true;
        return 0;
      }
      neutralSince=0;
      if(candidate!==label){candidate=label;since=now;return 0;}
      if(!armed || now-since<500 || now-lastCommand<1500)return 0;
      armed=false;lastCommand=now;
      return {ATTACK:1,SHIELD:2,HEAL:3}[label]||0;
    }
    function stop(){session++;running=false;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;if(webcam){webcam.srcObject=null;webcam.remove();webcam=null;}set('AICommand',0);resetGate();status('Камера выключена. Кнопки игры доступны.');}
    function close(){stop();if(panel)panel.remove();panel=null;}
    function shell(title){
      close();panel=document.createElement('div');panel.id='mp-overlay';panel.setAttribute('role','dialog');panel.setAttribute('aria-label',title);
      panel.style.cssText='position:fixed;inset:0;z-index:99999;background:#100b20dd;display:grid;place-items:center;font:16px system-ui;color:#fff8ed';
      panel.innerHTML='<section style="background:#282039;border:1px solid #655276;border-radius:24px;padding:26px;width:min(680px,86vw);max-height:86vh;overflow:auto"><button id="mp-close" style="float:right">Закрыть ×</button><h2></h2><div id="mp-content"></div><p id="mp-status" role="status"></p></section>';
      panel.querySelector('h2').textContent=title;
      // The canvas must not receive clicks made on a modal control.
      for(const event of ['mousedown','mouseup','pointerdown','pointerup','touchstart','touchend'])panel.addEventListener(event,e=>e.stopPropagation());
      document.body.append(panel);panel.querySelector('#mp-close').onclick=close;
      return panel.querySelector('#mp-content');
    }
    function rename(){const root=shell('Имя твоего монстра');root.innerHTML='<label>Имя (до 24 символов)<br><input id="mp-name" maxlength="24" style="font:24px system-ui;padding:10px;margin:16px 0"></label><br><button id="mp-name-save">Готово</button>';
      root.querySelector('input').value=state().get('Name').getAsString();root.querySelector('button').onclick=()=>{const n=root.querySelector('input').value.trim();if(n){set('Name',n);close();}};
    }
    function validateLabels(m){const labels=m.getClassLabels();if(labels.length!==4||!allowed.every(n=>labels.includes(n)))throw Error('Нужны ровно 4 класса: ATTACK, SHIELD, HEAL, IDLE. Проверь регистр.');}
    async function replaceModel(next){try{validateLabels(next);}catch(e){next.model.dispose();throw e;}stop();if(model)model.model.dispose();model=next;status('Модель готова. Включи камеру; команды действуют только на арене.');}
    function missingFiles(files){
      const names=Array.from(files,f=>f.name);
      return ['model.json','metadata.json'].filter(n=>!names.includes(n));
    }
    async function loadLocal(files){const f=Array.from(files),find=n=>f.find(x=>x.name===n);const missing=missingFiles(f);if(missing.length)throw Error('Не хватает: '+missing.join(', ')+'. Нужен распакованный экспорт TensorFlow.js из Teachable Machine.');
      const meta=JSON.parse(await find('metadata.json').text());const spec=JSON.parse(await find('model.json').text());
      if(!Array.isArray(spec.weightsManifest)||!spec.modelTopology)throw Error('Этот JSON не похож на модель TensorFlow.js. game.json — проект GDevelop, а не файл ИИ.');
      const names=spec.weightsManifest.flatMap(g=>g.paths);const weights=names.map(n=>{const file=find(n);if(!file)throw Error('Не найден файл весов '+n);return file;});
      await libraries();
      const layers=await tf.loadLayersModel(tf.io.browserFiles([find('model.json'),...weights]));
      await replaceModel(new tmImage.CustomMobileNet(layers,meta));
    }
    async function demoModel(){await libraries();const response=await fetch(resource('demo-bundle.json'));if(!response.ok)throw Error('Не найден локальный комплект модели');const b=await response.json();const weightData=Uint8Array.from(atob(b.weightData),c=>c.charCodeAt(0)).buffer;const layers=await tf.loadLayersModel(tf.io.fromMemory(b.modelTopology,b.weightSpecs,weightData));await replaceModel(new tmImage.CustomMobileNet(layers,b.metadata));}
    async function start(){
      if(!model){
        status('Загружаем встроенную модель цветных карточек…');
        try{await demoModel();}catch(e){status('Не удалось загрузить встроенную модель: '+e.message);return;}
      }
      stop();const token=session;status('Разреши доступ к камере…');
      try{
        if(!navigator.mediaDevices?.getUserMedia)throw Error('Камере нужен localhost или HTTPS. Запусти START_WINDOWS.bat из распакованной папки.');
        const acquired=await navigator.mediaDevices.getUserMedia({video:{width:320,height:240,facingMode:'user'},audio:false});
        if(token!==session){acquired.getTracks().forEach(t=>t.stop());return;}
        stream=acquired;webcam=document.createElement('video');webcam.id='mp-video';webcam.autoplay=true;webcam.muted=true;webcam.playsInline=true;webcam.style.cssText='width:240px;border-radius:14px;transform:scaleX(-1)';webcam.srcObject=stream;
        document.getElementById('mp-video-box').append(webcam);await webcam.play();
        if(token!==session)return;running=true;resetGate();
        while(running&&token===session){
          const predictions=await model.predict(webcam,false);if(token!==session)break;
          const top=predictions.reduce((a,b)=>a.probability>b.probability?a:b);
          const command=gate(predictions);
          status(top.className+' · '+Math.round(top.probability*100)+'%'+(armed?' · готов':' · убери карточку / вернись в IDLE'));
          if(command&&scene.getName()==='Arena')set('AICommand',command);
          await new Promise(r=>setTimeout(r,100));
        }
      }catch(e){if(token===session){stop();const help={NotAllowedError:'Разреши камеру в настройках рядом с адресом браузера.',NotFoundError:'Камера не найдена. Проверь подключение.',NotReadableError:'Камера занята или недоступна. Закрой видеозвонки и попробуй снова.'};status(help[e.name]||('Камера или модель: '+e.message));}}
    }
    function camera(){const root=shell('Teachable Machine → команды игры');
      root.innerHTML='<p>Быстрый старт: нажми <b>«Включить камеру»</b>. Встроенная модель цветных карточек загрузится сама.</p><p>Для своей модели: 4 класса <b>ATTACK · SHIELD · HEAL · IDLE</b>. Добавь <b>model.json, metadata.json и все веса</b> из экспорта TensorFlow.js — вместе или по очереди. Выбранные файлы останутся в списке.</p><input id="mp-model-files" type="file" multiple accept=".json,.bin"><p><button id="mp-demo">Модель цветных карточек</button> <button id="mp-start">Включить камеру</button> <button id="mp-stop">Выключить камеру</button></p><p>Красная карточка — атака, синяя — щит, зелёная — лечение. Нейтральный серый фон — IDLE. Это модель цвета, а не распознавание рук. Удержи карточку 0,5 с, затем убери её.</p><div id="mp-video-box"></div><p id="mp-battle-state" style="padding:12px;background:#171122;border-radius:10px"></p><p>Оставь окно открытым на арене. Для перехода к кнопкам нажми «Закрыть»: камера выключится. Видео и файлы обрабатываются в этом браузере.</p>';
      const collected=new Map();
      const selection=document.createElement('p');selection.id='mp-selected-files';selection.textContent='Своя модель: файлы пока не добавлены.';root.querySelector('#mp-model-files').after(selection);
      root.querySelector('#mp-model-files').onchange=async e=>{
        for(const file of e.target.files)collected.set(file.name,file);
        selection.textContent='Добавлены: '+[...collected.keys()].join(', ');
        try{
          const files=[...collected.values()],missing=missingFiles(files);
          if(missing.length){status('Файлы добавлены. Теперь добавь: '+missing.join(', ')+', затем файл весов из той же папки. Можно выбирать по очереди.');return;}
          status('Проверяем комплект модели…');await loadLocal(files);
        }catch(err){status('Модель пока не загружена: '+err.message+' Добавь недостающий файл, уже выбранные сохранены.');}
      };
      root.querySelector('#mp-demo').onclick=async()=>{try{status('Загружаем локальную модель…');await demoModel();}catch(e){status('Модель не загружена: '+e.message);}};
      root.querySelector('#mp-start').onclick=start;root.querySelector('#mp-stop').onclick=stop;
      status(model?'Модель готова. Можно включить камеру.':'Для быстрого старта нажми «Включить камеру»: встроенная модель карточек загрузится автоматически. Для своей модели добавь model.json, metadata.json и веса — вместе или по очереди.');
    }
    const fields=['Name','Health','Energy','Strength','XP','Level','Wins','Round',...['Body','Eyes','Mouth','Arms','Legs','Horns','Nose','Ears','Tail','Wings'].map(x=>x+'Variant')];
    // Optional teacher-owned presentation. It never writes gameplay variables.
    let visualScene=null,homes=[],previous=null,animation=null,fx=null;
    function presentation(next){
      const now=performance.now();
      if(visualScene!==next){
        fx?.remove();fx=document.createElement('canvas');fx.id='mp-effects';fx.width=1280;fx.height=800;
        fx.style.cssText='position:fixed;pointer-events:none;z-index:100';document.body.append(fx);
        visualScene=next;animation=null;previous=null;homes=[];
        for(const name of ['MonsterBody','MonsterEyes','MonsterMouth','MonsterArms','MonsterLegs','MonsterHorns','MonsterNose','MonsterEars','MonsterTail','MonsterWings','Rival'])
          for(const object of next.getObjects(name))homes.push({object,x:object.getX(),y:object.getY(),rival:name==='Rival'});
      }
      const current={hp:get('Health'),enemy:get('EnemyHP'),energy:get('Energy'),xp:get('XP')};
      if(previous){
        const hit=next.getName()==='Arena'&&current.enemy<previous.enemy;
        const hurt=next.getName()==='Arena'&&current.hp<previous.hp;
        const heal=current.hp>previous.hp||current.energy>previous.energy;
        if(hit||hurt||heal||current.xp>previous.xp)animation={start:now,hit,hurt,heal,damage:previous.enemy-current.enemy,taken:previous.hp-current.hp};
      }
      previous=current;
      const bounds=document.querySelector('canvas:not(#mp-effects)')?.getBoundingClientRect();
      if(!bounds)return;
      Object.assign(fx.style,{left:bounds.left+'px',top:bounds.top+'px',width:bounds.width+'px',height:bounds.height+'px'});
      const ctx=fx.getContext('2d');ctx.clearRect(0,0,1280,800);
      const elapsed=animation?(now-animation.start)/1000:5;
      const pulse=(start,duration)=>elapsed>start&&elapsed<start+duration?Math.sin((elapsed-start)/duration*Math.PI):0;
      const attack=pulse(0,.32),retaliate=pulse(.4,.32),jump=pulse(0,.5);
      if(animation)for(const h of homes){
        const dx=animation?(h.rival?(animation.hurt?-55*retaliate:0):(animation.hit?55*attack:0)):0;
        const dy=animation&&!h.rival&&next.getName()==='Lab'?-22*jump:0;
        h.object.setPosition(h.x+dx,h.y+dy);
      }
      if(!animation)return;
      if(elapsed>1.15){animation=null;return;}
      function orb(x,y,color,r=18){ctx.fillStyle=color;ctx.shadowColor=color;ctx.shadowBlur=25;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;}
      if(animation.hit&&elapsed<.32){orb(420+elapsed/.32*480,370,'#baf5d2');}
      if(animation.hurt&&elapsed>.4&&elapsed<.72){orb(930-(elapsed-.4)/.32*590,370,'#ffbca1');}
      ctx.font='bold 34px system-ui';ctx.textAlign='center';
      if(animation.hit){ctx.fillStyle='#ffe3ab';ctx.fillText('−'+animation.damage,970,280-elapsed*35);}
      if(animation.hurt&&elapsed>.4){ctx.fillStyle='#ffbca1';ctx.fillText('−'+animation.taken+' HP',330,280-elapsed*35);}
      if(animation.heal){ctx.strokeStyle='#baf5d2';ctx.lineWidth=6;ctx.beginPath();ctx.arc(330,383,110+jump*15,0,Math.PI*2);ctx.stroke();}
    }
    const limits={Health:[0,100],Energy:[0,100],Strength:[10,30],XP:[0,100000],Level:[1,33334],Wins:[0,3],Round:[1,3],BodyVariant:[0,5],EyesVariant:[0,7],MouthVariant:[0,5]};
    function save(){try{const values={};for(const n of fields)values[n]=n==='Name'?state().get(n).getAsString():get(n);localStorage.setItem('monster-protocol-v1',JSON.stringify({version:1,values}));set('Message','Сохранено в этом браузере. Для переноса копируй проект; эта запись не передаётся автоматически.');}catch{set('Message','Браузер запретил локальное сохранение. Сохрани проект в GDevelop.');}}
    function load(){try{const data=JSON.parse(localStorage.getItem('monster-protocol-v1'));if(data?.version!==1||!data.values)throw Error('Нет сохранения');for(const n of fields){const v=data.values[n];if(n==='Name'){if(typeof v!=='string'||!v.trim()||v.length>24)throw Error('Имя');}else{const [lo,hi]=limits[n]||[0,3];if(!Number.isFinite(v)||!Number.isInteger(v)||v<lo||v>hi)throw Error(n);}}for(const n of fields)set(n,data.values[n]);set('Message','Сохранение загружено.');}catch{set('Message','Корректное сохранение не найдено. Текущий монстр не изменён.');}}
    function tick(next){if(scene&&scene!==next&&panel)close();scene=next;
      presentation(next);
      const battle=document.getElementById('mp-battle-state');if(battle)battle.textContent='Раунд '+get('Round')+' / 3 · Соперник: '+get('EnemyHP')+' HP · Ты: '+get('Health')+' HP · Энергия: '+get('Energy')+' · '+state().get('Message').getAsString();
      for(const [key,fn] of [['NamePanel',rename],['AIPanel',camera],['SaveRequest',save],['LoadRequest',load]])if(get(key)){set(key,0);fn();}
    }
    window.addEventListener('pagehide',()=>{if(scene)stop();});
    return {tick,gate,resetGate,stop,close,loadLocal,demoModel,getScene:()=>scene,getModel:()=>model};
  })();
}
runtimeScene.getGame().enableMetrics(false);
globalThis.MonsterProtocol.tick(runtimeScene);
};
gdjs.MonsterCreatorCode.eventsList3 = function(runtimeScene) {

{


gdjs.MonsterCreatorCode.userFunc0xb58068(runtimeScene);

}


};gdjs.MonsterCreatorCode.eventsList4 = function(runtimeScene) {

{


gdjs.MonsterCreatorCode.eventsList0(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BodyCount"), gdjs.MonsterCreatorCode.GDBodyCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDBodyCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDBodyCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) + 1) + " / 6");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EyesCount"), gdjs.MonsterCreatorCode.GDEyesCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDEyesCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDEyesCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) + 1) + " / 8");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MouthCount"), gdjs.MonsterCreatorCode.GDMouthCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDMouthCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDMouthCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) + 1) + " / 6");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ArmsCount"), gdjs.MonsterCreatorCode.GDArmsCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDArmsCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDArmsCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) + 1) + " / 4");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("LegsCount"), gdjs.MonsterCreatorCode.GDLegsCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDLegsCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDLegsCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) + 1) + " / 4");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HornsCount"), gdjs.MonsterCreatorCode.GDHornsCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDHornsCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDHornsCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) + 1) + " / 4");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NoseCount"), gdjs.MonsterCreatorCode.GDNoseCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDNoseCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDNoseCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) + 1) + " / 4");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EarsCount"), gdjs.MonsterCreatorCode.GDEarsCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDEarsCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDEarsCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) + 1) + " / 4");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TailCount"), gdjs.MonsterCreatorCode.GDTailCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDTailCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDTailCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) + 1) + " / 4");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("WingsCount"), gdjs.MonsterCreatorCode.GDWingsCountObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDWingsCountObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDWingsCountObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)) + 1) + " / 4");
}
}
}

}


{


gdjs.MonsterCreatorCode.eventsList1(runtimeScene);
}


{


gdjs.MonsterCreatorCode.eventsList2(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("ToLab"), gdjs.MonsterCreatorCode.GDToLabObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDToLabObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12047188);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Lab", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Rename"), gdjs.MonsterCreatorCode.GDRenameObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDRenameObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12048348);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(21).setNumber(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Save"), gdjs.MonsterCreatorCode.GDSaveObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDSaveObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12049692);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(22).setNumber(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Load"), gdjs.MonsterCreatorCode.GDLoadObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.MonsterCreatorCode.mapOfGDgdjs_9546MonsterCreatorCode_9546GDLoadObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12050900);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(23).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NameText"), gdjs.MonsterCreatorCode.GDNameTextObjects1);
{for(var i = 0, len = gdjs.MonsterCreatorCode.GDNameTextObjects1.length ;i < len;++i) {
    gdjs.MonsterCreatorCode.GDNameTextObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(10)));
}
}
}

}


{


gdjs.MonsterCreatorCode.eventsList3(runtimeScene);
}


};

gdjs.MonsterCreatorCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MonsterCreatorCode.GDBackdropObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBackdropObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBackdropObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBrandObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBrandObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBrandObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEditionObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEditionObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEditionObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDKickerObjects1.length = 0;
gdjs.MonsterCreatorCode.GDKickerObjects2.length = 0;
gdjs.MonsterCreatorCode.GDKickerObjects3.length = 0;
gdjs.MonsterCreatorCode.GDPortraitPanelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDPortraitPanelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDPortraitPanelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDPartPanelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDPartPanelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDPartPanelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterBodyObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterBodyObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterBodyObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEyesObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEyesObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEyesObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterMouthObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterMouthObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterMouthObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterArmsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterArmsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterArmsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterLegsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterLegsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterLegsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterHornsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterHornsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterHornsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterNoseObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterNoseObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterNoseObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEarsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEarsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEarsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterTailObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterTailObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterTailObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterWingsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterWingsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterWingsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNameTextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNameTextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNameTextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDCombinationObjects1.length = 0;
gdjs.MonsterCreatorCode.GDCombinationObjects2.length = 0;
gdjs.MonsterCreatorCode.GDCombinationObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRandomObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRandomObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRandomObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRandomLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRandomLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRandomLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRenameObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRenameObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRenameObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRenameLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRenameLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRenameLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDSaveObjects1.length = 0;
gdjs.MonsterCreatorCode.GDSaveObjects2.length = 0;
gdjs.MonsterCreatorCode.GDSaveObjects3.length = 0;
gdjs.MonsterCreatorCode.GDSaveLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDSaveLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDSaveLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLoadObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLoadObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLoadObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLoadLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLoadLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLoadLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDToLabObjects1.length = 0;
gdjs.MonsterCreatorCode.GDToLabObjects2.length = 0;
gdjs.MonsterCreatorCode.GDToLabObjects3.length = 0;
gdjs.MonsterCreatorCode.GDToLabLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDToLabLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDToLabLabelObjects3.length = 0;

gdjs.MonsterCreatorCode.eventsList4(runtimeScene);
gdjs.MonsterCreatorCode.GDBackdropObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBackdropObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBackdropObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBrandObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBrandObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBrandObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEditionObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEditionObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEditionObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDKickerObjects1.length = 0;
gdjs.MonsterCreatorCode.GDKickerObjects2.length = 0;
gdjs.MonsterCreatorCode.GDKickerObjects3.length = 0;
gdjs.MonsterCreatorCode.GDPortraitPanelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDPortraitPanelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDPortraitPanelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDPartPanelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDPartPanelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDPartPanelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterBodyObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterBodyObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterBodyObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEyesObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEyesObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEyesObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterMouthObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterMouthObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterMouthObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterArmsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterArmsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterArmsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterLegsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterLegsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterLegsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterHornsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterHornsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterHornsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterNoseObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterNoseObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterNoseObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEarsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEarsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterEarsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterTailObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterTailObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterTailObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMonsterWingsObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMonsterWingsObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMonsterWingsObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNameTextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNameTextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNameTextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDCombinationObjects1.length = 0;
gdjs.MonsterCreatorCode.GDCombinationObjects2.length = 0;
gdjs.MonsterCreatorCode.GDCombinationObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDBodyCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDBodyCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDBodyCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEyesCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEyesCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEyesCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDMouthCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDMouthCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDMouthCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDArmsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDArmsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDArmsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLegsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLegsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLegsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDHornsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDHornsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDHornsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNosePrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDNoseCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDNoseCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDNoseCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDEarsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDEarsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDEarsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDTailCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDTailCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDTailCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsTitleObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsTitleObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsTitleObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsPrevLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsNextLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDWingsCountObjects1.length = 0;
gdjs.MonsterCreatorCode.GDWingsCountObjects2.length = 0;
gdjs.MonsterCreatorCode.GDWingsCountObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRandomObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRandomObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRandomObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRandomLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRandomLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRandomLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRenameObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRenameObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRenameObjects3.length = 0;
gdjs.MonsterCreatorCode.GDRenameLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDRenameLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDRenameLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDSaveObjects1.length = 0;
gdjs.MonsterCreatorCode.GDSaveObjects2.length = 0;
gdjs.MonsterCreatorCode.GDSaveObjects3.length = 0;
gdjs.MonsterCreatorCode.GDSaveLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDSaveLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDSaveLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLoadObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLoadObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLoadObjects3.length = 0;
gdjs.MonsterCreatorCode.GDLoadLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDLoadLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDLoadLabelObjects3.length = 0;
gdjs.MonsterCreatorCode.GDToLabObjects1.length = 0;
gdjs.MonsterCreatorCode.GDToLabObjects2.length = 0;
gdjs.MonsterCreatorCode.GDToLabObjects3.length = 0;
gdjs.MonsterCreatorCode.GDToLabLabelObjects1.length = 0;
gdjs.MonsterCreatorCode.GDToLabLabelObjects2.length = 0;
gdjs.MonsterCreatorCode.GDToLabLabelObjects3.length = 0;


return;

}

gdjs['MonsterCreatorCode'] = gdjs.MonsterCreatorCode;

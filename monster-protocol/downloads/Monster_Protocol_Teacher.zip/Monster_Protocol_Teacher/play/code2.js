gdjs.ArenaCode = {};
gdjs.ArenaCode.localVariables = [];
gdjs.ArenaCode.idToCallbackMap = new Map();
gdjs.ArenaCode.GDBackdropObjects1= [];
gdjs.ArenaCode.GDBackdropObjects2= [];
gdjs.ArenaCode.GDBackdropObjects3= [];
gdjs.ArenaCode.GDBrandObjects1= [];
gdjs.ArenaCode.GDBrandObjects2= [];
gdjs.ArenaCode.GDBrandObjects3= [];
gdjs.ArenaCode.GDEditionObjects1= [];
gdjs.ArenaCode.GDEditionObjects2= [];
gdjs.ArenaCode.GDEditionObjects3= [];
gdjs.ArenaCode.GDTitleObjects1= [];
gdjs.ArenaCode.GDTitleObjects2= [];
gdjs.ArenaCode.GDTitleObjects3= [];
gdjs.ArenaCode.GDKickerObjects1= [];
gdjs.ArenaCode.GDKickerObjects2= [];
gdjs.ArenaCode.GDKickerObjects3= [];
gdjs.ArenaCode.GDPortraitPanelObjects1= [];
gdjs.ArenaCode.GDPortraitPanelObjects2= [];
gdjs.ArenaCode.GDPortraitPanelObjects3= [];
gdjs.ArenaCode.GDMonsterBodyObjects1= [];
gdjs.ArenaCode.GDMonsterBodyObjects2= [];
gdjs.ArenaCode.GDMonsterBodyObjects3= [];
gdjs.ArenaCode.GDMonsterEyesObjects1= [];
gdjs.ArenaCode.GDMonsterEyesObjects2= [];
gdjs.ArenaCode.GDMonsterEyesObjects3= [];
gdjs.ArenaCode.GDMonsterMouthObjects1= [];
gdjs.ArenaCode.GDMonsterMouthObjects2= [];
gdjs.ArenaCode.GDMonsterMouthObjects3= [];
gdjs.ArenaCode.GDMonsterArmsObjects1= [];
gdjs.ArenaCode.GDMonsterArmsObjects2= [];
gdjs.ArenaCode.GDMonsterArmsObjects3= [];
gdjs.ArenaCode.GDMonsterLegsObjects1= [];
gdjs.ArenaCode.GDMonsterLegsObjects2= [];
gdjs.ArenaCode.GDMonsterLegsObjects3= [];
gdjs.ArenaCode.GDMonsterHornsObjects1= [];
gdjs.ArenaCode.GDMonsterHornsObjects2= [];
gdjs.ArenaCode.GDMonsterHornsObjects3= [];
gdjs.ArenaCode.GDMonsterNoseObjects1= [];
gdjs.ArenaCode.GDMonsterNoseObjects2= [];
gdjs.ArenaCode.GDMonsterNoseObjects3= [];
gdjs.ArenaCode.GDMonsterEarsObjects1= [];
gdjs.ArenaCode.GDMonsterEarsObjects2= [];
gdjs.ArenaCode.GDMonsterEarsObjects3= [];
gdjs.ArenaCode.GDMonsterTailObjects1= [];
gdjs.ArenaCode.GDMonsterTailObjects2= [];
gdjs.ArenaCode.GDMonsterTailObjects3= [];
gdjs.ArenaCode.GDMonsterWingsObjects1= [];
gdjs.ArenaCode.GDMonsterWingsObjects2= [];
gdjs.ArenaCode.GDMonsterWingsObjects3= [];
gdjs.ArenaCode.GDNameTextObjects1= [];
gdjs.ArenaCode.GDNameTextObjects2= [];
gdjs.ArenaCode.GDNameTextObjects3= [];
gdjs.ArenaCode.GDMessageObjects1= [];
gdjs.ArenaCode.GDMessageObjects2= [];
gdjs.ArenaCode.GDMessageObjects3= [];
gdjs.ArenaCode.GDCreatorObjects1= [];
gdjs.ArenaCode.GDCreatorObjects2= [];
gdjs.ArenaCode.GDCreatorObjects3= [];
gdjs.ArenaCode.GDCreatorLabelObjects1= [];
gdjs.ArenaCode.GDCreatorLabelObjects2= [];
gdjs.ArenaCode.GDCreatorLabelObjects3= [];
gdjs.ArenaCode.GDCameraObjects1= [];
gdjs.ArenaCode.GDCameraObjects2= [];
gdjs.ArenaCode.GDCameraObjects3= [];
gdjs.ArenaCode.GDCameraLabelObjects1= [];
gdjs.ArenaCode.GDCameraLabelObjects2= [];
gdjs.ArenaCode.GDCameraLabelObjects3= [];
gdjs.ArenaCode.GDEnemyPanelObjects1= [];
gdjs.ArenaCode.GDEnemyPanelObjects2= [];
gdjs.ArenaCode.GDEnemyPanelObjects3= [];
gdjs.ArenaCode.GDRivalObjects1= [];
gdjs.ArenaCode.GDRivalObjects2= [];
gdjs.ArenaCode.GDRivalObjects3= [];
gdjs.ArenaCode.GDEnemyTitleObjects1= [];
gdjs.ArenaCode.GDEnemyTitleObjects2= [];
gdjs.ArenaCode.GDEnemyTitleObjects3= [];
gdjs.ArenaCode.GDCombatStatsObjects1= [];
gdjs.ArenaCode.GDCombatStatsObjects2= [];
gdjs.ArenaCode.GDCombatStatsObjects3= [];
gdjs.ArenaCode.GDAttackObjects1= [];
gdjs.ArenaCode.GDAttackObjects2= [];
gdjs.ArenaCode.GDAttackObjects3= [];
gdjs.ArenaCode.GDAttackLabelObjects1= [];
gdjs.ArenaCode.GDAttackLabelObjects2= [];
gdjs.ArenaCode.GDAttackLabelObjects3= [];
gdjs.ArenaCode.GDShieldObjects1= [];
gdjs.ArenaCode.GDShieldObjects2= [];
gdjs.ArenaCode.GDShieldObjects3= [];
gdjs.ArenaCode.GDShieldLabelObjects1= [];
gdjs.ArenaCode.GDShieldLabelObjects2= [];
gdjs.ArenaCode.GDShieldLabelObjects3= [];
gdjs.ArenaCode.GDHealObjects1= [];
gdjs.ArenaCode.GDHealObjects2= [];
gdjs.ArenaCode.GDHealObjects3= [];
gdjs.ArenaCode.GDHealLabelObjects1= [];
gdjs.ArenaCode.GDHealLabelObjects2= [];
gdjs.ArenaCode.GDHealLabelObjects3= [];
gdjs.ArenaCode.GDRetreatObjects1= [];
gdjs.ArenaCode.GDRetreatObjects2= [];
gdjs.ArenaCode.GDRetreatObjects3= [];
gdjs.ArenaCode.GDRetreatLabelObjects1= [];
gdjs.ArenaCode.GDRetreatLabelObjects2= [];
gdjs.ArenaCode.GDRetreatLabelObjects3= [];


gdjs.ArenaCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("MonsterArms"), gdjs.ArenaCode.GDMonsterArmsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterBody"), gdjs.ArenaCode.GDMonsterBodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterEars"), gdjs.ArenaCode.GDMonsterEarsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterEyes"), gdjs.ArenaCode.GDMonsterEyesObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterHorns"), gdjs.ArenaCode.GDMonsterHornsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterLegs"), gdjs.ArenaCode.GDMonsterLegsObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterMouth"), gdjs.ArenaCode.GDMonsterMouthObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterNose"), gdjs.ArenaCode.GDMonsterNoseObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterTail"), gdjs.ArenaCode.GDMonsterTailObjects1);
gdjs.copyArray(runtimeScene.getObjects("MonsterWings"), gdjs.ArenaCode.GDMonsterWingsObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterBodyObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterBodyObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterEyesObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterEyesObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterMouthObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterMouthObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterArmsObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterArmsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterLegsObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterLegsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterHornsObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterHornsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterNoseObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterNoseObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterEarsObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterEarsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterTailObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterTailObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)));
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDMonsterWingsObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMonsterWingsObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(9)));
}
}
}

}


};gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDCreatorObjects1Objects = Hashtable.newFrom({"Creator": gdjs.ArenaCode.GDCreatorObjects1});
gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDCameraObjects1Objects = Hashtable.newFrom({"Camera": gdjs.ArenaCode.GDCameraObjects1});
gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDRetreatObjects1Objects = Hashtable.newFrom({"Retreat": gdjs.ArenaCode.GDRetreatObjects1});
gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDAttackObjects2Objects = Hashtable.newFrom({"Attack": gdjs.ArenaCode.GDAttackObjects2});
gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDShieldObjects2Objects = Hashtable.newFrom({"Shield": gdjs.ArenaCode.GDShieldObjects2});
gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDHealObjects2Objects = Hashtable.newFrom({"Heal": gdjs.ArenaCode.GDHealObjects2});
gdjs.ArenaCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(6 + 2 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Attack"), gdjs.ArenaCode.GDAttackObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDAttackObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12445556);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Shield"), gdjs.ArenaCode.GDShieldObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDShieldObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12446748);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(2);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Heal"), gdjs.ArenaCode.GDHealObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDHealObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12447916);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(3);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19)) > 0;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(19)));
}
{runtimeScene.getGame().getVariables().getFromIndex(19).setNumber(0);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) >= 10;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(18).setNumber(Math.max(0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(13))));
}
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) - 10);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Атака! Соперник отвечает, если ещё не побеждён.");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) < 10;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == 0;
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Мало энергии для атаки. Используй щит.");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(Math.min(100, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) + 14));
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(3);
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Щит: +14 энергии. Ответ соперника ослаблен до 3.");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) >= 20;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) - 20);
}
{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(Math.min(100, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) + 25));
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Лечение: +25 здоровья, −20 энергии. Соперник отвечает.");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12)) < 20;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == 0;
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Нужно 20 энергии для лечения. Используй щит.");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) > 0;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(Math.max(0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2))));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) <= 0;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(16).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) + 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Победа! Восстановись в лаборатории перед следующим раундом.");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) <= 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) < 3;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Lab", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(16)) >= 3;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Final", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11)) <= 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18)) > 0;
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Тренировочное поражение. Отдохни и попробуй другую тактику.");
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Lab", false);
}
}

}


};gdjs.ArenaCode.userFunc0xa21030 = function GDJSInlineCode(runtimeScene) {
"use strict";
/* Teacher-owned adapter. Gameplay lives in visible GDevelop events, not here. */
if (!globalThis.MonsterProtocol) {
  globalThis.MonsterProtocol = (() => {
    let scene, model=null, panel=null, webcam=null, stream=null, running=false, session=0;
    let candidate='', since=0, neutralSince=0, armed=true, lastCommand=-Infinity;
    const allowed=['ATTACK','SHIELD','HEAL','IDLE'];
    const state=()=>scene.getGame().getVariables();
    const set=(n,v)=>typeof v==='string'?state().get(n).setString(v):state().get(n).setNumber(v);
    const get=n=>state().get(n).getAsNumber();
    const status=s=>{const el=document.getElementById('mp-status');if(el)el.textContent=s;};
    function resource(name) {
      const data=scene.getGame().getGameData().resources.resources.find(r=>r.name==='assets/'+name);
      if (!data) throw Error('Ресурс не найден: '+name);
      return scene.getGame().getResourceLoader().getFullUrl(data.file);
    }
    const loadScript=(name,globalName)=>new Promise((resolve,reject)=>{
      if(globalThis[globalName])return resolve();
      const s=document.createElement('script');s.src=resource(name);s.onload=resolve;s.onerror=()=>reject(Error('Не загружена локальная библиотека '+name));document.head.append(s);
    });
    async function libraries(){await loadScript('tf.min.js','tf');await loadScript('tm.min.js','tmImage');}
    function resetGate(){candidate='';since=0;neutralSince=0;armed=true;lastCommand=-Infinity;}
    function gate(predictions,now=performance.now()) {
      const top=predictions.reduce((a,b)=>a.probability>b.probability?a:b,{className:'IDLE',probability:0});
      const label=top.className;
      if(top.probability<.85 || label==='IDLE') {
        candidate='';
        if(!neutralSince)neutralSince=now;
        if(now-neutralSince>=400)armed=true;
        return 0;
      }
      neutralSince=0;
      if(candidate!==label){candidate=label;since=now;return 0;}
      if(!armed || now-since<500 || now-lastCommand<1500)return 0;
      armed=false;lastCommand=now;
      return {ATTACK:1,SHIELD:2,HEAL:3}[label]||0;
    }
    function stop(){session++;running=false;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;if(webcam){webcam.srcObject=null;webcam.remove();webcam=null;}set('AICommand',0);resetGate();status('Камера выключена. Кнопки игры доступны.');}
    function close(){stop();if(panel)panel.remove();panel=null;}
    function shell(title){
      close();panel=document.createElement('div');panel.id='mp-overlay';panel.setAttribute('role','dialog');panel.setAttribute('aria-label',title);
      panel.style.cssText='position:fixed;inset:0;z-index:99999;background:#100b20dd;display:grid;place-items:center;font:16px system-ui;color:#fff8ed';
      panel.innerHTML='<section style="background:#282039;border:1px solid #655276;border-radius:24px;padding:26px;width:min(680px,86vw);max-height:86vh;overflow:auto"><button id="mp-close" style="float:right">Закрыть ×</button><h2></h2><div id="mp-content"></div><p id="mp-status" role="status"></p></section>';
      panel.querySelector('h2').textContent=title;
      // The canvas must not receive clicks made on a modal control.
      for(const event of ['mousedown','mouseup','pointerdown','pointerup','touchstart','touchend'])panel.addEventListener(event,e=>e.stopPropagation());
      document.body.append(panel);panel.querySelector('#mp-close').onclick=close;
      return panel.querySelector('#mp-content');
    }
    function rename(){const root=shell('Имя твоего монстра');root.innerHTML='<label>Имя (до 24 символов)<br><input id="mp-name" maxlength="24" style="font:24px system-ui;padding:10px;margin:16px 0"></label><br><button id="mp-name-save">Готово</button>';
      root.querySelector('input').value=state().get('Name').getAsString();root.querySelector('button').onclick=()=>{const n=root.querySelector('input').value.trim();if(n){set('Name',n);close();}};
    }
    function validateLabels(m){const labels=m.getClassLabels();if(labels.length!==4||!allowed.every(n=>labels.includes(n)))throw Error('Нужны ровно 4 класса: ATTACK, SHIELD, HEAL, IDLE. Проверь регистр.');}
    async function replaceModel(next){try{validateLabels(next);}catch(e){next.model.dispose();throw e;}stop();if(model)model.model.dispose();model=next;status('Модель готова. Включи камеру; команды действуют только на арене.');}
    function missingFiles(files){
      const names=Array.from(files,f=>f.name);
      return ['model.json','metadata.json'].filter(n=>!names.includes(n));
    }
    async function loadLocal(files){const f=Array.from(files),find=n=>f.find(x=>x.name===n);const missing=missingFiles(f);if(missing.length)throw Error('Не хватает: '+missing.join(', ')+'. Нужен распакованный экспорт TensorFlow.js из Teachable Machine.');
      const meta=JSON.parse(await find('metadata.json').text());const spec=JSON.parse(await find('model.json').text());
      if(!Array.isArray(spec.weightsManifest)||!spec.modelTopology)throw Error('Этот JSON не похож на модель TensorFlow.js. game.json — проект GDevelop, а не файл ИИ.');
      const names=spec.weightsManifest.flatMap(g=>g.paths);const weights=names.map(n=>{const file=find(n);if(!file)throw Error('Не найден файл весов '+n);return file;});
      await libraries();
      const layers=await tf.loadLayersModel(tf.io.browserFiles([find('model.json'),...weights]));
      await replaceModel(new tmImage.CustomMobileNet(layers,meta));
    }
    async function demoModel(){await libraries();const response=await fetch(resource('demo-bundle.json'));if(!response.ok)throw Error('Не найден локальный комплект модели');const b=await response.json();const weightData=Uint8Array.from(atob(b.weightData),c=>c.charCodeAt(0)).buffer;const layers=await tf.loadLayersModel(tf.io.fromMemory(b.modelTopology,b.weightSpecs,weightData));await replaceModel(new tmImage.CustomMobileNet(layers,b.metadata));}
    async function start(){
      if(!model){
        status('Загружаем встроенную модель цветных карточек…');
        try{await demoModel();}catch(e){status('Не удалось загрузить встроенную модель: '+e.message);return;}
      }
      stop();const token=session;status('Разреши доступ к камере…');
      try{
        if(!navigator.mediaDevices?.getUserMedia)throw Error('Камере нужен localhost или HTTPS. Запусти START_WINDOWS.bat из распакованной папки.');
        const acquired=await navigator.mediaDevices.getUserMedia({video:{width:320,height:240,facingMode:'user'},audio:false});
        if(token!==session){acquired.getTracks().forEach(t=>t.stop());return;}
        stream=acquired;webcam=document.createElement('video');webcam.id='mp-video';webcam.autoplay=true;webcam.muted=true;webcam.playsInline=true;webcam.style.cssText='width:240px;border-radius:14px;transform:scaleX(-1)';webcam.srcObject=stream;
        document.getElementById('mp-video-box').append(webcam);await webcam.play();
        if(token!==session)return;running=true;resetGate();
        while(running&&token===session){
          const predictions=await model.predict(webcam,false);if(token!==session)break;
          const top=predictions.reduce((a,b)=>a.probability>b.probability?a:b);
          const command=gate(predictions);
          status(top.className+' · '+Math.round(top.probability*100)+'%'+(armed?' · готов':' · убери карточку / вернись в IDLE'));
          if(command&&scene.getName()==='Arena')set('AICommand',command);
          await new Promise(r=>setTimeout(r,100));
        }
      }catch(e){if(token===session){stop();const help={NotAllowedError:'Разреши камеру в настройках рядом с адресом браузера.',NotFoundError:'Камера не найдена. Проверь подключение.',NotReadableError:'Камера занята или недоступна. Закрой видеозвонки и попробуй снова.'};status(help[e.name]||('Камера или модель: '+e.message));}}
    }
    function camera(){const root=shell('Teachable Machine → команды игры');
      root.innerHTML='<p>Быстрый старт: нажми <b>«Включить камеру»</b>. Встроенная модель цветных карточек загрузится сама.</p><p>Для своей модели: 4 класса <b>ATTACK · SHIELD · HEAL · IDLE</b>. Добавь <b>model.json, metadata.json и все веса</b> из экспорта TensorFlow.js — вместе или по очереди. Выбранные файлы останутся в списке.</p><input id="mp-model-files" type="file" multiple accept=".json,.bin"><p><button id="mp-demo">Модель цветных карточек</button> <button id="mp-start">Включить камеру</button> <button id="mp-stop">Выключить камеру</button></p><p>Красная карточка — атака, синяя — щит, зелёная — лечение. Нейтральный серый фон — IDLE. Это модель цвета, а не распознавание рук. Удержи карточку 0,5 с, затем убери её.</p><div id="mp-video-box"></div><p id="mp-battle-state" style="padding:12px;background:#171122;border-radius:10px"></p><p>Оставь окно открытым на арене. Для перехода к кнопкам нажми «Закрыть»: камера выключится. Видео и файлы обрабатываются в этом браузере.</p>';
      const collected=new Map();
      const selection=document.createElement('p');selection.id='mp-selected-files';selection.textContent='Своя модель: файлы пока не добавлены.';root.querySelector('#mp-model-files').after(selection);
      root.querySelector('#mp-model-files').onchange=async e=>{
        for(const file of e.target.files)collected.set(file.name,file);
        selection.textContent='Добавлены: '+[...collected.keys()].join(', ');
        try{
          const files=[...collected.values()],missing=missingFiles(files);
          if(missing.length){status('Файлы добавлены. Теперь добавь: '+missing.join(', ')+', затем файл весов из той же папки. Можно выбирать по очереди.');return;}
          status('Проверяем комплект модели…');await loadLocal(files);
        }catch(err){status('Модель пока не загружена: '+err.message+' Добавь недостающий файл, уже выбранные сохранены.');}
      };
      root.querySelector('#mp-demo').onclick=async()=>{try{status('Загружаем локальную модель…');await demoModel();}catch(e){status('Модель не загружена: '+e.message);}};
      root.querySelector('#mp-start').onclick=start;root.querySelector('#mp-stop').onclick=stop;
      status(model?'Модель готова. Можно включить камеру.':'Для быстрого старта нажми «Включить камеру»: встроенная модель карточек загрузится автоматически. Для своей модели добавь model.json, metadata.json и веса — вместе или по очереди.');
    }
    const fields=['Name','Health','Energy','Strength','XP','Level','Wins','Round',...['Body','Eyes','Mouth','Arms','Legs','Horns','Nose','Ears','Tail','Wings'].map(x=>x+'Variant')];
    // Optional teacher-owned presentation. It never writes gameplay variables.
    let visualScene=null,homes=[],previous=null,animation=null,fx=null;
    function presentation(next){
      const now=performance.now();
      if(visualScene!==next){
        fx?.remove();fx=document.createElement('canvas');fx.id='mp-effects';fx.width=1280;fx.height=800;
        fx.style.cssText='position:fixed;pointer-events:none;z-index:100';document.body.append(fx);
        visualScene=next;animation=null;previous=null;homes=[];
        for(const name of ['MonsterBody','MonsterEyes','MonsterMouth','MonsterArms','MonsterLegs','MonsterHorns','MonsterNose','MonsterEars','MonsterTail','MonsterWings','Rival'])
          for(const object of next.getObjects(name))homes.push({object,x:object.getX(),y:object.getY(),rival:name==='Rival'});
      }
      const current={hp:get('Health'),enemy:get('EnemyHP'),energy:get('Energy'),xp:get('XP')};
      if(previous){
        const hit=next.getName()==='Arena'&&current.enemy<previous.enemy;
        const hurt=next.getName()==='Arena'&&current.hp<previous.hp;
        const heal=current.hp>previous.hp||current.energy>previous.energy;
        if(hit||hurt||heal||current.xp>previous.xp)animation={start:now,hit,hurt,heal,damage:previous.enemy-current.enemy,taken:previous.hp-current.hp};
      }
      previous=current;
      const bounds=document.querySelector('canvas:not(#mp-effects)')?.getBoundingClientRect();
      if(!bounds)return;
      Object.assign(fx.style,{left:bounds.left+'px',top:bounds.top+'px',width:bounds.width+'px',height:bounds.height+'px'});
      const ctx=fx.getContext('2d');ctx.clearRect(0,0,1280,800);
      const elapsed=animation?(now-animation.start)/1000:5;
      const pulse=(start,duration)=>elapsed>start&&elapsed<start+duration?Math.sin((elapsed-start)/duration*Math.PI):0;
      const attack=pulse(0,.32),retaliate=pulse(.4,.32),jump=pulse(0,.5);
      if(animation)for(const h of homes){
        const dx=animation?(h.rival?(animation.hurt?-55*retaliate:0):(animation.hit?55*attack:0)):0;
        const dy=animation&&!h.rival&&next.getName()==='Lab'?-22*jump:0;
        h.object.setPosition(h.x+dx,h.y+dy);
      }
      if(!animation)return;
      if(elapsed>1.15){animation=null;return;}
      function orb(x,y,color,r=18){ctx.fillStyle=color;ctx.shadowColor=color;ctx.shadowBlur=25;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;}
      if(animation.hit&&elapsed<.32){orb(420+elapsed/.32*480,370,'#baf5d2');}
      if(animation.hurt&&elapsed>.4&&elapsed<.72){orb(930-(elapsed-.4)/.32*590,370,'#ffbca1');}
      ctx.font='bold 34px system-ui';ctx.textAlign='center';
      if(animation.hit){ctx.fillStyle='#ffe3ab';ctx.fillText('−'+animation.damage,970,280-elapsed*35);}
      if(animation.hurt&&elapsed>.4){ctx.fillStyle='#ffbca1';ctx.fillText('−'+animation.taken+' HP',330,280-elapsed*35);}
      if(animation.heal){ctx.strokeStyle='#baf5d2';ctx.lineWidth=6;ctx.beginPath();ctx.arc(330,383,110+jump*15,0,Math.PI*2);ctx.stroke();}
    }
    const limits={Health:[0,100],Energy:[0,100],Strength:[10,30],XP:[0,100000],Level:[1,33334],Wins:[0,3],Round:[1,3],BodyVariant:[0,5],EyesVariant:[0,7],MouthVariant:[0,5]};
    function save(){try{const values={};for(const n of fields)values[n]=n==='Name'?state().get(n).getAsString():get(n);localStorage.setItem('monster-protocol-v1',JSON.stringify({version:1,values}));set('Message','Сохранено в этом браузере. Для переноса копируй проект; эта запись не передаётся автоматически.');}catch{set('Message','Браузер запретил локальное сохранение. Сохрани проект в GDevelop.');}}
    function load(){try{const data=JSON.parse(localStorage.getItem('monster-protocol-v1'));if(data?.version!==1||!data.values)throw Error('Нет сохранения');for(const n of fields){const v=data.values[n];if(n==='Name'){if(typeof v!=='string'||!v.trim()||v.length>24)throw Error('Имя');}else{const [lo,hi]=limits[n]||[0,3];if(!Number.isFinite(v)||!Number.isInteger(v)||v<lo||v>hi)throw Error(n);}}for(const n of fields)set(n,data.values[n]);set('Message','Сохранение загружено.');}catch{set('Message','Корректное сохранение не найдено. Текущий монстр не изменён.');}}
    function tick(next){if(scene&&scene!==next&&panel)close();scene=next;
      presentation(next);
      const battle=document.getElementById('mp-battle-state');if(battle)battle.textContent='Раунд '+get('Round')+' / 3 · Соперник: '+get('EnemyHP')+' HP · Ты: '+get('Health')+' HP · Энергия: '+get('Energy')+' · '+state().get('Message').getAsString();
      for(const [key,fn] of [['NamePanel',rename],['AIPanel',camera],['SaveRequest',save],['LoadRequest',load]])if(get(key)){set(key,0);fn();}
    }
    window.addEventListener('pagehide',()=>{if(scene)stop();});
    return {tick,gate,resetGate,stop,close,loadLocal,demoModel,getScene:()=>scene,getModel:()=>model};
  })();
}
runtimeScene.getGame().enableMetrics(false);
globalThis.MonsterProtocol.tick(runtimeScene);
};
gdjs.ArenaCode.eventsList2 = function(runtimeScene) {

{


gdjs.ArenaCode.userFunc0xa21030(runtimeScene);

}


};gdjs.ArenaCode.eventsList3 = function(runtimeScene) {

{


gdjs.ArenaCode.eventsList0(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NameText"), gdjs.ArenaCode.GDNameTextObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDNameTextObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDNameTextObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(10)));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Message"), gdjs.ArenaCode.GDMessageObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDMessageObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDMessageObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(24)));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Creator"), gdjs.ArenaCode.GDCreatorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDCreatorObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12438108);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MonsterCreator", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Camera"), gdjs.ArenaCode.GDCameraObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDCameraObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12439300);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(20).setNumber(1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EnemyTitle"), gdjs.ArenaCode.GDEnemyTitleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rival"), gdjs.ArenaCode.GDRivalObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDRivalObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDRivalObjects1[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17)) - 1);
}
}
{for(var i = 0, len = gdjs.ArenaCode.GDEnemyTitleObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDEnemyTitleObjects1[i].setString("СОПЕРНИК " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))) + " / 3");
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("CombatStats"), gdjs.ArenaCode.GDCombatStatsObjects1);
{for(var i = 0, len = gdjs.ArenaCode.GDCombatStatsObjects1.length ;i < len;++i) {
    gdjs.ArenaCode.GDCombatStatsObjects1[i].setString("Раунд " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(17))) + " / 3     Соперник: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(18))) + " HP" + gdjs.evtTools.string.newLine() + "Ты: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(11))) + " HP     Энергия: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(12))));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Retreat"), gdjs.ArenaCode.GDRetreatObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.ArenaCode.mapOfGDgdjs_9546ArenaCode_9546GDRetreatObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12442252);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(24).setString("Можно отдохнуть и попробовать снова. Победы сохранены.");
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Lab", false);
}
}

}


{


gdjs.ArenaCode.eventsList1(runtimeScene);
}


{


gdjs.ArenaCode.eventsList2(runtimeScene);
}


};

gdjs.ArenaCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ArenaCode.GDBackdropObjects1.length = 0;
gdjs.ArenaCode.GDBackdropObjects2.length = 0;
gdjs.ArenaCode.GDBackdropObjects3.length = 0;
gdjs.ArenaCode.GDBrandObjects1.length = 0;
gdjs.ArenaCode.GDBrandObjects2.length = 0;
gdjs.ArenaCode.GDBrandObjects3.length = 0;
gdjs.ArenaCode.GDEditionObjects1.length = 0;
gdjs.ArenaCode.GDEditionObjects2.length = 0;
gdjs.ArenaCode.GDEditionObjects3.length = 0;
gdjs.ArenaCode.GDTitleObjects1.length = 0;
gdjs.ArenaCode.GDTitleObjects2.length = 0;
gdjs.ArenaCode.GDTitleObjects3.length = 0;
gdjs.ArenaCode.GDKickerObjects1.length = 0;
gdjs.ArenaCode.GDKickerObjects2.length = 0;
gdjs.ArenaCode.GDKickerObjects3.length = 0;
gdjs.ArenaCode.GDPortraitPanelObjects1.length = 0;
gdjs.ArenaCode.GDPortraitPanelObjects2.length = 0;
gdjs.ArenaCode.GDPortraitPanelObjects3.length = 0;
gdjs.ArenaCode.GDMonsterBodyObjects1.length = 0;
gdjs.ArenaCode.GDMonsterBodyObjects2.length = 0;
gdjs.ArenaCode.GDMonsterBodyObjects3.length = 0;
gdjs.ArenaCode.GDMonsterEyesObjects1.length = 0;
gdjs.ArenaCode.GDMonsterEyesObjects2.length = 0;
gdjs.ArenaCode.GDMonsterEyesObjects3.length = 0;
gdjs.ArenaCode.GDMonsterMouthObjects1.length = 0;
gdjs.ArenaCode.GDMonsterMouthObjects2.length = 0;
gdjs.ArenaCode.GDMonsterMouthObjects3.length = 0;
gdjs.ArenaCode.GDMonsterArmsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterArmsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterArmsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterLegsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterLegsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterLegsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterHornsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterHornsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterHornsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterNoseObjects1.length = 0;
gdjs.ArenaCode.GDMonsterNoseObjects2.length = 0;
gdjs.ArenaCode.GDMonsterNoseObjects3.length = 0;
gdjs.ArenaCode.GDMonsterEarsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterEarsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterEarsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterTailObjects1.length = 0;
gdjs.ArenaCode.GDMonsterTailObjects2.length = 0;
gdjs.ArenaCode.GDMonsterTailObjects3.length = 0;
gdjs.ArenaCode.GDMonsterWingsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterWingsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterWingsObjects3.length = 0;
gdjs.ArenaCode.GDNameTextObjects1.length = 0;
gdjs.ArenaCode.GDNameTextObjects2.length = 0;
gdjs.ArenaCode.GDNameTextObjects3.length = 0;
gdjs.ArenaCode.GDMessageObjects1.length = 0;
gdjs.ArenaCode.GDMessageObjects2.length = 0;
gdjs.ArenaCode.GDMessageObjects3.length = 0;
gdjs.ArenaCode.GDCreatorObjects1.length = 0;
gdjs.ArenaCode.GDCreatorObjects2.length = 0;
gdjs.ArenaCode.GDCreatorObjects3.length = 0;
gdjs.ArenaCode.GDCreatorLabelObjects1.length = 0;
gdjs.ArenaCode.GDCreatorLabelObjects2.length = 0;
gdjs.ArenaCode.GDCreatorLabelObjects3.length = 0;
gdjs.ArenaCode.GDCameraObjects1.length = 0;
gdjs.ArenaCode.GDCameraObjects2.length = 0;
gdjs.ArenaCode.GDCameraObjects3.length = 0;
gdjs.ArenaCode.GDCameraLabelObjects1.length = 0;
gdjs.ArenaCode.GDCameraLabelObjects2.length = 0;
gdjs.ArenaCode.GDCameraLabelObjects3.length = 0;
gdjs.ArenaCode.GDEnemyPanelObjects1.length = 0;
gdjs.ArenaCode.GDEnemyPanelObjects2.length = 0;
gdjs.ArenaCode.GDEnemyPanelObjects3.length = 0;
gdjs.ArenaCode.GDRivalObjects1.length = 0;
gdjs.ArenaCode.GDRivalObjects2.length = 0;
gdjs.ArenaCode.GDRivalObjects3.length = 0;
gdjs.ArenaCode.GDEnemyTitleObjects1.length = 0;
gdjs.ArenaCode.GDEnemyTitleObjects2.length = 0;
gdjs.ArenaCode.GDEnemyTitleObjects3.length = 0;
gdjs.ArenaCode.GDCombatStatsObjects1.length = 0;
gdjs.ArenaCode.GDCombatStatsObjects2.length = 0;
gdjs.ArenaCode.GDCombatStatsObjects3.length = 0;
gdjs.ArenaCode.GDAttackObjects1.length = 0;
gdjs.ArenaCode.GDAttackObjects2.length = 0;
gdjs.ArenaCode.GDAttackObjects3.length = 0;
gdjs.ArenaCode.GDAttackLabelObjects1.length = 0;
gdjs.ArenaCode.GDAttackLabelObjects2.length = 0;
gdjs.ArenaCode.GDAttackLabelObjects3.length = 0;
gdjs.ArenaCode.GDShieldObjects1.length = 0;
gdjs.ArenaCode.GDShieldObjects2.length = 0;
gdjs.ArenaCode.GDShieldObjects3.length = 0;
gdjs.ArenaCode.GDShieldLabelObjects1.length = 0;
gdjs.ArenaCode.GDShieldLabelObjects2.length = 0;
gdjs.ArenaCode.GDShieldLabelObjects3.length = 0;
gdjs.ArenaCode.GDHealObjects1.length = 0;
gdjs.ArenaCode.GDHealObjects2.length = 0;
gdjs.ArenaCode.GDHealObjects3.length = 0;
gdjs.ArenaCode.GDHealLabelObjects1.length = 0;
gdjs.ArenaCode.GDHealLabelObjects2.length = 0;
gdjs.ArenaCode.GDHealLabelObjects3.length = 0;
gdjs.ArenaCode.GDRetreatObjects1.length = 0;
gdjs.ArenaCode.GDRetreatObjects2.length = 0;
gdjs.ArenaCode.GDRetreatObjects3.length = 0;
gdjs.ArenaCode.GDRetreatLabelObjects1.length = 0;
gdjs.ArenaCode.GDRetreatLabelObjects2.length = 0;
gdjs.ArenaCode.GDRetreatLabelObjects3.length = 0;

gdjs.ArenaCode.eventsList3(runtimeScene);
gdjs.ArenaCode.GDBackdropObjects1.length = 0;
gdjs.ArenaCode.GDBackdropObjects2.length = 0;
gdjs.ArenaCode.GDBackdropObjects3.length = 0;
gdjs.ArenaCode.GDBrandObjects1.length = 0;
gdjs.ArenaCode.GDBrandObjects2.length = 0;
gdjs.ArenaCode.GDBrandObjects3.length = 0;
gdjs.ArenaCode.GDEditionObjects1.length = 0;
gdjs.ArenaCode.GDEditionObjects2.length = 0;
gdjs.ArenaCode.GDEditionObjects3.length = 0;
gdjs.ArenaCode.GDTitleObjects1.length = 0;
gdjs.ArenaCode.GDTitleObjects2.length = 0;
gdjs.ArenaCode.GDTitleObjects3.length = 0;
gdjs.ArenaCode.GDKickerObjects1.length = 0;
gdjs.ArenaCode.GDKickerObjects2.length = 0;
gdjs.ArenaCode.GDKickerObjects3.length = 0;
gdjs.ArenaCode.GDPortraitPanelObjects1.length = 0;
gdjs.ArenaCode.GDPortraitPanelObjects2.length = 0;
gdjs.ArenaCode.GDPortraitPanelObjects3.length = 0;
gdjs.ArenaCode.GDMonsterBodyObjects1.length = 0;
gdjs.ArenaCode.GDMonsterBodyObjects2.length = 0;
gdjs.ArenaCode.GDMonsterBodyObjects3.length = 0;
gdjs.ArenaCode.GDMonsterEyesObjects1.length = 0;
gdjs.ArenaCode.GDMonsterEyesObjects2.length = 0;
gdjs.ArenaCode.GDMonsterEyesObjects3.length = 0;
gdjs.ArenaCode.GDMonsterMouthObjects1.length = 0;
gdjs.ArenaCode.GDMonsterMouthObjects2.length = 0;
gdjs.ArenaCode.GDMonsterMouthObjects3.length = 0;
gdjs.ArenaCode.GDMonsterArmsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterArmsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterArmsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterLegsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterLegsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterLegsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterHornsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterHornsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterHornsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterNoseObjects1.length = 0;
gdjs.ArenaCode.GDMonsterNoseObjects2.length = 0;
gdjs.ArenaCode.GDMonsterNoseObjects3.length = 0;
gdjs.ArenaCode.GDMonsterEarsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterEarsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterEarsObjects3.length = 0;
gdjs.ArenaCode.GDMonsterTailObjects1.length = 0;
gdjs.ArenaCode.GDMonsterTailObjects2.length = 0;
gdjs.ArenaCode.GDMonsterTailObjects3.length = 0;
gdjs.ArenaCode.GDMonsterWingsObjects1.length = 0;
gdjs.ArenaCode.GDMonsterWingsObjects2.length = 0;
gdjs.ArenaCode.GDMonsterWingsObjects3.length = 0;
gdjs.ArenaCode.GDNameTextObjects1.length = 0;
gdjs.ArenaCode.GDNameTextObjects2.length = 0;
gdjs.ArenaCode.GDNameTextObjects3.length = 0;
gdjs.ArenaCode.GDMessageObjects1.length = 0;
gdjs.ArenaCode.GDMessageObjects2.length = 0;
gdjs.ArenaCode.GDMessageObjects3.length = 0;
gdjs.ArenaCode.GDCreatorObjects1.length = 0;
gdjs.ArenaCode.GDCreatorObjects2.length = 0;
gdjs.ArenaCode.GDCreatorObjects3.length = 0;
gdjs.ArenaCode.GDCreatorLabelObjects1.length = 0;
gdjs.ArenaCode.GDCreatorLabelObjects2.length = 0;
gdjs.ArenaCode.GDCreatorLabelObjects3.length = 0;
gdjs.ArenaCode.GDCameraObjects1.length = 0;
gdjs.ArenaCode.GDCameraObjects2.length = 0;
gdjs.ArenaCode.GDCameraObjects3.length = 0;
gdjs.ArenaCode.GDCameraLabelObjects1.length = 0;
gdjs.ArenaCode.GDCameraLabelObjects2.length = 0;
gdjs.ArenaCode.GDCameraLabelObjects3.length = 0;
gdjs.ArenaCode.GDEnemyPanelObjects1.length = 0;
gdjs.ArenaCode.GDEnemyPanelObjects2.length = 0;
gdjs.ArenaCode.GDEnemyPanelObjects3.length = 0;
gdjs.ArenaCode.GDRivalObjects1.length = 0;
gdjs.ArenaCode.GDRivalObjects2.length = 0;
gdjs.ArenaCode.GDRivalObjects3.length = 0;
gdjs.ArenaCode.GDEnemyTitleObjects1.length = 0;
gdjs.ArenaCode.GDEnemyTitleObjects2.length = 0;
gdjs.ArenaCode.GDEnemyTitleObjects3.length = 0;
gdjs.ArenaCode.GDCombatStatsObjects1.length = 0;
gdjs.ArenaCode.GDCombatStatsObjects2.length = 0;
gdjs.ArenaCode.GDCombatStatsObjects3.length = 0;
gdjs.ArenaCode.GDAttackObjects1.length = 0;
gdjs.ArenaCode.GDAttackObjects2.length = 0;
gdjs.ArenaCode.GDAttackObjects3.length = 0;
gdjs.ArenaCode.GDAttackLabelObjects1.length = 0;
gdjs.ArenaCode.GDAttackLabelObjects2.length = 0;
gdjs.ArenaCode.GDAttackLabelObjects3.length = 0;
gdjs.ArenaCode.GDShieldObjects1.length = 0;
gdjs.ArenaCode.GDShieldObjects2.length = 0;
gdjs.ArenaCode.GDShieldObjects3.length = 0;
gdjs.ArenaCode.GDShieldLabelObjects1.length = 0;
gdjs.ArenaCode.GDShieldLabelObjects2.length = 0;
gdjs.ArenaCode.GDShieldLabelObjects3.length = 0;
gdjs.ArenaCode.GDHealObjects1.length = 0;
gdjs.ArenaCode.GDHealObjects2.length = 0;
gdjs.ArenaCode.GDHealObjects3.length = 0;
gdjs.ArenaCode.GDHealLabelObjects1.length = 0;
gdjs.ArenaCode.GDHealLabelObjects2.length = 0;
gdjs.ArenaCode.GDHealLabelObjects3.length = 0;
gdjs.ArenaCode.GDRetreatObjects1.length = 0;
gdjs.ArenaCode.GDRetreatObjects2.length = 0;
gdjs.ArenaCode.GDRetreatObjects3.length = 0;
gdjs.ArenaCode.GDRetreatLabelObjects1.length = 0;
gdjs.ArenaCode.GDRetreatLabelObjects2.length = 0;
gdjs.ArenaCode.GDRetreatLabelObjects3.length = 0;


return;

}

gdjs['ArenaCode'] = gdjs.ArenaCode;
